﻿Public Class user_transaction
    Private Sub backBtn_Click(sender As Object, e As EventArgs) Handles backBtn.Click
        user_deposit.Show()
        Me.Hide()
    End Sub

    Private Sub exit_home_Click(sender As Object, e As EventArgs) Handles exit_home.Click
        exit_btn(Me)
        index.Hide()
    End Sub

    Private Sub user_transaction_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Dim customer_id = userlog.login_customer_id
        functions.customerDepositTransaction(customer_id, userRecord)
    End Sub
End Class