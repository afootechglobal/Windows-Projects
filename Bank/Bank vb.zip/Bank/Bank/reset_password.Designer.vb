﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class reset_password
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Guna2GradientPanel1 = New Guna.UI2.WinForms.Guna2GradientPanel()
        Me.Guna2PictureBox1 = New Guna.UI2.WinForms.Guna2PictureBox()
        Me.Guna2HtmlLabel1 = New Guna.UI2.WinForms.Guna2HtmlLabel()
        Me.exit_home = New Guna.UI2.WinForms.Guna2CircleButton()
        Me.Guna2HtmlLabel9 = New Guna.UI2.WinForms.Guna2HtmlLabel()
        Me.otp_txt = New Guna.UI2.WinForms.Guna2TextBox()
        Me.Guna2HtmlLabel10 = New Guna.UI2.WinForms.Guna2HtmlLabel()
        Me.Guna2Panel2 = New Guna.UI2.WinForms.Guna2Panel()
        Me.login_link = New System.Windows.Forms.LinkLabel()
        Me.Guna2HtmlLabel12 = New Guna.UI2.WinForms.Guna2HtmlLabel()
        Me.Guna2HtmlLabel11 = New Guna.UI2.WinForms.Guna2HtmlLabel()
        Me.create_pass = New Guna.UI2.WinForms.Guna2TextBox()
        Me.Guna2HtmlLabel13 = New Guna.UI2.WinForms.Guna2HtmlLabel()
        Me.confirm_pass = New Guna.UI2.WinForms.Guna2TextBox()
        Me.Guna2HtmlLabel14 = New Guna.UI2.WinForms.Guna2HtmlLabel()
        Me.Guna2Button1 = New Guna.UI2.WinForms.Guna2Button()
        Me.reset_btn = New Guna.UI2.WinForms.Guna2GradientButton()
        Me.passLabel = New Guna.UI2.WinForms.Guna2HtmlLabel()
        Me.Guna2GradientPanel1.SuspendLayout()
        CType(Me.Guna2PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Guna2Panel2.SuspendLayout()
        Me.SuspendLayout()
        '
        'Guna2GradientPanel1
        '
        Me.Guna2GradientPanel1.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Guna2GradientPanel1.BorderRadius = 5
        Me.Guna2GradientPanel1.Controls.Add(Me.Guna2PictureBox1)
        Me.Guna2GradientPanel1.Controls.Add(Me.Guna2HtmlLabel1)
        Me.Guna2GradientPanel1.Controls.Add(Me.exit_home)
        Me.Guna2GradientPanel1.FillColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.Guna2GradientPanel1.FillColor2 = System.Drawing.Color.Navy
        Me.Guna2GradientPanel1.Location = New System.Drawing.Point(-4, 0)
        Me.Guna2GradientPanel1.Name = "Guna2GradientPanel1"
        Me.Guna2GradientPanel1.ShadowDecoration.Parent = Me.Guna2GradientPanel1
        Me.Guna2GradientPanel1.Size = New System.Drawing.Size(731, 45)
        Me.Guna2GradientPanel1.TabIndex = 0
        '
        'Guna2PictureBox1
        '
        Me.Guna2PictureBox1.BackColor = System.Drawing.Color.Transparent
        Me.Guna2PictureBox1.Image = Global.Bank.My.Resources.Resources.padlock_1_
        Me.Guna2PictureBox1.Location = New System.Drawing.Point(15, 12)
        Me.Guna2PictureBox1.Name = "Guna2PictureBox1"
        Me.Guna2PictureBox1.ShadowDecoration.Parent = Me.Guna2PictureBox1
        Me.Guna2PictureBox1.Size = New System.Drawing.Size(31, 25)
        Me.Guna2PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.Guna2PictureBox1.TabIndex = 1
        Me.Guna2PictureBox1.TabStop = False
        '
        'Guna2HtmlLabel1
        '
        Me.Guna2HtmlLabel1.BackColor = System.Drawing.Color.Transparent
        Me.Guna2HtmlLabel1.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Guna2HtmlLabel1.ForeColor = System.Drawing.Color.White
        Me.Guna2HtmlLabel1.Location = New System.Drawing.Point(48, 14)
        Me.Guna2HtmlLabel1.Name = "Guna2HtmlLabel1"
        Me.Guna2HtmlLabel1.Size = New System.Drawing.Size(127, 20)
        Me.Guna2HtmlLabel1.TabIndex = 4
        Me.Guna2HtmlLabel1.Text = "Reset Password"
        '
        'exit_home
        '
        Me.exit_home.BackColor = System.Drawing.Color.Transparent
        Me.exit_home.BorderColor = System.Drawing.Color.Transparent
        Me.exit_home.CheckedState.Parent = Me.exit_home
        Me.exit_home.Cursor = System.Windows.Forms.Cursors.Hand
        Me.exit_home.CustomImages.Parent = Me.exit_home
        Me.exit_home.FillColor = System.Drawing.Color.Red
        Me.exit_home.Font = New System.Drawing.Font("Segoe UI", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.exit_home.ForeColor = System.Drawing.Color.White
        Me.exit_home.HoverState.FillColor = System.Drawing.Color.Maroon
        Me.exit_home.HoverState.Parent = Me.exit_home
        Me.exit_home.Location = New System.Drawing.Point(683, 3)
        Me.exit_home.Name = "exit_home"
        Me.exit_home.ShadowDecoration.Mode = Guna.UI2.WinForms.Enums.ShadowMode.Circle
        Me.exit_home.ShadowDecoration.Parent = Me.exit_home
        Me.exit_home.Size = New System.Drawing.Size(41, 38)
        Me.exit_home.TabIndex = 3
        Me.exit_home.Text = "x"
        '
        'Guna2HtmlLabel9
        '
        Me.Guna2HtmlLabel9.BackColor = System.Drawing.Color.Transparent
        Me.Guna2HtmlLabel9.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Guna2HtmlLabel9.Location = New System.Drawing.Point(37, 300)
        Me.Guna2HtmlLabel9.Name = "Guna2HtmlLabel9"
        Me.Guna2HtmlLabel9.Size = New System.Drawing.Size(455, 15)
        Me.Guna2HtmlLabel9.TabIndex = 0
        Me.Guna2HtmlLabel9.Text = "Atleast 8 characters required including upper & lower cases and special character" &
    "s and numbers"
        '
        'otp_txt
        '
        Me.otp_txt.BorderRadius = 5
        Me.otp_txt.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.otp_txt.DefaultText = ""
        Me.otp_txt.DisabledState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer))
        Me.otp_txt.DisabledState.FillColor = System.Drawing.Color.FromArgb(CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer))
        Me.otp_txt.DisabledState.ForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.otp_txt.DisabledState.Parent = Me.otp_txt
        Me.otp_txt.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.otp_txt.FocusedState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.otp_txt.FocusedState.Parent = Me.otp_txt
        Me.otp_txt.HoverState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.otp_txt.HoverState.Parent = Me.otp_txt
        Me.otp_txt.Location = New System.Drawing.Point(27, 150)
        Me.otp_txt.Name = "otp_txt"
        Me.otp_txt.PasswordChar = Global.Microsoft.VisualBasic.ChrW(0)
        Me.otp_txt.PlaceholderText = "ENTER OTP"
        Me.otp_txt.SelectedText = ""
        Me.otp_txt.ShadowDecoration.Parent = Me.otp_txt
        Me.otp_txt.Size = New System.Drawing.Size(670, 38)
        Me.otp_txt.TabIndex = 2
        '
        'Guna2HtmlLabel10
        '
        Me.Guna2HtmlLabel10.BackColor = System.Drawing.Color.Transparent
        Me.Guna2HtmlLabel10.Location = New System.Drawing.Point(40, 133)
        Me.Guna2HtmlLabel10.Name = "Guna2HtmlLabel10"
        Me.Guna2HtmlLabel10.Size = New System.Drawing.Size(68, 15)
        Me.Guna2HtmlLabel10.TabIndex = 3
        Me.Guna2HtmlLabel10.Text = "ENTER OTP:"
        '
        'Guna2Panel2
        '
        Me.Guna2Panel2.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.Guna2Panel2.BorderColor = System.Drawing.Color.Transparent
        Me.Guna2Panel2.BorderRadius = 5
        Me.Guna2Panel2.BorderThickness = 2
        Me.Guna2Panel2.Controls.Add(Me.login_link)
        Me.Guna2Panel2.Controls.Add(Me.Guna2HtmlLabel12)
        Me.Guna2Panel2.Controls.Add(Me.Guna2HtmlLabel11)
        Me.Guna2Panel2.Location = New System.Drawing.Point(27, 194)
        Me.Guna2Panel2.Name = "Guna2Panel2"
        Me.Guna2Panel2.ShadowDecoration.Parent = Me.Guna2Panel2
        Me.Guna2Panel2.Size = New System.Drawing.Size(673, 33)
        Me.Guna2Panel2.TabIndex = 1
        '
        'login_link
        '
        Me.login_link.AutoSize = True
        Me.login_link.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.login_link.ForeColor = System.Drawing.Color.Navy
        Me.login_link.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.login_link.LinkColor = System.Drawing.Color.Navy
        Me.login_link.Location = New System.Drawing.Point(123, 8)
        Me.login_link.Name = "login_link"
        Me.login_link.Size = New System.Drawing.Size(85, 15)
        Me.login_link.TabIndex = 21
        Me.login_link.TabStop = True
        Me.login_link.Text = "RESEND OTP"
        '
        'Guna2HtmlLabel12
        '
        Me.Guna2HtmlLabel12.BackColor = System.Drawing.Color.Transparent
        Me.Guna2HtmlLabel12.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Guna2HtmlLabel12.ForeColor = System.Drawing.Color.Black
        Me.Guna2HtmlLabel12.Location = New System.Drawing.Point(43, 7)
        Me.Guna2HtmlLabel12.Name = "Guna2HtmlLabel12"
        Me.Guna2HtmlLabel12.Size = New System.Drawing.Size(79, 17)
        Me.Guna2HtmlLabel12.TabIndex = 0
        Me.Guna2HtmlLabel12.Text = "not received ?"
        '
        'Guna2HtmlLabel11
        '
        Me.Guna2HtmlLabel11.BackColor = System.Drawing.Color.Transparent
        Me.Guna2HtmlLabel11.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Guna2HtmlLabel11.ForeColor = System.Drawing.Color.Navy
        Me.Guna2HtmlLabel11.Location = New System.Drawing.Point(13, 8)
        Me.Guna2HtmlLabel11.Name = "Guna2HtmlLabel11"
        Me.Guna2HtmlLabel11.Size = New System.Drawing.Size(27, 17)
        Me.Guna2HtmlLabel11.TabIndex = 0
        Me.Guna2HtmlLabel11.Text = "OTP"
        '
        'create_pass
        '
        Me.create_pass.BorderRadius = 5
        Me.create_pass.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.create_pass.DefaultText = ""
        Me.create_pass.DisabledState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer))
        Me.create_pass.DisabledState.FillColor = System.Drawing.Color.FromArgb(CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer))
        Me.create_pass.DisabledState.ForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.create_pass.DisabledState.Parent = Me.create_pass
        Me.create_pass.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.create_pass.FocusedState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.create_pass.FocusedState.Parent = Me.create_pass
        Me.create_pass.HoverState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.create_pass.HoverState.Parent = Me.create_pass
        Me.create_pass.Location = New System.Drawing.Point(27, 262)
        Me.create_pass.Name = "create_pass"
        Me.create_pass.PasswordChar = Global.Microsoft.VisualBasic.ChrW(42)
        Me.create_pass.PlaceholderText = "CREATE PASSWORD"
        Me.create_pass.SelectedText = ""
        Me.create_pass.ShadowDecoration.Parent = Me.create_pass
        Me.create_pass.Size = New System.Drawing.Size(670, 38)
        Me.create_pass.TabIndex = 2
        '
        'Guna2HtmlLabel13
        '
        Me.Guna2HtmlLabel13.BackColor = System.Drawing.Color.Transparent
        Me.Guna2HtmlLabel13.Location = New System.Drawing.Point(40, 245)
        Me.Guna2HtmlLabel13.Name = "Guna2HtmlLabel13"
        Me.Guna2HtmlLabel13.Size = New System.Drawing.Size(115, 15)
        Me.Guna2HtmlLabel13.TabIndex = 3
        Me.Guna2HtmlLabel13.Text = "CREATE PASSWORD:"
        '
        'confirm_pass
        '
        Me.confirm_pass.BorderRadius = 5
        Me.confirm_pass.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.confirm_pass.DefaultText = ""
        Me.confirm_pass.DisabledState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer))
        Me.confirm_pass.DisabledState.FillColor = System.Drawing.Color.FromArgb(CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer))
        Me.confirm_pass.DisabledState.ForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.confirm_pass.DisabledState.Parent = Me.confirm_pass
        Me.confirm_pass.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.confirm_pass.FocusedState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.confirm_pass.FocusedState.Parent = Me.confirm_pass
        Me.confirm_pass.HoverState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.confirm_pass.HoverState.Parent = Me.confirm_pass
        Me.confirm_pass.Location = New System.Drawing.Point(28, 362)
        Me.confirm_pass.Name = "confirm_pass"
        Me.confirm_pass.PasswordChar = Global.Microsoft.VisualBasic.ChrW(42)
        Me.confirm_pass.PlaceholderText = "CONFIRM PASSWORD"
        Me.confirm_pass.SelectedText = ""
        Me.confirm_pass.ShadowDecoration.Parent = Me.confirm_pass
        Me.confirm_pass.Size = New System.Drawing.Size(670, 38)
        Me.confirm_pass.TabIndex = 2
        '
        'Guna2HtmlLabel14
        '
        Me.Guna2HtmlLabel14.BackColor = System.Drawing.Color.Transparent
        Me.Guna2HtmlLabel14.Location = New System.Drawing.Point(41, 345)
        Me.Guna2HtmlLabel14.Name = "Guna2HtmlLabel14"
        Me.Guna2HtmlLabel14.Size = New System.Drawing.Size(121, 15)
        Me.Guna2HtmlLabel14.TabIndex = 3
        Me.Guna2HtmlLabel14.Text = "CONFIRM PASSWORD:"
        '
        'Guna2Button1
        '
        Me.Guna2Button1.BorderRadius = 5
        Me.Guna2Button1.CheckedState.Parent = Me.Guna2Button1
        Me.Guna2Button1.CustomImages.Parent = Me.Guna2Button1
        Me.Guna2Button1.FillColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.Guna2Button1.Font = New System.Drawing.Font("Segoe UI", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Guna2Button1.ForeColor = System.Drawing.Color.White
        Me.Guna2Button1.HoverState.Parent = Me.Guna2Button1
        Me.Guna2Button1.Location = New System.Drawing.Point(35, 419)
        Me.Guna2Button1.Name = "Guna2Button1"
        Me.Guna2Button1.ShadowDecoration.Parent = Me.Guna2Button1
        Me.Guna2Button1.Size = New System.Drawing.Size(0, 0)
        Me.Guna2Button1.TabIndex = 4
        Me.Guna2Button1.Text = "RESET PASSWORD"
        '
        'reset_btn
        '
        Me.reset_btn.Animated = True
        Me.reset_btn.CheckedState.Parent = Me.reset_btn
        Me.reset_btn.Cursor = System.Windows.Forms.Cursors.Hand
        Me.reset_btn.CustomImages.Parent = Me.reset_btn
        Me.reset_btn.FillColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.reset_btn.FillColor2 = System.Drawing.Color.Navy
        Me.reset_btn.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.reset_btn.ForeColor = System.Drawing.Color.White
        Me.reset_btn.HoverState.Parent = Me.reset_btn
        Me.reset_btn.Image = Global.Bank.My.Resources.Resources.tick
        Me.reset_btn.ImageSize = New System.Drawing.Size(10, 10)
        Me.reset_btn.Location = New System.Drawing.Point(28, 427)
        Me.reset_btn.Name = "reset_btn"
        Me.reset_btn.ShadowDecoration.Parent = Me.reset_btn
        Me.reset_btn.Size = New System.Drawing.Size(666, 51)
        Me.reset_btn.TabIndex = 5
        Me.reset_btn.Text = "RESET PASSWORD"
        '
        'passLabel
        '
        Me.passLabel.BackColor = System.Drawing.Color.Transparent
        Me.passLabel.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.passLabel.Location = New System.Drawing.Point(41, 63)
        Me.passLabel.Name = "passLabel"
        Me.passLabel.Size = New System.Drawing.Size(30, 17)
        Me.passLabel.TabIndex = 6
        Me.passLabel.Text = "Dear"
        '
        'reset_password
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(725, 499)
        Me.Controls.Add(Me.passLabel)
        Me.Controls.Add(Me.reset_btn)
        Me.Controls.Add(Me.Guna2Button1)
        Me.Controls.Add(Me.Guna2HtmlLabel14)
        Me.Controls.Add(Me.Guna2HtmlLabel9)
        Me.Controls.Add(Me.Guna2HtmlLabel13)
        Me.Controls.Add(Me.confirm_pass)
        Me.Controls.Add(Me.create_pass)
        Me.Controls.Add(Me.Guna2HtmlLabel10)
        Me.Controls.Add(Me.otp_txt)
        Me.Controls.Add(Me.Guna2Panel2)
        Me.Controls.Add(Me.Guna2GradientPanel1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.Name = "reset_password"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "reset_password"
        Me.Guna2GradientPanel1.ResumeLayout(False)
        Me.Guna2GradientPanel1.PerformLayout()
        CType(Me.Guna2PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Guna2Panel2.ResumeLayout(False)
        Me.Guna2Panel2.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Guna2GradientPanel1 As Guna.UI2.WinForms.Guna2GradientPanel
    Friend WithEvents Guna2HtmlLabel1 As Guna.UI2.WinForms.Guna2HtmlLabel
    Friend WithEvents exit_home As Guna.UI2.WinForms.Guna2CircleButton
    Friend WithEvents Guna2PictureBox1 As Guna.UI2.WinForms.Guna2PictureBox
    Friend WithEvents Guna2HtmlLabel9 As Guna.UI2.WinForms.Guna2HtmlLabel
    Friend WithEvents otp_txt As Guna.UI2.WinForms.Guna2TextBox
    Friend WithEvents Guna2HtmlLabel10 As Guna.UI2.WinForms.Guna2HtmlLabel
    Friend WithEvents Guna2Panel2 As Guna.UI2.WinForms.Guna2Panel
    Friend WithEvents Guna2HtmlLabel12 As Guna.UI2.WinForms.Guna2HtmlLabel
    Friend WithEvents Guna2HtmlLabel11 As Guna.UI2.WinForms.Guna2HtmlLabel
    Friend WithEvents login_link As System.Windows.Forms.LinkLabel
    Friend WithEvents create_pass As Guna.UI2.WinForms.Guna2TextBox
    Friend WithEvents Guna2HtmlLabel13 As Guna.UI2.WinForms.Guna2HtmlLabel
    Friend WithEvents confirm_pass As Guna.UI2.WinForms.Guna2TextBox
    Friend WithEvents Guna2HtmlLabel14 As Guna.UI2.WinForms.Guna2HtmlLabel
    Friend WithEvents Guna2Button1 As Guna.UI2.WinForms.Guna2Button
    Friend WithEvents reset_btn As Guna.UI2.WinForms.Guna2GradientButton
    Friend WithEvents passLabel As Guna.UI2.WinForms.Guna2HtmlLabel
End Class
