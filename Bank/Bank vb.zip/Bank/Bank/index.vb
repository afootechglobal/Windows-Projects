﻿Public Class index

    Private Sub index_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

        AddHandler userlog.FormClosed, AddressOf Main_FormClosed : AddHandler admin_login.FormClosed, AddressOf admin_FormClosed : AddHandler admin_record.FormClosed, AddressOf record_FormClosed
        AddHandler view_records.FormClosed, AddressOf view_FormClosed : AddHandler customer_record.FormClosed, AddressOf customer_FormClosed : AddHandler loan_form.FormClosed, AddressOf loan_FormClosed
        AddHandler view_customer_records.FormClosed, AddressOf view_customer_FormClosed : AddHandler system_settings.FormClosed, AddressOf settings_FormClosed : AddHandler payment_deposit.FormClosed, AddressOf payment_deposit_FormClosed
        AddHandler loan_schedule.FormClosed, AddressOf Loan_schedule_FormClosed
    End Sub
    Private Sub Main_FormClosed(ByVal sender As Object, ByVal e As FormClosedEventArgs)
        Me.Close()
    End Sub
    Private Sub admin_FormClosed(ByVal sender As Object, ByVal e As FormClosedEventArgs)
        Me.Close()
    End Sub
    Private Sub record_FormClosed(ByVal sender As Object, ByVal e As FormClosedEventArgs)
        Me.Close()
    End Sub
    Private Sub view_FormClosed(ByVal sender As Object, ByVal e As FormClosedEventArgs)
        Me.Close()
    End Sub
    Private Sub customer_FormClosed(ByVal sender As Object, ByVal e As FormClosedEventArgs)
        Me.Close()
    End Sub
    Private Sub loan_FormClosed(ByVal sender As Object, ByVal e As FormClosedEventArgs)
        Me.Close()
    End Sub
    Private Sub view_customer_FormClosed(ByVal sender As Object, ByVal e As FormClosedEventArgs)
        Me.Close()
    End Sub
    Private Sub settings_FormClosed(ByVal sender As Object, ByVal e As FormClosedEventArgs)
        Me.Close()
    End Sub
    Private Sub payment_deposit_FormClosed(ByVal sender As Object, ByVal e As FormClosedEventArgs)
        Me.Close()
    End Sub
    Private Sub Loan_schedule_FormClosed(ByVal sender As Object, ByVal e As FormClosedEventArgs)
        Me.Close()
    End Sub
End Class