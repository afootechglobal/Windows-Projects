﻿Imports MySql.Data.MySqlClient
Imports BCrypt.Net
Public Class change_pass
    Dim reader As MySqlDataReader
    Dim command As MySqlCommand
    Dim query As String
    Private Sub system_update_btn_Click(sender As Object, e As EventArgs) Handles system_update_btn.Click
        If oldPass_txt.Text = "" Or newPass_txt.Text = "" Or confirmPass_txt.Text = "" Then
            MessageBox.Show("ERROR! All fields are Required!", "Bank Application Software", MessageBoxButtons.OK, MessageBoxIcon.Error)
        Else
            Dim connection = functions.connection
            Dim result = functions.getCustomerProfile(userlog.login_customer_id)
            Dim old_password = result.item6.ToString

            If BCrypt.Net.BCrypt.Verify(oldPass_txt.Text, old_password) Then
                If newPass_txt.Text = confirmPass_txt.Text Then
                    connection.open()
                    query = "UPDATE customer_tab SET password=@password WHERE customer_id=@customer_id"
                    command = New MySqlCommand(query, connection)
                    Dim hashedPassword As String = BCrypt.Net.BCrypt.HashPassword(newPass_txt.Text)
                    command.Parameters.AddWithValue("@password", hashedPassword)
                    command.Parameters.AddWithValue("@customer_id", userlog.login_customer_id)
                    reader = command.ExecuteReader
                    connection.Close()
                    MessageBox.Show("SUCCESS! Password has been updated successfully", "Bank Application Software", MessageBoxButtons.OK, MessageBoxIcon.Information)
                    Me.Close()
                    index.Close()
                Else
                    MessageBox.Show("ERROR! New Password don't match with Confirmed Password!", "Bank Application Software", MessageBoxButtons.OK, MessageBoxIcon.Error)
                End If
            Else
                MessageBox.Show("ERROR! Old Password is Incorrect", "Bank Application Software", MessageBoxButtons.OK, MessageBoxIcon.Error)
            End If
        End If
    End Sub

    Private Sub exit_home_Click(sender As Object, e As EventArgs) Handles exit_home.Click
        exit_btn(Me)
        index.Hide()
    End Sub
End Class