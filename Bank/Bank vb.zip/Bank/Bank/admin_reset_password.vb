﻿Imports System.Net.Mail
Imports MySql.Data.MySqlClient
Imports BCrypt.Net

Public Class admin_reset_password
    Dim reader As MySqlDataReader
    Dim command As MySqlCommand
    'Public staff_id As String
    Private Sub exit_home_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles exit_home.Click
        Me.Close()
    End Sub

    Private Sub admin_reset_password_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        fullname_txt.Text = admin_login.fullname
        email_txt.Text = admin_login.email_address
    End Sub

    Private Sub reset_pass_btn_Click(sender As Object, e As EventArgs) Handles reset_pass_btn.Click

        If otp_txt.Text = "" Or create_pass.Text = "" Or confirm_pass.Text = "" Then
            MessageBox.Show("ERROR! All fields are Required", "Bank System Software", MessageBoxButtons.OK, MessageBoxIcon.Error)
        Else
            If create_pass.Text = confirm_pass.Text Then
                Try
                    Dim connection = functions.connection

                    connection.Open()
                    command = New MySqlCommand("SELECT otp FROM staff_tab WHERE otp=@otp AND staff_id=@staff_id", connection)
                    command.Parameters.AddWithValue("@staff_id", admin_login.staff_id)
                    command.Parameters.AddWithValue("@otp", otp_txt.Text)
                    reader = command.ExecuteReader

                    If reader.HasRows Then
                        connection.close()
                        connection.open()
                        command = New MySqlCommand("UPDATE staff_tab SET password=@password WHERE staff_id=@staff_id", connection)
                        command.Parameters.AddWithValue("@staff_id", admin_login.staff_id)
                        Dim hashedPassword As String = BCrypt.Net.BCrypt.HashPassword(create_pass.Text)
                        command.Parameters.AddWithValue("@password", hashedPassword)
                        reader = command.ExecuteReader
                        connection.Close()
                        MessageBox.Show("SUCCESS! Password has been successfully updated", "Bank System Software", MessageBoxButtons.OK, MessageBoxIcon.Information)

                        Me.Hide()
                        index.Hide()
                        admin_login.Show()
                    Else
                        MessageBox.Show("ERROR! OTP not valid", "Bank System Software", MessageBoxButtons.OK, MessageBoxIcon.Error)
                    End If
                Catch ex As Exception
                    MsgBox(ex.ToString)
                End Try
            Else
                MessageBox.Show("ERROR! Create password and confirm password don't match", "Bank System Software", MessageBoxButtons.OK, MessageBoxIcon.Error)
            End If
        End If
    End Sub

    Private Sub resend_otp_LinkClicked(sender As Object, e As LinkLabelLinkClickedEventArgs) Handles resend_otp.LinkClicked
        Dim otp As String = New Random().Next(100000, 999999).ToString()

        Dim connection = functions.connection
        connection.Open()
        command = New MySqlCommand("UPDATE staff_tab SET otp=@otp WHERE staff_id=@staff_id", connection)
        command.Parameters.AddWithValue("@staff_id", admin_login.staff_id)
        command.Parameters.AddWithValue("@otp", otp)
        reader = command.ExecuteReader
        connection.Close()

        MessageBox.Show("SUCCESS! OTP has been successfully been resent", "Bank System Software", MessageBoxButtons.OK, MessageBoxIcon.Information)

    End Sub


End Class