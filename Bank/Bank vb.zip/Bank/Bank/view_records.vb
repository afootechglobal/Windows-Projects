﻿Imports MySql.Data.MySqlClient
Public Class view_records
    Private Sub record_home_btn_Click(sender As Object, e As EventArgs) Handles record_home_btn.Click
        admin_record.Show()
        index.Show()
        Me.Hide()
    End Sub

    Private Sub exit_home_btn_Click(sender As Object, e As EventArgs) Handles exit_home_btn.Click
        exit_btn(Me)
    End Sub

    Private Sub view_records_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        functions.staffRecord()
    End Sub
End Class