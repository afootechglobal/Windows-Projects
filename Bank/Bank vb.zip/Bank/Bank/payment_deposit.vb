﻿Imports MySql.Data.MySqlClient

Public Class payment_deposit
    Dim reader As MySqlDataReader
    Dim command As MySqlCommand
    Dim query As String
    Private Sub exit_home_Click(sender As Object, e As EventArgs) Handles exit_home.Click
        exit_btn(Me)
    End Sub

    Private Sub payment_deposit_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        functions.getCustomerID()
    End Sub

    Private Sub fetch_btn_Click(sender As Object, e As EventArgs) Handles fetch_btn.Click
        transaction_form.Show()
        Me.Hide()
    End Sub

    Private Sub Guna2Button2_Click(sender As Object, e As EventArgs) Handles Guna2Button2.Click
        deposit_txt.Text = ""
    End Sub

    Private Sub deposit_btn_Click(sender As Object, e As EventArgs) Handles deposit_btn.Click
        If profile_id.Text = "SELECT CUSTOMER" Then
            MessageBox.Show("ERROR! Select customer to continue!", "Bank Application Software", MessageBoxButtons.OK, MessageBoxIcon.Error)
        ElseIf deposit_txt.Text = "" Then
            MessageBox.Show("ERROR! All fields are required", "Bank Application Software", MessageBoxButtons.OK, MessageBoxIcon.Error)
        Else
            Dim deposit As Double = Convert.ToDouble(deposit_txt.Text).ToString
            Dim customer_id = profile_id.SelectedValue
            functions.deposit(deposit, customer_id, 1)
        End If
    End Sub

    Private Sub deposit_txt_KeyPress(sender As Object, e As KeyPressEventArgs) Handles deposit_txt.KeyPress
        numCheck(e)
    End Sub
End Class