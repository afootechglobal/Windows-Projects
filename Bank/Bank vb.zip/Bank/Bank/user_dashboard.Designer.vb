﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class user_dashboard
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Guna2Panel1 = New Guna.UI2.WinForms.Guna2Panel()
        Me.logout_btn = New Guna.UI2.WinForms.Guna2Button()
        Me.Guna2HtmlLabel11 = New Guna.UI2.WinForms.Guna2HtmlLabel()
        Me.profilename_panel = New Guna.UI2.WinForms.Guna2Panel()
        Me.passport = New Guna.UI2.WinForms.Guna2PictureBox()
        Me.Guna2PictureBox2 = New Guna.UI2.WinForms.Guna2PictureBox()
        Me.fullname_label = New Guna.UI2.WinForms.Guna2HtmlLabel()
        Me.Guna2HtmlLabel7 = New Guna.UI2.WinForms.Guna2HtmlLabel()
        Me.Guna2HtmlLabel3 = New Guna.UI2.WinForms.Guna2HtmlLabel()
        Me.status_label = New Guna.UI2.WinForms.Guna2HtmlLabel()
        Me.Guna2HtmlLabel5 = New Guna.UI2.WinForms.Guna2HtmlLabel()
        Me.last_login_label = New Guna.UI2.WinForms.Guna2HtmlLabel()
        Me.Guna2HtmlLabel8 = New Guna.UI2.WinForms.Guna2HtmlLabel()
        Me.time_panel = New Guna.UI2.WinForms.Guna2CustomGradientPanel()
        Me.loan_bal_txt = New Guna.UI2.WinForms.Guna2HtmlLabel()
        Me.acct_bal_txt = New Guna.UI2.WinForms.Guna2HtmlLabel()
        Me.Guna2HtmlLabel2 = New Guna.UI2.WinForms.Guna2HtmlLabel()
        Me.Guna2HtmlLabel10 = New Guna.UI2.WinForms.Guna2HtmlLabel()
        Me.Guna2Panel2 = New Guna.UI2.WinForms.Guna2Panel()
        Me.Guna2Panel3 = New Guna.UI2.WinForms.Guna2Panel()
        Me.change_password_btn = New Guna.UI2.WinForms.Guna2Button()
        Me.loan_schedule = New Guna.UI2.WinForms.Guna2Button()
        Me.cust_deposit = New Guna.UI2.WinForms.Guna2Button()
        Me.request_loan = New Guna.UI2.WinForms.Guna2Button()
        Me.dashboard_btn = New Guna.UI2.WinForms.Guna2Button()
        Me.repay_btn = New Guna.UI2.WinForms.Guna2Button()
        Me.Guna2Panel1.SuspendLayout()
        Me.profilename_panel.SuspendLayout()
        CType(Me.passport, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Guna2PictureBox2, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.time_panel.SuspendLayout()
        Me.Guna2Panel2.SuspendLayout()
        Me.Guna2Panel3.SuspendLayout()
        Me.SuspendLayout()
        '
        'Guna2Panel1
        '
        Me.Guna2Panel1.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Guna2Panel1.BackColor = System.Drawing.Color.FromArgb(CType(CType(47, Byte), Integer), CType(CType(60, Byte), Integer), CType(CType(77, Byte), Integer))
        Me.Guna2Panel1.Controls.Add(Me.logout_btn)
        Me.Guna2Panel1.Controls.Add(Me.Guna2HtmlLabel11)
        Me.Guna2Panel1.Location = New System.Drawing.Point(0, 1)
        Me.Guna2Panel1.Name = "Guna2Panel1"
        Me.Guna2Panel1.ShadowDecoration.Depth = 40
        Me.Guna2Panel1.ShadowDecoration.Enabled = True
        Me.Guna2Panel1.ShadowDecoration.Parent = Me.Guna2Panel1
        Me.Guna2Panel1.ShadowDecoration.Shadow = New System.Windows.Forms.Padding(0, 0, 0, 3)
        Me.Guna2Panel1.Size = New System.Drawing.Size(1371, 75)
        Me.Guna2Panel1.TabIndex = 1
        '
        'logout_btn
        '
        Me.logout_btn.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.logout_btn.Animated = True
        Me.logout_btn.BackColor = System.Drawing.Color.Transparent
        Me.logout_btn.BorderRadius = 4
        Me.logout_btn.CheckedState.Parent = Me.logout_btn
        Me.logout_btn.Cursor = System.Windows.Forms.Cursors.Hand
        Me.logout_btn.CustomImages.Parent = Me.logout_btn
        Me.logout_btn.FillColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.logout_btn.Font = New System.Drawing.Font("Segoe UI Semibold", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.logout_btn.ForeColor = System.Drawing.Color.White
        Me.logout_btn.HoverState.FillColor = System.Drawing.Color.Maroon
        Me.logout_btn.HoverState.Parent = Me.logout_btn
        Me.logout_btn.Image = Global.Bank.My.Resources.Resources.logout_1_
        Me.logout_btn.Location = New System.Drawing.Point(1239, 20)
        Me.logout_btn.Name = "logout_btn"
        Me.logout_btn.ShadowDecoration.Enabled = True
        Me.logout_btn.ShadowDecoration.Parent = Me.logout_btn
        Me.logout_btn.ShadowDecoration.Shadow = New System.Windows.Forms.Padding(3)
        Me.logout_btn.Size = New System.Drawing.Size(119, 39)
        Me.logout_btn.TabIndex = 2
        Me.logout_btn.Text = "LOG-OUT"
        '
        'Guna2HtmlLabel11
        '
        Me.Guna2HtmlLabel11.BackColor = System.Drawing.Color.Transparent
        Me.Guna2HtmlLabel11.Font = New System.Drawing.Font("Microsoft Tai Le", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Guna2HtmlLabel11.ForeColor = System.Drawing.Color.White
        Me.Guna2HtmlLabel11.Location = New System.Drawing.Point(48, 29)
        Me.Guna2HtmlLabel11.Name = "Guna2HtmlLabel11"
        Me.Guna2HtmlLabel11.Size = New System.Drawing.Size(158, 29)
        Me.Guna2HtmlLabel11.TabIndex = 1
        Me.Guna2HtmlLabel11.Text = "User Dashboard"
        '
        'profilename_panel
        '
        Me.profilename_panel.BackColor = System.Drawing.Color.Transparent
        Me.profilename_panel.BorderColor = System.Drawing.Color.Transparent
        Me.profilename_panel.BorderRadius = 6
        Me.profilename_panel.BorderThickness = 2
        Me.profilename_panel.Controls.Add(Me.passport)
        Me.profilename_panel.Controls.Add(Me.Guna2PictureBox2)
        Me.profilename_panel.Controls.Add(Me.fullname_label)
        Me.profilename_panel.Controls.Add(Me.Guna2HtmlLabel7)
        Me.profilename_panel.Controls.Add(Me.Guna2HtmlLabel3)
        Me.profilename_panel.Controls.Add(Me.status_label)
        Me.profilename_panel.Controls.Add(Me.Guna2HtmlLabel5)
        Me.profilename_panel.Controls.Add(Me.last_login_label)
        Me.profilename_panel.Controls.Add(Me.Guna2HtmlLabel8)
        Me.profilename_panel.CustomBorderColor = System.Drawing.Color.Transparent
        Me.profilename_panel.FillColor = System.Drawing.Color.White
        Me.profilename_panel.Location = New System.Drawing.Point(295, 79)
        Me.profilename_panel.Name = "profilename_panel"
        Me.profilename_panel.ShadowDecoration.Parent = Me.profilename_panel
        Me.profilename_panel.Size = New System.Drawing.Size(749, 77)
        Me.profilename_panel.TabIndex = 3
        '
        'passport
        '
        Me.passport.Image = Global.Bank.My.Resources.Resources.person
        Me.passport.Location = New System.Drawing.Point(10, 8)
        Me.passport.Name = "passport"
        Me.passport.ShadowDecoration.Parent = Me.passport
        Me.passport.Size = New System.Drawing.Size(69, 61)
        Me.passport.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.passport.TabIndex = 5
        Me.passport.TabStop = False
        '
        'Guna2PictureBox2
        '
        Me.Guna2PictureBox2.Image = Global.Bank.My.Resources.Resources.hand
        Me.Guna2PictureBox2.Location = New System.Drawing.Point(186, 1)
        Me.Guna2PictureBox2.Name = "Guna2PictureBox2"
        Me.Guna2PictureBox2.ShadowDecoration.Parent = Me.Guna2PictureBox2
        Me.Guna2PictureBox2.Size = New System.Drawing.Size(33, 28)
        Me.Guna2PictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.Guna2PictureBox2.TabIndex = 2
        Me.Guna2PictureBox2.TabStop = False
        '
        'fullname_label
        '
        Me.fullname_label.BackColor = System.Drawing.Color.Transparent
        Me.fullname_label.Font = New System.Drawing.Font("Microsoft Tai Le", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.fullname_label.ForeColor = System.Drawing.Color.DimGray
        Me.fullname_label.Location = New System.Drawing.Point(93, 26)
        Me.fullname_label.Name = "fullname_label"
        Me.fullname_label.Size = New System.Drawing.Size(33, 28)
        Me.fullname_label.TabIndex = 1
        Me.fullname_label.Text = "xxx"
        '
        'Guna2HtmlLabel7
        '
        Me.Guna2HtmlLabel7.BackColor = System.Drawing.Color.Transparent
        Me.Guna2HtmlLabel7.Font = New System.Drawing.Font("Microsoft Tai Le", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Guna2HtmlLabel7.ForeColor = System.Drawing.Color.Black
        Me.Guna2HtmlLabel7.Location = New System.Drawing.Point(338, 50)
        Me.Guna2HtmlLabel7.Name = "Guna2HtmlLabel7"
        Me.Guna2HtmlLabel7.Size = New System.Drawing.Size(6, 18)
        Me.Guna2HtmlLabel7.TabIndex = 1
        Me.Guna2HtmlLabel7.Text = "|"
        '
        'Guna2HtmlLabel3
        '
        Me.Guna2HtmlLabel3.BackColor = System.Drawing.Color.Transparent
        Me.Guna2HtmlLabel3.Font = New System.Drawing.Font("Microsoft Tai Le", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Guna2HtmlLabel3.ForeColor = System.Drawing.Color.Black
        Me.Guna2HtmlLabel3.Location = New System.Drawing.Point(92, 4)
        Me.Guna2HtmlLabel3.Name = "Guna2HtmlLabel3"
        Me.Guna2HtmlLabel3.Size = New System.Drawing.Size(90, 28)
        Me.Guna2HtmlLabel3.TabIndex = 1
        Me.Guna2HtmlLabel3.Text = "Welcome"
        '
        'status_label
        '
        Me.status_label.BackColor = System.Drawing.Color.Transparent
        Me.status_label.Font = New System.Drawing.Font("Microsoft Tai Le", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.status_label.ForeColor = System.Drawing.Color.Navy
        Me.status_label.Location = New System.Drawing.Point(390, 51)
        Me.status_label.Name = "status_label"
        Me.status_label.Size = New System.Drawing.Size(37, 18)
        Me.status_label.TabIndex = 1
        Me.status_label.Text = "Active"
        '
        'Guna2HtmlLabel5
        '
        Me.Guna2HtmlLabel5.BackColor = System.Drawing.Color.Transparent
        Me.Guna2HtmlLabel5.Font = New System.Drawing.Font("Microsoft Tai Le", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Guna2HtmlLabel5.ForeColor = System.Drawing.Color.Black
        Me.Guna2HtmlLabel5.Location = New System.Drawing.Point(95, 51)
        Me.Guna2HtmlLabel5.Name = "Guna2HtmlLabel5"
        Me.Guna2HtmlLabel5.Size = New System.Drawing.Size(96, 18)
        Me.Guna2HtmlLabel5.TabIndex = 1
        Me.Guna2HtmlLabel5.Text = "Last Login Date:"
        '
        'last_login_label
        '
        Me.last_login_label.BackColor = System.Drawing.Color.Transparent
        Me.last_login_label.Font = New System.Drawing.Font("Microsoft Tai Le", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.last_login_label.ForeColor = System.Drawing.Color.Navy
        Me.last_login_label.Location = New System.Drawing.Point(194, 52)
        Me.last_login_label.Name = "last_login_label"
        Me.last_login_label.Size = New System.Drawing.Size(121, 18)
        Me.last_login_label.TabIndex = 1
        Me.last_login_label.Text = "2024-11-20 20:18:55"
        '
        'Guna2HtmlLabel8
        '
        Me.Guna2HtmlLabel8.BackColor = System.Drawing.Color.Transparent
        Me.Guna2HtmlLabel8.Font = New System.Drawing.Font("Microsoft Tai Le", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Guna2HtmlLabel8.ForeColor = System.Drawing.Color.Black
        Me.Guna2HtmlLabel8.Location = New System.Drawing.Point(350, 51)
        Me.Guna2HtmlLabel8.Name = "Guna2HtmlLabel8"
        Me.Guna2HtmlLabel8.Size = New System.Drawing.Size(41, 18)
        Me.Guna2HtmlLabel8.TabIndex = 1
        Me.Guna2HtmlLabel8.Text = "Status:"
        '
        'time_panel
        '
        Me.time_panel.BackColor = System.Drawing.Color.Transparent
        Me.time_panel.BorderRadius = 7
        Me.time_panel.BorderThickness = 2
        Me.time_panel.Controls.Add(Me.loan_bal_txt)
        Me.time_panel.Controls.Add(Me.acct_bal_txt)
        Me.time_panel.Controls.Add(Me.Guna2HtmlLabel2)
        Me.time_panel.Controls.Add(Me.Guna2HtmlLabel10)
        Me.time_panel.Location = New System.Drawing.Point(1052, 79)
        Me.time_panel.Name = "time_panel"
        Me.time_panel.ShadowDecoration.Parent = Me.time_panel
        Me.time_panel.Size = New System.Drawing.Size(308, 77)
        Me.time_panel.TabIndex = 4
        '
        'loan_bal_txt
        '
        Me.loan_bal_txt.BackColor = System.Drawing.Color.Transparent
        Me.loan_bal_txt.Font = New System.Drawing.Font("Microsoft Tai Le", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.loan_bal_txt.ForeColor = System.Drawing.Color.Black
        Me.loan_bal_txt.Location = New System.Drawing.Point(169, 34)
        Me.loan_bal_txt.Name = "loan_bal_txt"
        Me.loan_bal_txt.Size = New System.Drawing.Size(40, 23)
        Me.loan_bal_txt.TabIndex = 1
        Me.loan_bal_txt.Text = "NGN"
        '
        'acct_bal_txt
        '
        Me.acct_bal_txt.BackColor = System.Drawing.Color.Transparent
        Me.acct_bal_txt.Font = New System.Drawing.Font("Microsoft Tai Le", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.acct_bal_txt.ForeColor = System.Drawing.Color.Black
        Me.acct_bal_txt.Location = New System.Drawing.Point(19, 34)
        Me.acct_bal_txt.Name = "acct_bal_txt"
        Me.acct_bal_txt.Size = New System.Drawing.Size(40, 23)
        Me.acct_bal_txt.TabIndex = 1
        Me.acct_bal_txt.Text = "NGN"
        '
        'Guna2HtmlLabel2
        '
        Me.Guna2HtmlLabel2.BackColor = System.Drawing.Color.Transparent
        Me.Guna2HtmlLabel2.Font = New System.Drawing.Font("Microsoft YaHei", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Guna2HtmlLabel2.ForeColor = System.Drawing.Color.Black
        Me.Guna2HtmlLabel2.Location = New System.Drawing.Point(165, 9)
        Me.Guna2HtmlLabel2.Name = "Guna2HtmlLabel2"
        Me.Guna2HtmlLabel2.Size = New System.Drawing.Size(84, 21)
        Me.Guna2HtmlLabel2.TabIndex = 1
        Me.Guna2HtmlLabel2.Text = "Loan Balance"
        '
        'Guna2HtmlLabel10
        '
        Me.Guna2HtmlLabel10.BackColor = System.Drawing.Color.Transparent
        Me.Guna2HtmlLabel10.Font = New System.Drawing.Font("Microsoft YaHei", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Guna2HtmlLabel10.ForeColor = System.Drawing.Color.Black
        Me.Guna2HtmlLabel10.Location = New System.Drawing.Point(15, 9)
        Me.Guna2HtmlLabel10.Name = "Guna2HtmlLabel10"
        Me.Guna2HtmlLabel10.Size = New System.Drawing.Size(106, 21)
        Me.Guna2HtmlLabel10.TabIndex = 1
        Me.Guna2HtmlLabel10.Text = "Account Balance"
        '
        'Guna2Panel2
        '
        Me.Guna2Panel2.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.Guna2Panel2.Controls.Add(Me.Guna2Panel3)
        Me.Guna2Panel2.Location = New System.Drawing.Point(-2, 75)
        Me.Guna2Panel2.Name = "Guna2Panel2"
        Me.Guna2Panel2.ShadowDecoration.Parent = Me.Guna2Panel2
        Me.Guna2Panel2.Size = New System.Drawing.Size(281, 563)
        Me.Guna2Panel2.TabIndex = 5
        '
        'Guna2Panel3
        '
        Me.Guna2Panel3.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.Guna2Panel3.Controls.Add(Me.change_password_btn)
        Me.Guna2Panel3.Controls.Add(Me.repay_btn)
        Me.Guna2Panel3.Controls.Add(Me.loan_schedule)
        Me.Guna2Panel3.Controls.Add(Me.cust_deposit)
        Me.Guna2Panel3.Controls.Add(Me.request_loan)
        Me.Guna2Panel3.Controls.Add(Me.dashboard_btn)
        Me.Guna2Panel3.CustomBorderColor = System.Drawing.Color.Gray
        Me.Guna2Panel3.Location = New System.Drawing.Point(25, 13)
        Me.Guna2Panel3.Name = "Guna2Panel3"
        Me.Guna2Panel3.ShadowDecoration.Parent = Me.Guna2Panel3
        Me.Guna2Panel3.Size = New System.Drawing.Size(247, 547)
        Me.Guna2Panel3.TabIndex = 4
        '
        'change_password_btn
        '
        Me.change_password_btn.Animated = True
        Me.change_password_btn.BorderRadius = 5
        Me.change_password_btn.CheckedState.Parent = Me.change_password_btn
        Me.change_password_btn.Cursor = System.Windows.Forms.Cursors.Hand
        Me.change_password_btn.CustomBorderColor = System.Drawing.Color.FromArgb(CType(CType(47, Byte), Integer), CType(CType(60, Byte), Integer), CType(CType(77, Byte), Integer))
        Me.change_password_btn.CustomImages.Parent = Me.change_password_btn
        Me.change_password_btn.FillColor = System.Drawing.Color.DarkGray
        Me.change_password_btn.Font = New System.Drawing.Font("Segoe UI", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.change_password_btn.ForeColor = System.Drawing.Color.White
        Me.change_password_btn.HoverState.Parent = Me.change_password_btn
        Me.change_password_btn.Location = New System.Drawing.Point(1, 457)
        Me.change_password_btn.Name = "change_password_btn"
        Me.change_password_btn.ShadowDecoration.Parent = Me.change_password_btn
        Me.change_password_btn.Size = New System.Drawing.Size(244, 52)
        Me.change_password_btn.TabIndex = 2
        Me.change_password_btn.Text = "Change Password"
        '
        'loan_schedule
        '
        Me.loan_schedule.Animated = True
        Me.loan_schedule.BorderRadius = 5
        Me.loan_schedule.CheckedState.Parent = Me.loan_schedule
        Me.loan_schedule.Cursor = System.Windows.Forms.Cursors.Hand
        Me.loan_schedule.CustomBorderColor = System.Drawing.Color.FromArgb(CType(CType(47, Byte), Integer), CType(CType(60, Byte), Integer), CType(CType(77, Byte), Integer))
        Me.loan_schedule.CustomImages.Parent = Me.loan_schedule
        Me.loan_schedule.FillColor = System.Drawing.Color.DarkGray
        Me.loan_schedule.Font = New System.Drawing.Font("Segoe UI", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.loan_schedule.ForeColor = System.Drawing.Color.White
        Me.loan_schedule.HoverState.Parent = Me.loan_schedule
        Me.loan_schedule.Location = New System.Drawing.Point(2, 283)
        Me.loan_schedule.Name = "loan_schedule"
        Me.loan_schedule.ShadowDecoration.Parent = Me.loan_schedule
        Me.loan_schedule.Size = New System.Drawing.Size(244, 52)
        Me.loan_schedule.TabIndex = 2
        Me.loan_schedule.Text = "Loan schedule"
        '
        'cust_deposit
        '
        Me.cust_deposit.Animated = True
        Me.cust_deposit.BorderRadius = 5
        Me.cust_deposit.CheckedState.Parent = Me.cust_deposit
        Me.cust_deposit.Cursor = System.Windows.Forms.Cursors.Hand
        Me.cust_deposit.CustomBorderColor = System.Drawing.Color.FromArgb(CType(CType(47, Byte), Integer), CType(CType(60, Byte), Integer), CType(CType(77, Byte), Integer))
        Me.cust_deposit.CustomImages.Parent = Me.cust_deposit
        Me.cust_deposit.FillColor = System.Drawing.Color.DarkGray
        Me.cust_deposit.Font = New System.Drawing.Font("Segoe UI", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cust_deposit.ForeColor = System.Drawing.Color.White
        Me.cust_deposit.HoverState.Parent = Me.cust_deposit
        Me.cust_deposit.Location = New System.Drawing.Point(2, 194)
        Me.cust_deposit.Name = "cust_deposit"
        Me.cust_deposit.ShadowDecoration.Parent = Me.cust_deposit
        Me.cust_deposit.Size = New System.Drawing.Size(244, 52)
        Me.cust_deposit.TabIndex = 2
        Me.cust_deposit.Text = "Deposit"
        '
        'request_loan
        '
        Me.request_loan.Animated = True
        Me.request_loan.BorderRadius = 5
        Me.request_loan.CheckedState.Parent = Me.request_loan
        Me.request_loan.Cursor = System.Windows.Forms.Cursors.Hand
        Me.request_loan.CustomBorderColor = System.Drawing.Color.FromArgb(CType(CType(47, Byte), Integer), CType(CType(60, Byte), Integer), CType(CType(77, Byte), Integer))
        Me.request_loan.CustomImages.Parent = Me.request_loan
        Me.request_loan.FillColor = System.Drawing.Color.DarkGray
        Me.request_loan.Font = New System.Drawing.Font("Segoe UI", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.request_loan.ForeColor = System.Drawing.Color.White
        Me.request_loan.HoverState.Parent = Me.request_loan
        Me.request_loan.Location = New System.Drawing.Point(2, 105)
        Me.request_loan.Name = "request_loan"
        Me.request_loan.ShadowDecoration.Parent = Me.request_loan
        Me.request_loan.Size = New System.Drawing.Size(244, 52)
        Me.request_loan.TabIndex = 2
        Me.request_loan.Text = "Request for loan"
        '
        'dashboard_btn
        '
        Me.dashboard_btn.Animated = True
        Me.dashboard_btn.BorderRadius = 5
        Me.dashboard_btn.CheckedState.Parent = Me.dashboard_btn
        Me.dashboard_btn.Cursor = System.Windows.Forms.Cursors.Hand
        Me.dashboard_btn.CustomBorderColor = System.Drawing.Color.FromArgb(CType(CType(47, Byte), Integer), CType(CType(60, Byte), Integer), CType(CType(77, Byte), Integer))
        Me.dashboard_btn.CustomBorderThickness = New System.Windows.Forms.Padding(2, 0, 0, 0)
        Me.dashboard_btn.CustomImages.Parent = Me.dashboard_btn
        Me.dashboard_btn.FillColor = System.Drawing.Color.DarkGray
        Me.dashboard_btn.Font = New System.Drawing.Font("Segoe UI", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.dashboard_btn.ForeColor = System.Drawing.Color.White
        Me.dashboard_btn.HoverState.Parent = Me.dashboard_btn
        Me.dashboard_btn.Location = New System.Drawing.Point(2, 16)
        Me.dashboard_btn.Name = "dashboard_btn"
        Me.dashboard_btn.ShadowDecoration.Parent = Me.dashboard_btn
        Me.dashboard_btn.Size = New System.Drawing.Size(244, 52)
        Me.dashboard_btn.TabIndex = 2
        Me.dashboard_btn.Text = "Home"
        '
        'repay_btn
        '
        Me.repay_btn.Animated = True
        Me.repay_btn.BorderRadius = 5
        Me.repay_btn.CheckedState.Parent = Me.repay_btn
        Me.repay_btn.Cursor = System.Windows.Forms.Cursors.Hand
        Me.repay_btn.CustomBorderColor = System.Drawing.Color.FromArgb(CType(CType(47, Byte), Integer), CType(CType(60, Byte), Integer), CType(CType(77, Byte), Integer))
        Me.repay_btn.CustomImages.Parent = Me.repay_btn
        Me.repay_btn.FillColor = System.Drawing.Color.DarkGray
        Me.repay_btn.Font = New System.Drawing.Font("Segoe UI", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.repay_btn.ForeColor = System.Drawing.Color.White
        Me.repay_btn.HoverState.Parent = Me.repay_btn
        Me.repay_btn.Location = New System.Drawing.Point(2, 368)
        Me.repay_btn.Name = "repay_btn"
        Me.repay_btn.ShadowDecoration.Parent = Me.repay_btn
        Me.repay_btn.Size = New System.Drawing.Size(244, 52)
        Me.repay_btn.TabIndex = 2
        Me.repay_btn.Text = "Repay Loan"
        '
        'user_dashboard
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackgroundImage = Global.Bank.My.Resources.Resources.pics1
        Me.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.ClientSize = New System.Drawing.Size(1370, 634)
        Me.Controls.Add(Me.Guna2Panel2)
        Me.Controls.Add(Me.time_panel)
        Me.Controls.Add(Me.profilename_panel)
        Me.Controls.Add(Me.Guna2Panel1)
        Me.DoubleBuffered = True
        Me.Name = "user_dashboard"
        Me.ShowInTaskbar = False
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "user_dashboard"
        Me.WindowState = System.Windows.Forms.FormWindowState.Maximized
        Me.Guna2Panel1.ResumeLayout(False)
        Me.Guna2Panel1.PerformLayout()
        Me.profilename_panel.ResumeLayout(False)
        Me.profilename_panel.PerformLayout()
        CType(Me.passport, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Guna2PictureBox2, System.ComponentModel.ISupportInitialize).EndInit()
        Me.time_panel.ResumeLayout(False)
        Me.time_panel.PerformLayout()
        Me.Guna2Panel2.ResumeLayout(False)
        Me.Guna2Panel3.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents Guna2Panel1 As Guna.UI2.WinForms.Guna2Panel
    Friend WithEvents logout_btn As Guna.UI2.WinForms.Guna2Button
    Friend WithEvents Guna2HtmlLabel11 As Guna.UI2.WinForms.Guna2HtmlLabel
    Friend WithEvents profilename_panel As Guna.UI2.WinForms.Guna2Panel
    Friend WithEvents fullname_label As Guna.UI2.WinForms.Guna2HtmlLabel
    Friend WithEvents Guna2HtmlLabel7 As Guna.UI2.WinForms.Guna2HtmlLabel
    Friend WithEvents status_label As Guna.UI2.WinForms.Guna2HtmlLabel
    Friend WithEvents Guna2HtmlLabel5 As Guna.UI2.WinForms.Guna2HtmlLabel
    Friend WithEvents last_login_label As Guna.UI2.WinForms.Guna2HtmlLabel
    Friend WithEvents Guna2HtmlLabel8 As Guna.UI2.WinForms.Guna2HtmlLabel
    Friend WithEvents time_panel As Guna.UI2.WinForms.Guna2CustomGradientPanel
    Friend WithEvents acct_bal_txt As Guna.UI2.WinForms.Guna2HtmlLabel
    Friend WithEvents Guna2HtmlLabel10 As Guna.UI2.WinForms.Guna2HtmlLabel
    Friend WithEvents loan_bal_txt As Guna.UI2.WinForms.Guna2HtmlLabel
    Friend WithEvents Guna2HtmlLabel2 As Guna.UI2.WinForms.Guna2HtmlLabel
    Friend WithEvents passport As Guna.UI2.WinForms.Guna2PictureBox
    Friend WithEvents Guna2PictureBox2 As Guna.UI2.WinForms.Guna2PictureBox
    Friend WithEvents Guna2HtmlLabel3 As Guna.UI2.WinForms.Guna2HtmlLabel
    Friend WithEvents Guna2Panel2 As Guna.UI2.WinForms.Guna2Panel
    Friend WithEvents Guna2Panel3 As Guna.UI2.WinForms.Guna2Panel
    Friend WithEvents dashboard_btn As Guna.UI2.WinForms.Guna2Button
    Friend WithEvents loan_schedule As Guna.UI2.WinForms.Guna2Button
    Friend WithEvents cust_deposit As Guna.UI2.WinForms.Guna2Button
    Friend WithEvents request_loan As Guna.UI2.WinForms.Guna2Button
    Friend WithEvents change_password_btn As Guna.UI2.WinForms.Guna2Button
    Friend WithEvents repay_btn As Guna.UI2.WinForms.Guna2Button
End Class
