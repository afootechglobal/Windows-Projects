﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Admin_dashboard
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Guna2Panel1 = New Guna.UI2.WinForms.Guna2Panel()
        Me.logout_btn = New Guna.UI2.WinForms.Guna2Button()
        Me.Guna2HtmlLabel11 = New Guna.UI2.WinForms.Guna2HtmlLabel()
        Me.Guna2PictureBox2 = New Guna.UI2.WinForms.Guna2PictureBox()
        Me.fullname_label = New Guna.UI2.WinForms.Guna2HtmlLabel()
        Me.status_label = New Guna.UI2.WinForms.Guna2HtmlLabel()
        Me.last_login_label = New Guna.UI2.WinForms.Guna2HtmlLabel()
        Me.Guna2HtmlLabel8 = New Guna.UI2.WinForms.Guna2HtmlLabel()
        Me.Guna2HtmlLabel7 = New Guna.UI2.WinForms.Guna2HtmlLabel()
        Me.Guna2HtmlLabel5 = New Guna.UI2.WinForms.Guna2HtmlLabel()
        Me.date_txt = New Guna.UI2.WinForms.Guna2HtmlLabel()
        Me.Guna2HtmlLabel10 = New Guna.UI2.WinForms.Guna2HtmlLabel()
        Me.time = New Guna.UI2.WinForms.Guna2HtmlLabel()
        Me.Guna2HtmlLabel3 = New Guna.UI2.WinForms.Guna2HtmlLabel()
        Me.Guna2Panel2 = New Guna.UI2.WinForms.Guna2Panel()
        Me.name_label = New Guna.UI2.WinForms.Guna2HtmlLabel()
        Me.Guna2Panel3 = New Guna.UI2.WinForms.Guna2Panel()
        Me.setting_btn = New Guna.UI2.WinForms.Guna2Button()
        Me.deposit_btn = New Guna.UI2.WinForms.Guna2Button()
        Me.loan_btn = New Guna.UI2.WinForms.Guna2Button()
        Me.customer_btn = New Guna.UI2.WinForms.Guna2Button()
        Me.add_staff_btn = New Guna.UI2.WinForms.Guna2Button()
        Me.dashboard_btn = New Guna.UI2.WinForms.Guna2Button()
        Me.role_label = New Guna.UI2.WinForms.Guna2HtmlLabel()
        Me.passport = New Guna.UI2.WinForms.Guna2PictureBox()
        Me.profilename_panel = New Guna.UI2.WinForms.Guna2Panel()
        Me.time_panel = New Guna.UI2.WinForms.Guna2CustomGradientPanel()
        Me.Guna2CustomGradientPanel1 = New Guna.UI2.WinForms.Guna2CustomGradientPanel()
        Me.Guna2GradientPanel4 = New Guna.UI2.WinForms.Guna2GradientPanel()
        Me.total_balance_label = New Guna.UI2.WinForms.Guna2HtmlLabel()
        Me.Guna2HtmlLabel19 = New Guna.UI2.WinForms.Guna2HtmlLabel()
        Me.Guna2GradientPanel3 = New Guna.UI2.WinForms.Guna2GradientPanel()
        Me.total_loan_label = New Guna.UI2.WinForms.Guna2HtmlLabel()
        Me.Guna2HtmlLabel17 = New Guna.UI2.WinForms.Guna2HtmlLabel()
        Me.Guna2GradientPanel2 = New Guna.UI2.WinForms.Guna2GradientPanel()
        Me.total_customer_label = New Guna.UI2.WinForms.Guna2HtmlLabel()
        Me.Guna2HtmlLabel15 = New Guna.UI2.WinForms.Guna2HtmlLabel()
        Me.Guna2GradientPanel1 = New Guna.UI2.WinForms.Guna2GradientPanel()
        Me.total_admin_label = New Guna.UI2.WinForms.Guna2HtmlLabel()
        Me.Guna2HtmlLabel12 = New Guna.UI2.WinForms.Guna2HtmlLabel()
        Me.Guna2Panel1.SuspendLayout()
        CType(Me.Guna2PictureBox2, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Guna2Panel2.SuspendLayout()
        Me.Guna2Panel3.SuspendLayout()
        CType(Me.passport, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.profilename_panel.SuspendLayout()
        Me.time_panel.SuspendLayout()
        Me.Guna2CustomGradientPanel1.SuspendLayout()
        Me.Guna2GradientPanel4.SuspendLayout()
        Me.Guna2GradientPanel3.SuspendLayout()
        Me.Guna2GradientPanel2.SuspendLayout()
        Me.Guna2GradientPanel1.SuspendLayout()
        Me.SuspendLayout()
        '
        'Guna2Panel1
        '
        Me.Guna2Panel1.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Guna2Panel1.BackColor = System.Drawing.Color.WhiteSmoke
        Me.Guna2Panel1.Controls.Add(Me.logout_btn)
        Me.Guna2Panel1.Controls.Add(Me.Guna2HtmlLabel11)
        Me.Guna2Panel1.Location = New System.Drawing.Point(249, 0)
        Me.Guna2Panel1.Name = "Guna2Panel1"
        Me.Guna2Panel1.ShadowDecoration.Depth = 40
        Me.Guna2Panel1.ShadowDecoration.Enabled = True
        Me.Guna2Panel1.ShadowDecoration.Parent = Me.Guna2Panel1
        Me.Guna2Panel1.ShadowDecoration.Shadow = New System.Windows.Forms.Padding(0, 0, 0, 3)
        Me.Guna2Panel1.Size = New System.Drawing.Size(1121, 63)
        Me.Guna2Panel1.TabIndex = 0
        '
        'logout_btn
        '
        Me.logout_btn.Animated = True
        Me.logout_btn.BorderRadius = 4
        Me.logout_btn.CheckedState.Parent = Me.logout_btn
        Me.logout_btn.Cursor = System.Windows.Forms.Cursors.Hand
        Me.logout_btn.CustomImages.Parent = Me.logout_btn
        Me.logout_btn.FillColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.logout_btn.Font = New System.Drawing.Font("Segoe UI Semibold", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.logout_btn.ForeColor = System.Drawing.Color.White
        Me.logout_btn.HoverState.FillColor = System.Drawing.Color.Maroon
        Me.logout_btn.HoverState.Parent = Me.logout_btn
        Me.logout_btn.Image = Global.Bank.My.Resources.Resources.logout_1_
        Me.logout_btn.Location = New System.Drawing.Point(988, 12)
        Me.logout_btn.Name = "logout_btn"
        Me.logout_btn.ShadowDecoration.Parent = Me.logout_btn
        Me.logout_btn.Size = New System.Drawing.Size(119, 39)
        Me.logout_btn.TabIndex = 2
        Me.logout_btn.Text = "LOG-OUT"
        '
        'Guna2HtmlLabel11
        '
        Me.Guna2HtmlLabel11.BackColor = System.Drawing.Color.Transparent
        Me.Guna2HtmlLabel11.Font = New System.Drawing.Font("Microsoft Tai Le", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Guna2HtmlLabel11.ForeColor = System.Drawing.Color.Black
        Me.Guna2HtmlLabel11.Location = New System.Drawing.Point(48, 16)
        Me.Guna2HtmlLabel11.Name = "Guna2HtmlLabel11"
        Me.Guna2HtmlLabel11.Size = New System.Drawing.Size(194, 29)
        Me.Guna2HtmlLabel11.TabIndex = 1
        Me.Guna2HtmlLabel11.Text = "Admin Dashbboard"
        '
        'Guna2PictureBox2
        '
        Me.Guna2PictureBox2.Image = Global.Bank.My.Resources.Resources.hand
        Me.Guna2PictureBox2.Location = New System.Drawing.Point(119, 1)
        Me.Guna2PictureBox2.Name = "Guna2PictureBox2"
        Me.Guna2PictureBox2.ShadowDecoration.Parent = Me.Guna2PictureBox2
        Me.Guna2PictureBox2.Size = New System.Drawing.Size(33, 28)
        Me.Guna2PictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.Guna2PictureBox2.TabIndex = 2
        Me.Guna2PictureBox2.TabStop = False
        '
        'fullname_label
        '
        Me.fullname_label.BackColor = System.Drawing.Color.Transparent
        Me.fullname_label.Font = New System.Drawing.Font("Microsoft Tai Le", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.fullname_label.ForeColor = System.Drawing.Color.Maroon
        Me.fullname_label.Location = New System.Drawing.Point(25, 30)
        Me.fullname_label.Name = "fullname_label"
        Me.fullname_label.Size = New System.Drawing.Size(24, 23)
        Me.fullname_label.TabIndex = 1
        Me.fullname_label.Text = "xxx"
        '
        'status_label
        '
        Me.status_label.BackColor = System.Drawing.Color.Transparent
        Me.status_label.Font = New System.Drawing.Font("Microsoft Tai Le", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.status_label.ForeColor = System.Drawing.Color.Navy
        Me.status_label.Location = New System.Drawing.Point(330, 53)
        Me.status_label.Name = "status_label"
        Me.status_label.Size = New System.Drawing.Size(37, 18)
        Me.status_label.TabIndex = 1
        Me.status_label.Text = "Active"
        '
        'last_login_label
        '
        Me.last_login_label.BackColor = System.Drawing.Color.Transparent
        Me.last_login_label.Font = New System.Drawing.Font("Microsoft Tai Le", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.last_login_label.ForeColor = System.Drawing.Color.Navy
        Me.last_login_label.Location = New System.Drawing.Point(125, 54)
        Me.last_login_label.Name = "last_login_label"
        Me.last_login_label.Size = New System.Drawing.Size(121, 18)
        Me.last_login_label.TabIndex = 1
        Me.last_login_label.Text = "2024-11-20 20:18:55"
        '
        'Guna2HtmlLabel8
        '
        Me.Guna2HtmlLabel8.BackColor = System.Drawing.Color.Transparent
        Me.Guna2HtmlLabel8.Font = New System.Drawing.Font("Microsoft Tai Le", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Guna2HtmlLabel8.ForeColor = System.Drawing.Color.Black
        Me.Guna2HtmlLabel8.Location = New System.Drawing.Point(290, 53)
        Me.Guna2HtmlLabel8.Name = "Guna2HtmlLabel8"
        Me.Guna2HtmlLabel8.Size = New System.Drawing.Size(41, 18)
        Me.Guna2HtmlLabel8.TabIndex = 1
        Me.Guna2HtmlLabel8.Text = "Status:"
        '
        'Guna2HtmlLabel7
        '
        Me.Guna2HtmlLabel7.BackColor = System.Drawing.Color.Transparent
        Me.Guna2HtmlLabel7.Font = New System.Drawing.Font("Microsoft Tai Le", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Guna2HtmlLabel7.ForeColor = System.Drawing.Color.Black
        Me.Guna2HtmlLabel7.Location = New System.Drawing.Point(273, 52)
        Me.Guna2HtmlLabel7.Name = "Guna2HtmlLabel7"
        Me.Guna2HtmlLabel7.Size = New System.Drawing.Size(6, 18)
        Me.Guna2HtmlLabel7.TabIndex = 1
        Me.Guna2HtmlLabel7.Text = "|"
        '
        'Guna2HtmlLabel5
        '
        Me.Guna2HtmlLabel5.BackColor = System.Drawing.Color.Transparent
        Me.Guna2HtmlLabel5.Font = New System.Drawing.Font("Microsoft Tai Le", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Guna2HtmlLabel5.ForeColor = System.Drawing.Color.Black
        Me.Guna2HtmlLabel5.Location = New System.Drawing.Point(26, 53)
        Me.Guna2HtmlLabel5.Name = "Guna2HtmlLabel5"
        Me.Guna2HtmlLabel5.Size = New System.Drawing.Size(96, 18)
        Me.Guna2HtmlLabel5.TabIndex = 1
        Me.Guna2HtmlLabel5.Text = "Last Login Date:"
        '
        'date_txt
        '
        Me.date_txt.BackColor = System.Drawing.Color.Transparent
        Me.date_txt.Font = New System.Drawing.Font("Microsoft Tai Le", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.date_txt.ForeColor = System.Drawing.Color.Black
        Me.date_txt.Location = New System.Drawing.Point(19, 54)
        Me.date_txt.Name = "date_txt"
        Me.date_txt.Size = New System.Drawing.Size(64, 16)
        Me.date_txt.TabIndex = 1
        Me.date_txt.Text = "wednesday,"
        '
        'Guna2HtmlLabel10
        '
        Me.Guna2HtmlLabel10.BackColor = System.Drawing.Color.Transparent
        Me.Guna2HtmlLabel10.Font = New System.Drawing.Font("Microsoft Tai Le", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Guna2HtmlLabel10.ForeColor = System.Drawing.Color.Black
        Me.Guna2HtmlLabel10.Location = New System.Drawing.Point(12, 6)
        Me.Guna2HtmlLabel10.Name = "Guna2HtmlLabel10"
        Me.Guna2HtmlLabel10.Size = New System.Drawing.Size(71, 16)
        Me.Guna2HtmlLabel10.TabIndex = 1
        Me.Guna2HtmlLabel10.Text = "Current Time:"
        '
        'time
        '
        Me.time.BackColor = System.Drawing.Color.Transparent
        Me.time.Font = New System.Drawing.Font("Microsoft Tai Le", 22.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.time.ForeColor = System.Drawing.Color.DarkRed
        Me.time.Location = New System.Drawing.Point(13, 20)
        Me.time.Name = "time"
        Me.time.Size = New System.Drawing.Size(79, 39)
        Me.time.TabIndex = 1
        Me.time.Text = "10:15"
        '
        'Guna2HtmlLabel3
        '
        Me.Guna2HtmlLabel3.BackColor = System.Drawing.Color.Transparent
        Me.Guna2HtmlLabel3.Font = New System.Drawing.Font("Microsoft Tai Le", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Guna2HtmlLabel3.ForeColor = System.Drawing.Color.Black
        Me.Guna2HtmlLabel3.Location = New System.Drawing.Point(23, 5)
        Me.Guna2HtmlLabel3.Name = "Guna2HtmlLabel3"
        Me.Guna2HtmlLabel3.Size = New System.Drawing.Size(90, 28)
        Me.Guna2HtmlLabel3.TabIndex = 1
        Me.Guna2HtmlLabel3.Text = "Welcome"
        '
        'Guna2Panel2
        '
        Me.Guna2Panel2.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.Guna2Panel2.BackColor = System.Drawing.Color.FromArgb(CType(CType(47, Byte), Integer), CType(CType(60, Byte), Integer), CType(CType(77, Byte), Integer))
        Me.Guna2Panel2.Controls.Add(Me.name_label)
        Me.Guna2Panel2.Controls.Add(Me.Guna2Panel3)
        Me.Guna2Panel2.Controls.Add(Me.role_label)
        Me.Guna2Panel2.Controls.Add(Me.passport)
        Me.Guna2Panel2.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Guna2Panel2.Location = New System.Drawing.Point(0, 0)
        Me.Guna2Panel2.Name = "Guna2Panel2"
        Me.Guna2Panel2.ShadowDecoration.Depth = 10
        Me.Guna2Panel2.ShadowDecoration.Enabled = True
        Me.Guna2Panel2.ShadowDecoration.Parent = Me.Guna2Panel2
        Me.Guna2Panel2.ShadowDecoration.Shadow = New System.Windows.Forms.Padding(0, 0, 0, 5)
        Me.Guna2Panel2.Size = New System.Drawing.Size(256, 750)
        Me.Guna2Panel2.TabIndex = 1
        '
        'name_label
        '
        Me.name_label.BackColor = System.Drawing.Color.Transparent
        Me.name_label.Font = New System.Drawing.Font("Microsoft Tai Le", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.name_label.ForeColor = System.Drawing.Color.White
        Me.name_label.Location = New System.Drawing.Point(9, 156)
        Me.name_label.Name = "name_label"
        Me.name_label.Size = New System.Drawing.Size(225, 23)
        Me.name_label.TabIndex = 4
        Me.name_label.Text = "OGUNYEMI FORTUNE OPEYEMI"
        Me.name_label.TextAlignment = System.Drawing.ContentAlignment.TopCenter
        '
        'Guna2Panel3
        '
        Me.Guna2Panel3.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.Guna2Panel3.Controls.Add(Me.setting_btn)
        Me.Guna2Panel3.Controls.Add(Me.deposit_btn)
        Me.Guna2Panel3.Controls.Add(Me.loan_btn)
        Me.Guna2Panel3.Controls.Add(Me.customer_btn)
        Me.Guna2Panel3.Controls.Add(Me.add_staff_btn)
        Me.Guna2Panel3.Controls.Add(Me.dashboard_btn)
        Me.Guna2Panel3.CustomBorderColor = System.Drawing.Color.Gray
        Me.Guna2Panel3.CustomBorderThickness = New System.Windows.Forms.Padding(0, 2, 0, 0)
        Me.Guna2Panel3.Location = New System.Drawing.Point(4, 209)
        Me.Guna2Panel3.Name = "Guna2Panel3"
        Me.Guna2Panel3.ShadowDecoration.Parent = Me.Guna2Panel3
        Me.Guna2Panel3.Size = New System.Drawing.Size(247, 538)
        Me.Guna2Panel3.TabIndex = 3
        '
        'setting_btn
        '
        Me.setting_btn.Animated = True
        Me.setting_btn.CheckedState.Parent = Me.setting_btn
        Me.setting_btn.Cursor = System.Windows.Forms.Cursors.Hand
        Me.setting_btn.CustomImages.Parent = Me.setting_btn
        Me.setting_btn.FillColor = System.Drawing.Color.DarkGray
        Me.setting_btn.Font = New System.Drawing.Font("Segoe UI", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.setting_btn.ForeColor = System.Drawing.Color.White
        Me.setting_btn.HoverState.Parent = Me.setting_btn
        Me.setting_btn.Image = Global.Bank.My.Resources.Resources.settings
        Me.setting_btn.Location = New System.Drawing.Point(8, 359)
        Me.setting_btn.Name = "setting_btn"
        Me.setting_btn.ShadowDecoration.Parent = Me.setting_btn
        Me.setting_btn.Size = New System.Drawing.Size(226, 52)
        Me.setting_btn.TabIndex = 2
        Me.setting_btn.Text = "Settings"
        '
        'deposit_btn
        '
        Me.deposit_btn.Animated = True
        Me.deposit_btn.CheckedState.Parent = Me.deposit_btn
        Me.deposit_btn.Cursor = System.Windows.Forms.Cursors.Hand
        Me.deposit_btn.CustomImages.Parent = Me.deposit_btn
        Me.deposit_btn.FillColor = System.Drawing.Color.DarkGray
        Me.deposit_btn.Font = New System.Drawing.Font("Segoe UI", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.deposit_btn.ForeColor = System.Drawing.Color.White
        Me.deposit_btn.HoverState.Parent = Me.deposit_btn
        Me.deposit_btn.Image = Global.Bank.My.Resources.Resources.deposit
        Me.deposit_btn.Location = New System.Drawing.Point(8, 293)
        Me.deposit_btn.Name = "deposit_btn"
        Me.deposit_btn.ShadowDecoration.Parent = Me.deposit_btn
        Me.deposit_btn.Size = New System.Drawing.Size(226, 52)
        Me.deposit_btn.TabIndex = 2
        Me.deposit_btn.Text = "Deposit"
        '
        'loan_btn
        '
        Me.loan_btn.Animated = True
        Me.loan_btn.CheckedState.Parent = Me.loan_btn
        Me.loan_btn.Cursor = System.Windows.Forms.Cursors.Hand
        Me.loan_btn.CustomImages.Parent = Me.loan_btn
        Me.loan_btn.FillColor = System.Drawing.Color.DarkGray
        Me.loan_btn.Font = New System.Drawing.Font("Segoe UI", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.loan_btn.ForeColor = System.Drawing.Color.White
        Me.loan_btn.HoverState.Parent = Me.loan_btn
        Me.loan_btn.Image = Global.Bank.My.Resources.Resources.personal
        Me.loan_btn.Location = New System.Drawing.Point(8, 225)
        Me.loan_btn.Name = "loan_btn"
        Me.loan_btn.ShadowDecoration.Parent = Me.loan_btn
        Me.loan_btn.Size = New System.Drawing.Size(226, 52)
        Me.loan_btn.TabIndex = 2
        Me.loan_btn.Text = "View loan"
        '
        'customer_btn
        '
        Me.customer_btn.Animated = True
        Me.customer_btn.CheckedState.Parent = Me.customer_btn
        Me.customer_btn.Cursor = System.Windows.Forms.Cursors.Hand
        Me.customer_btn.CustomImages.Parent = Me.customer_btn
        Me.customer_btn.FillColor = System.Drawing.Color.DarkGray
        Me.customer_btn.Font = New System.Drawing.Font("Segoe UI", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.customer_btn.ForeColor = System.Drawing.Color.White
        Me.customer_btn.HoverState.Parent = Me.customer_btn
        Me.customer_btn.Image = Global.Bank.My.Resources.Resources.add_group
        Me.customer_btn.Location = New System.Drawing.Point(8, 158)
        Me.customer_btn.Name = "customer_btn"
        Me.customer_btn.ShadowDecoration.Parent = Me.customer_btn
        Me.customer_btn.Size = New System.Drawing.Size(226, 52)
        Me.customer_btn.TabIndex = 2
        Me.customer_btn.Text = "Add Customers "
        '
        'add_staff_btn
        '
        Me.add_staff_btn.Animated = True
        Me.add_staff_btn.CheckedState.Parent = Me.add_staff_btn
        Me.add_staff_btn.Cursor = System.Windows.Forms.Cursors.Hand
        Me.add_staff_btn.CustomImages.Parent = Me.add_staff_btn
        Me.add_staff_btn.FillColor = System.Drawing.Color.DarkGray
        Me.add_staff_btn.Font = New System.Drawing.Font("Segoe UI", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.add_staff_btn.ForeColor = System.Drawing.Color.White
        Me.add_staff_btn.HoverState.Parent = Me.add_staff_btn
        Me.add_staff_btn.Image = Global.Bank.My.Resources.Resources.add_user
        Me.add_staff_btn.Location = New System.Drawing.Point(8, 92)
        Me.add_staff_btn.Name = "add_staff_btn"
        Me.add_staff_btn.ShadowDecoration.Parent = Me.add_staff_btn
        Me.add_staff_btn.Size = New System.Drawing.Size(226, 52)
        Me.add_staff_btn.TabIndex = 2
        Me.add_staff_btn.Text = "Add staff"
        '
        'dashboard_btn
        '
        Me.dashboard_btn.Animated = True
        Me.dashboard_btn.CheckedState.Parent = Me.dashboard_btn
        Me.dashboard_btn.Cursor = System.Windows.Forms.Cursors.Hand
        Me.dashboard_btn.CustomImages.Parent = Me.dashboard_btn
        Me.dashboard_btn.FillColor = System.Drawing.Color.DarkGray
        Me.dashboard_btn.Font = New System.Drawing.Font("Segoe UI", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.dashboard_btn.ForeColor = System.Drawing.Color.White
        Me.dashboard_btn.HoverState.Parent = Me.dashboard_btn
        Me.dashboard_btn.Image = Global.Bank.My.Resources.Resources.slow
        Me.dashboard_btn.Location = New System.Drawing.Point(8, 26)
        Me.dashboard_btn.Name = "dashboard_btn"
        Me.dashboard_btn.ShadowDecoration.Parent = Me.dashboard_btn
        Me.dashboard_btn.Size = New System.Drawing.Size(226, 52)
        Me.dashboard_btn.TabIndex = 2
        Me.dashboard_btn.Text = "Dashboard"
        '
        'role_label
        '
        Me.role_label.BackColor = System.Drawing.Color.Transparent
        Me.role_label.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.role_label.ForeColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.role_label.Location = New System.Drawing.Point(9, 175)
        Me.role_label.Name = "role_label"
        Me.role_label.Size = New System.Drawing.Size(94, 16)
        Me.role_label.TabIndex = 1
        Me.role_label.Text = "General Manager"
        '
        'passport
        '
        Me.passport.BorderRadius = 10
        Me.passport.Image = Global.Bank.My.Resources.Resources.bg_image
        Me.passport.Location = New System.Drawing.Point(60, 45)
        Me.passport.Name = "passport"
        Me.passport.ShadowDecoration.Parent = Me.passport
        Me.passport.Size = New System.Drawing.Size(128, 105)
        Me.passport.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.passport.TabIndex = 0
        Me.passport.TabStop = False
        '
        'profilename_panel
        '
        Me.profilename_panel.BackColor = System.Drawing.Color.Transparent
        Me.profilename_panel.BorderColor = System.Drawing.Color.Transparent
        Me.profilename_panel.BorderRadius = 6
        Me.profilename_panel.BorderThickness = 2
        Me.profilename_panel.Controls.Add(Me.Guna2PictureBox2)
        Me.profilename_panel.Controls.Add(Me.fullname_label)
        Me.profilename_panel.Controls.Add(Me.Guna2HtmlLabel7)
        Me.profilename_panel.Controls.Add(Me.Guna2HtmlLabel3)
        Me.profilename_panel.Controls.Add(Me.status_label)
        Me.profilename_panel.Controls.Add(Me.Guna2HtmlLabel5)
        Me.profilename_panel.Controls.Add(Me.last_login_label)
        Me.profilename_panel.Controls.Add(Me.Guna2HtmlLabel8)
        Me.profilename_panel.CustomBorderColor = System.Drawing.Color.Transparent
        Me.profilename_panel.FillColor = System.Drawing.Color.White
        Me.profilename_panel.Location = New System.Drawing.Point(275, 73)
        Me.profilename_panel.Name = "profilename_panel"
        Me.profilename_panel.ShadowDecoration.Parent = Me.profilename_panel
        Me.profilename_panel.Size = New System.Drawing.Size(840, 77)
        Me.profilename_panel.TabIndex = 2
        '
        'time_panel
        '
        Me.time_panel.BackColor = System.Drawing.Color.Transparent
        Me.time_panel.BorderRadius = 7
        Me.time_panel.BorderThickness = 2
        Me.time_panel.Controls.Add(Me.date_txt)
        Me.time_panel.Controls.Add(Me.time)
        Me.time_panel.Controls.Add(Me.Guna2HtmlLabel10)
        Me.time_panel.Location = New System.Drawing.Point(1126, 73)
        Me.time_panel.Name = "time_panel"
        Me.time_panel.ShadowDecoration.Parent = Me.time_panel
        Me.time_panel.Size = New System.Drawing.Size(232, 77)
        Me.time_panel.TabIndex = 3
        '
        'Guna2CustomGradientPanel1
        '
        Me.Guna2CustomGradientPanel1.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.Guna2CustomGradientPanel1.BackColor = System.Drawing.Color.Transparent
        Me.Guna2CustomGradientPanel1.BorderRadius = 7
        Me.Guna2CustomGradientPanel1.BorderThickness = 2
        Me.Guna2CustomGradientPanel1.Controls.Add(Me.Guna2GradientPanel4)
        Me.Guna2CustomGradientPanel1.Controls.Add(Me.Guna2GradientPanel3)
        Me.Guna2CustomGradientPanel1.Controls.Add(Me.Guna2GradientPanel2)
        Me.Guna2CustomGradientPanel1.Controls.Add(Me.Guna2GradientPanel1)
        Me.Guna2CustomGradientPanel1.Location = New System.Drawing.Point(275, 162)
        Me.Guna2CustomGradientPanel1.Name = "Guna2CustomGradientPanel1"
        Me.Guna2CustomGradientPanel1.ShadowDecoration.Parent = Me.Guna2CustomGradientPanel1
        Me.Guna2CustomGradientPanel1.Size = New System.Drawing.Size(1083, 575)
        Me.Guna2CustomGradientPanel1.TabIndex = 3
        '
        'Guna2GradientPanel4
        '
        Me.Guna2GradientPanel4.BorderRadius = 6
        Me.Guna2GradientPanel4.BorderThickness = 2
        Me.Guna2GradientPanel4.Controls.Add(Me.total_balance_label)
        Me.Guna2GradientPanel4.Controls.Add(Me.Guna2HtmlLabel19)
        Me.Guna2GradientPanel4.FillColor = System.Drawing.Color.FromArgb(CType(CType(53, Byte), Integer), CType(CType(68, Byte), Integer), CType(CType(87, Byte), Integer))
        Me.Guna2GradientPanel4.FillColor2 = System.Drawing.Color.SlateGray
        Me.Guna2GradientPanel4.Location = New System.Drawing.Point(821, 18)
        Me.Guna2GradientPanel4.Name = "Guna2GradientPanel4"
        Me.Guna2GradientPanel4.ShadowDecoration.Parent = Me.Guna2GradientPanel4
        Me.Guna2GradientPanel4.Size = New System.Drawing.Size(246, 110)
        Me.Guna2GradientPanel4.TabIndex = 1
        '
        'total_balance_label
        '
        Me.total_balance_label.BackColor = System.Drawing.Color.Transparent
        Me.total_balance_label.Font = New System.Drawing.Font("Microsoft Tai Le", 15.0!, System.Drawing.FontStyle.Bold)
        Me.total_balance_label.ForeColor = System.Drawing.Color.White
        Me.total_balance_label.Location = New System.Drawing.Point(26, 44)
        Me.total_balance_label.Name = "total_balance_label"
        Me.total_balance_label.Size = New System.Drawing.Size(15, 28)
        Me.total_balance_label.TabIndex = 1
        Me.total_balance_label.Text = "0"
        '
        'Guna2HtmlLabel19
        '
        Me.Guna2HtmlLabel19.BackColor = System.Drawing.Color.Transparent
        Me.Guna2HtmlLabel19.Font = New System.Drawing.Font("Microsoft Tai Le", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Guna2HtmlLabel19.ForeColor = System.Drawing.Color.White
        Me.Guna2HtmlLabel19.Location = New System.Drawing.Point(21, 12)
        Me.Guna2HtmlLabel19.Name = "Guna2HtmlLabel19"
        Me.Guna2HtmlLabel19.Size = New System.Drawing.Size(120, 23)
        Me.Guna2HtmlLabel19.TabIndex = 1
        Me.Guna2HtmlLabel19.Text = "TOTAL BALANCE"
        '
        'Guna2GradientPanel3
        '
        Me.Guna2GradientPanel3.BorderRadius = 6
        Me.Guna2GradientPanel3.BorderThickness = 2
        Me.Guna2GradientPanel3.Controls.Add(Me.total_loan_label)
        Me.Guna2GradientPanel3.Controls.Add(Me.Guna2HtmlLabel17)
        Me.Guna2GradientPanel3.FillColor = System.Drawing.Color.FromArgb(CType(CType(53, Byte), Integer), CType(CType(68, Byte), Integer), CType(CType(87, Byte), Integer))
        Me.Guna2GradientPanel3.FillColor2 = System.Drawing.Color.SlateGray
        Me.Guna2GradientPanel3.Location = New System.Drawing.Point(552, 18)
        Me.Guna2GradientPanel3.Name = "Guna2GradientPanel3"
        Me.Guna2GradientPanel3.ShadowDecoration.Parent = Me.Guna2GradientPanel3
        Me.Guna2GradientPanel3.Size = New System.Drawing.Size(246, 110)
        Me.Guna2GradientPanel3.TabIndex = 1
        '
        'total_loan_label
        '
        Me.total_loan_label.BackColor = System.Drawing.Color.Transparent
        Me.total_loan_label.Font = New System.Drawing.Font("Microsoft Tai Le", 15.0!, System.Drawing.FontStyle.Bold)
        Me.total_loan_label.ForeColor = System.Drawing.Color.White
        Me.total_loan_label.Location = New System.Drawing.Point(26, 44)
        Me.total_loan_label.Name = "total_loan_label"
        Me.total_loan_label.Size = New System.Drawing.Size(15, 28)
        Me.total_loan_label.TabIndex = 1
        Me.total_loan_label.Text = "0"
        '
        'Guna2HtmlLabel17
        '
        Me.Guna2HtmlLabel17.BackColor = System.Drawing.Color.Transparent
        Me.Guna2HtmlLabel17.Font = New System.Drawing.Font("Microsoft Tai Le", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Guna2HtmlLabel17.ForeColor = System.Drawing.Color.White
        Me.Guna2HtmlLabel17.Location = New System.Drawing.Point(21, 12)
        Me.Guna2HtmlLabel17.Name = "Guna2HtmlLabel17"
        Me.Guna2HtmlLabel17.Size = New System.Drawing.Size(95, 23)
        Me.Guna2HtmlLabel17.TabIndex = 1
        Me.Guna2HtmlLabel17.Text = "TOTAL LOAN"
        '
        'Guna2GradientPanel2
        '
        Me.Guna2GradientPanel2.BorderRadius = 6
        Me.Guna2GradientPanel2.BorderThickness = 2
        Me.Guna2GradientPanel2.Controls.Add(Me.total_customer_label)
        Me.Guna2GradientPanel2.Controls.Add(Me.Guna2HtmlLabel15)
        Me.Guna2GradientPanel2.FillColor = System.Drawing.Color.FromArgb(CType(CType(53, Byte), Integer), CType(CType(68, Byte), Integer), CType(CType(87, Byte), Integer))
        Me.Guna2GradientPanel2.FillColor2 = System.Drawing.Color.SlateGray
        Me.Guna2GradientPanel2.Location = New System.Drawing.Point(282, 19)
        Me.Guna2GradientPanel2.Name = "Guna2GradientPanel2"
        Me.Guna2GradientPanel2.ShadowDecoration.Parent = Me.Guna2GradientPanel2
        Me.Guna2GradientPanel2.Size = New System.Drawing.Size(246, 110)
        Me.Guna2GradientPanel2.TabIndex = 1
        '
        'total_customer_label
        '
        Me.total_customer_label.BackColor = System.Drawing.Color.Transparent
        Me.total_customer_label.Font = New System.Drawing.Font("Microsoft Tai Le", 15.0!, System.Drawing.FontStyle.Bold)
        Me.total_customer_label.ForeColor = System.Drawing.Color.White
        Me.total_customer_label.Location = New System.Drawing.Point(26, 44)
        Me.total_customer_label.Name = "total_customer_label"
        Me.total_customer_label.Size = New System.Drawing.Size(15, 28)
        Me.total_customer_label.TabIndex = 1
        Me.total_customer_label.Text = "0"
        '
        'Guna2HtmlLabel15
        '
        Me.Guna2HtmlLabel15.BackColor = System.Drawing.Color.Transparent
        Me.Guna2HtmlLabel15.Font = New System.Drawing.Font("Microsoft Tai Le", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Guna2HtmlLabel15.ForeColor = System.Drawing.Color.White
        Me.Guna2HtmlLabel15.Location = New System.Drawing.Point(21, 12)
        Me.Guna2HtmlLabel15.Name = "Guna2HtmlLabel15"
        Me.Guna2HtmlLabel15.Size = New System.Drawing.Size(144, 23)
        Me.Guna2HtmlLabel15.TabIndex = 1
        Me.Guna2HtmlLabel15.Text = "TOTAL CUSTOMERS"
        '
        'Guna2GradientPanel1
        '
        Me.Guna2GradientPanel1.BorderRadius = 6
        Me.Guna2GradientPanel1.BorderThickness = 2
        Me.Guna2GradientPanel1.Controls.Add(Me.total_admin_label)
        Me.Guna2GradientPanel1.Controls.Add(Me.Guna2HtmlLabel12)
        Me.Guna2GradientPanel1.FillColor = System.Drawing.Color.FromArgb(CType(CType(53, Byte), Integer), CType(CType(68, Byte), Integer), CType(CType(87, Byte), Integer))
        Me.Guna2GradientPanel1.FillColor2 = System.Drawing.Color.SlateGray
        Me.Guna2GradientPanel1.Location = New System.Drawing.Point(12, 19)
        Me.Guna2GradientPanel1.Name = "Guna2GradientPanel1"
        Me.Guna2GradientPanel1.ShadowDecoration.Parent = Me.Guna2GradientPanel1
        Me.Guna2GradientPanel1.Size = New System.Drawing.Size(246, 110)
        Me.Guna2GradientPanel1.TabIndex = 1
        '
        'total_admin_label
        '
        Me.total_admin_label.BackColor = System.Drawing.Color.Transparent
        Me.total_admin_label.Font = New System.Drawing.Font("Microsoft Tai Le", 15.0!, System.Drawing.FontStyle.Bold)
        Me.total_admin_label.ForeColor = System.Drawing.Color.White
        Me.total_admin_label.Location = New System.Drawing.Point(26, 44)
        Me.total_admin_label.Name = "total_admin_label"
        Me.total_admin_label.Size = New System.Drawing.Size(15, 28)
        Me.total_admin_label.TabIndex = 1
        Me.total_admin_label.Text = "0"
        '
        'Guna2HtmlLabel12
        '
        Me.Guna2HtmlLabel12.BackColor = System.Drawing.Color.Transparent
        Me.Guna2HtmlLabel12.Font = New System.Drawing.Font("Microsoft Tai Le", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Guna2HtmlLabel12.ForeColor = System.Drawing.Color.White
        Me.Guna2HtmlLabel12.Location = New System.Drawing.Point(21, 12)
        Me.Guna2HtmlLabel12.Name = "Guna2HtmlLabel12"
        Me.Guna2HtmlLabel12.Size = New System.Drawing.Size(104, 23)
        Me.Guna2HtmlLabel12.TabIndex = 1
        Me.Guna2HtmlLabel12.Text = "TOTAL ADMIN"
        '
        'Admin_dashboard
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackgroundImage = Global.Bank.My.Resources.Resources.bg_2
        Me.ClientSize = New System.Drawing.Size(1370, 749)
        Me.Controls.Add(Me.Guna2CustomGradientPanel1)
        Me.Controls.Add(Me.time_panel)
        Me.Controls.Add(Me.profilename_panel)
        Me.Controls.Add(Me.Guna2Panel2)
        Me.Controls.Add(Me.Guna2Panel1)
        Me.Name = "Admin_dashboard"
        Me.ShowInTaskbar = False
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Admin_dashboard"
        Me.WindowState = System.Windows.Forms.FormWindowState.Maximized
        Me.Guna2Panel1.ResumeLayout(False)
        Me.Guna2Panel1.PerformLayout()
        CType(Me.Guna2PictureBox2, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Guna2Panel2.ResumeLayout(False)
        Me.Guna2Panel2.PerformLayout()
        Me.Guna2Panel3.ResumeLayout(False)
        CType(Me.passport, System.ComponentModel.ISupportInitialize).EndInit()
        Me.profilename_panel.ResumeLayout(False)
        Me.profilename_panel.PerformLayout()
        Me.time_panel.ResumeLayout(False)
        Me.time_panel.PerformLayout()
        Me.Guna2CustomGradientPanel1.ResumeLayout(False)
        Me.Guna2GradientPanel4.ResumeLayout(False)
        Me.Guna2GradientPanel4.PerformLayout()
        Me.Guna2GradientPanel3.ResumeLayout(False)
        Me.Guna2GradientPanel3.PerformLayout()
        Me.Guna2GradientPanel2.ResumeLayout(False)
        Me.Guna2GradientPanel2.PerformLayout()
        Me.Guna2GradientPanel1.ResumeLayout(False)
        Me.Guna2GradientPanel1.PerformLayout()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents Guna2Panel1 As Guna.UI2.WinForms.Guna2Panel
    Friend WithEvents Guna2Panel2 As Guna.UI2.WinForms.Guna2Panel
    Friend WithEvents passport As Guna.UI2.WinForms.Guna2PictureBox
    Friend WithEvents role_label As Guna.UI2.WinForms.Guna2HtmlLabel
    Friend WithEvents Guna2PictureBox2 As Guna.UI2.WinForms.Guna2PictureBox
    Friend WithEvents fullname_label As Guna.UI2.WinForms.Guna2HtmlLabel
    Friend WithEvents Guna2HtmlLabel3 As Guna.UI2.WinForms.Guna2HtmlLabel
    Friend WithEvents status_label As Guna.UI2.WinForms.Guna2HtmlLabel
    Friend WithEvents last_login_label As Guna.UI2.WinForms.Guna2HtmlLabel
    Friend WithEvents Guna2HtmlLabel8 As Guna.UI2.WinForms.Guna2HtmlLabel
    Friend WithEvents Guna2HtmlLabel7 As Guna.UI2.WinForms.Guna2HtmlLabel
    Friend WithEvents Guna2HtmlLabel5 As Guna.UI2.WinForms.Guna2HtmlLabel
    Friend WithEvents Guna2HtmlLabel10 As Guna.UI2.WinForms.Guna2HtmlLabel
    Friend WithEvents time As Guna.UI2.WinForms.Guna2HtmlLabel
    Friend WithEvents date_txt As Guna.UI2.WinForms.Guna2HtmlLabel
    Friend WithEvents profilename_panel As Guna.UI2.WinForms.Guna2Panel
    Friend WithEvents time_panel As Guna.UI2.WinForms.Guna2CustomGradientPanel
    Friend WithEvents Guna2HtmlLabel11 As Guna.UI2.WinForms.Guna2HtmlLabel
    Friend WithEvents logout_btn As Guna.UI2.WinForms.Guna2Button
    Friend WithEvents Guna2CustomGradientPanel1 As Guna.UI2.WinForms.Guna2CustomGradientPanel
    Friend WithEvents total_admin_label As Guna.UI2.WinForms.Guna2HtmlLabel
    Friend WithEvents Guna2HtmlLabel12 As Guna.UI2.WinForms.Guna2HtmlLabel
    Friend WithEvents Guna2GradientPanel1 As Guna.UI2.WinForms.Guna2GradientPanel
    Friend WithEvents Guna2GradientPanel4 As Guna.UI2.WinForms.Guna2GradientPanel
    Friend WithEvents total_balance_label As Guna.UI2.WinForms.Guna2HtmlLabel
    Friend WithEvents Guna2HtmlLabel19 As Guna.UI2.WinForms.Guna2HtmlLabel
    Friend WithEvents Guna2GradientPanel3 As Guna.UI2.WinForms.Guna2GradientPanel
    Friend WithEvents total_loan_label As Guna.UI2.WinForms.Guna2HtmlLabel
    Friend WithEvents Guna2HtmlLabel17 As Guna.UI2.WinForms.Guna2HtmlLabel
    Friend WithEvents Guna2GradientPanel2 As Guna.UI2.WinForms.Guna2GradientPanel
    Friend WithEvents total_customer_label As Guna.UI2.WinForms.Guna2HtmlLabel
    Friend WithEvents Guna2HtmlLabel15 As Guna.UI2.WinForms.Guna2HtmlLabel
    Friend WithEvents dashboard_btn As Guna.UI2.WinForms.Guna2Button
    Friend WithEvents Guna2Panel3 As Guna.UI2.WinForms.Guna2Panel
    Friend WithEvents setting_btn As Guna.UI2.WinForms.Guna2Button
    Friend WithEvents loan_btn As Guna.UI2.WinForms.Guna2Button
    Friend WithEvents customer_btn As Guna.UI2.WinForms.Guna2Button
    Friend WithEvents add_staff_btn As Guna.UI2.WinForms.Guna2Button
    Friend WithEvents deposit_btn As Guna.UI2.WinForms.Guna2Button
    Friend WithEvents name_label As Guna.UI2.WinForms.Guna2HtmlLabel
End Class
