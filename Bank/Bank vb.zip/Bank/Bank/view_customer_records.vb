﻿Public Class view_customer_records
    Private Sub exit_home_btn_Click(sender As Object, e As EventArgs) Handles exit_home_btn.Click
        exit_btn(Me)
    End Sub

    Private Sub record_home_btn_Click(sender As Object, e As EventArgs) Handles record_home_btn.Click
        customer_record.Show()
        Me.Hide()

    End Sub

    Private Sub view_customer_records_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        functions.customerRecord()
    End Sub
End Class