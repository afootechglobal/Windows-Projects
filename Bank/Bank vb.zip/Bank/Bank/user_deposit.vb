﻿Public Class user_deposit
    Private Sub exit_home_Click(sender As Object, e As EventArgs) Handles exit_home.Click
        exit_btn(Me)
        index.Hide()
    End Sub

    Private Sub ClearButton_Click(sender As Object, e As EventArgs) Handles ClearButton.Click
        deposit_txt.Text = ""
    End Sub

    Private Sub transBtn_Click(sender As Object, e As EventArgs) Handles transBtn.Click
        user_transaction.Show()
        Me.Hide()
    End Sub

    Private Sub SubmitButton_Click(sender As Object, e As EventArgs) Handles SubmitButton.Click
        If deposit_txt.Text = "" Then
            MessageBox.Show("ERROR! All fields are required", "Bank Application Software", MessageBoxButtons.OK, MessageBoxIcon.Error)
        Else
            Dim deposit As Double = Convert.ToDouble(deposit_txt.Text).ToString
            Dim customer_id = userlog.login_customer_id
            functions.deposit(deposit, customer_id, 2)
        End If
    End Sub

    Private Sub deposit_txt_KeyPress(sender As Object, e As KeyPressEventArgs) Handles deposit_txt.KeyPress
        functions.numCheck(e)
    End Sub
End Class