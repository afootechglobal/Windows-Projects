﻿Imports MySql.Data.MySqlClient
Imports System.IO
Public Class customer_record
    Dim reader As MySqlDataReader
    Dim command As MySqlCommand
    Dim query As String
    Private Sub exit_home_Click(sender As Object, e As EventArgs) Handles exit_home.Click
        exit_btn(Me)
    End Sub

    Private Sub view_btn_Click(sender As Object, e As EventArgs) Handles view_btn.Click
        Me.Hide()
        view_customer_records.Show()

    End Sub

    Private Sub customer_record_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        functions.getGender()
        functions.getStatus(StatusComboBox)
        functions.getCustomerID()
        counter_val_txt.Text = GetCustomerCount()
    End Sub

    Private Sub select_btn_Click(sender As Object, e As EventArgs) Handles select_btn.Click
        functions.selectPassport(picture_box)
    End Sub

    Private Sub submit_btn_Click(sender As Object, e As EventArgs) Handles submit_btn.Click
        If fullname_txt.Text = "" Or email_txt.Text = "" Or phoneno_txt.Text = "" Then
            MessageBox.Show("ERROR! Enter Input for all Fields", "Bank Application Software", MessageBoxButtons.OK, MessageBoxIcon.Error)
        ElseIf picture_box.Image Is Nothing Then
            MessageBox.Show("ERROR! Select a Passport to Continue!", "Bank Application Software", MessageBoxButtons.OK, MessageBoxIcon.Error)
        ElseIf functions.emailValidate(email_txt.Text) = False Then
            MessageBox.Show("ERROR! Invalid Email Address", "Bank Application Software", MessageBoxButtons.OK, MessageBoxIcon.Error)
        Else
            If profile_id.Text = "SELECT CUSTOMER" Then
                reader = functions.customerEmailCheck(email_txt.Text)
                If reader.HasRows Then
                    MessageBox.Show("ERROR! Emaill Address is already Exist, Kindly Enter a new Email Address to Continue!", "Bank Application Software", MessageBoxButtons.OK, MessageBoxIcon.Error)
                Else
                    functions.customerRegistration()
                End If
            Else
                reader = functions.customerUpdateEmailCheck(email_txt.Text)
                If reader.HasRows Then
                    MessageBox.Show("ERROR! Emaill Address is already Exist, Kindly Enter a new Email Address to Continue!", "Bank Application Software", MessageBoxButtons.OK, MessageBoxIcon.Error)
                Else
                    functions.UpdateCustomer()
                End If
            End If
        End If
    End Sub

    Private Sub fetch_btn_Click(sender As Object, e As EventArgs) Handles fetch_btn.Click
        If profile_id.Text = "SELECT CUSTOMER" Then
            MessageBox.Show("SELECT CUSTOMER TO CONTINUE!", "Bank Application Software", MessageBoxButtons.OK, MessageBoxIcon.Error)
        Else
            Try
                Dim connection = functions.connection
                connection.Open()
                query = "SELECT a.*, b.status_name, c.gender_name FROM customer_tab a, setup_status_tab b, setup_gender_tab c WHERE a.status_id=b.status_id AND a.gender_id=c.gender_id AND customer_id=@customer_id;"
                Dim Command = New MySqlCommand(query, connection)
                Command.Parameters.AddWithValue("@customer_id", profile_id.SelectedValue)
                reader = Command.ExecuteReader
                reader.Read()

                Dim arrimage() As Byte

                fullname_txt.Text = reader("fullname")
                email_txt.Text = reader("email")
                phoneno_txt.Text = reader("mobile")
                genderComboBox.Text = (reader("gender_name"))
                genderComboBox.SelectedValue = reader("gender_id")
                StatusComboBox.Text = (reader("status_name"))
                StatusComboBox.SelectedValue = reader("status_id")
                arrimage = reader("passport")

                Dim mstream = New MemoryStream(arrimage)
                picture_box.Image = Image.FromStream(mstream)
                connection.Close()
            Catch ex As Exception
                MsgBox(ex.Message)
            End Try
        End If
    End Sub

    Private Sub fullname_txt_KeyPress(sender As Object, e As KeyPressEventArgs) Handles fullname_txt.KeyPress
        functions.alphaCheck(e)
    End Sub

    Private Sub phoneno_txt_KeyPress(sender As Object, e As KeyPressEventArgs) Handles phoneno_txt.KeyPress
        functions.numCheck(e)
    End Sub

    Private Sub main_clear_Click(sender As Object, e As EventArgs) Handles main_clear.Click
        functions.clearFunction()
    End Sub
End Class