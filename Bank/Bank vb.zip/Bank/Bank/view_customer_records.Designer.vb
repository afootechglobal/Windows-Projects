﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class view_customer_records
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.userRecord = New System.Windows.Forms.ListView()
        Me.sn = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.customer_id = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.full_name = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.email = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.phone_number = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.LOAN_BALANCE = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.PASSPORT = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.PAS = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.ColumnHeader1 = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.ColumnHeader2 = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.ColumnHeader3 = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.ColumnHeader4 = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.ColumnHeader5 = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.ColumnHeader6 = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.Guna2Panel3 = New Guna.UI2.WinForms.Guna2Panel()
        Me.record_home_btn = New Guna.UI2.WinForms.Guna2Button()
        Me.Guna2Panel4 = New Guna.UI2.WinForms.Guna2Panel()
        Me.Guna2HtmlLabel2 = New Guna.UI2.WinForms.Guna2HtmlLabel()
        Me.exit_home_btn = New Guna.UI2.WinForms.Guna2Button()
        Me.Guna2Panel3.SuspendLayout()
        Me.Guna2Panel4.SuspendLayout()
        Me.SuspendLayout()
        '
        'userRecord
        '
        Me.userRecord.Columns.AddRange(New System.Windows.Forms.ColumnHeader() {Me.sn, Me.customer_id, Me.full_name, Me.email, Me.phone_number, Me.LOAN_BALANCE, Me.PASSPORT, Me.PAS, Me.ColumnHeader1, Me.ColumnHeader2, Me.ColumnHeader3, Me.ColumnHeader4, Me.ColumnHeader5, Me.ColumnHeader6})
        Me.userRecord.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.userRecord.FullRowSelect = True
        Me.userRecord.GridLines = True
        Me.userRecord.HideSelection = False
        Me.userRecord.Location = New System.Drawing.Point(10, 92)
        Me.userRecord.Name = "userRecord"
        Me.userRecord.Size = New System.Drawing.Size(707, 543)
        Me.userRecord.TabIndex = 10
        Me.userRecord.UseCompatibleStateImageBehavior = False
        Me.userRecord.View = System.Windows.Forms.View.Details
        '
        'sn
        '
        Me.sn.Text = "S/N"
        Me.sn.Width = 40
        '
        'customer_id
        '
        Me.customer_id.Text = "CUSTOMER_ID"
        Me.customer_id.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        Me.customer_id.Width = 200
        '
        'full_name
        '
        Me.full_name.Text = "FULL NAME"
        Me.full_name.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        Me.full_name.Width = 200
        '
        'email
        '
        Me.email.Text = "EMAIL ADDRESS"
        Me.email.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        Me.email.Width = 200
        '
        'phone_number
        '
        Me.phone_number.Text = "PHONE NUMBER"
        Me.phone_number.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        Me.phone_number.Width = 200
        '
        'LOAN_BALANCE
        '
        Me.LOAN_BALANCE.Text = "LOAN BALANCE"
        Me.LOAN_BALANCE.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        Me.LOAN_BALANCE.Width = 200
        '
        'PASSPORT
        '
        Me.PASSPORT.Text = "PASSPORT"
        Me.PASSPORT.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        Me.PASSPORT.Width = 200
        '
        'PAS
        '
        Me.PAS.Text = "REGISTERED BY"
        Me.PAS.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        Me.PAS.Width = 200
        '
        'ColumnHeader1
        '
        Me.ColumnHeader1.Text = "DATE REGISTERED"
        Me.ColumnHeader1.Width = 200
        '
        'ColumnHeader2
        '
        Me.ColumnHeader2.Text = "ACCOUNT BALANCE"
        Me.ColumnHeader2.Width = 200
        '
        'ColumnHeader3
        '
        Me.ColumnHeader3.Text = "UPDATED TIME"
        Me.ColumnHeader3.Width = 200
        '
        'ColumnHeader4
        '
        Me.ColumnHeader4.Text = "LAST LOGIN DATE"
        Me.ColumnHeader4.Width = 200
        '
        'ColumnHeader5
        '
        Me.ColumnHeader5.Text = "GENDER"
        Me.ColumnHeader5.Width = 200
        '
        'ColumnHeader6
        '
        Me.ColumnHeader6.Text = "STATUS"
        Me.ColumnHeader6.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        Me.ColumnHeader6.Width = 200
        '
        'Guna2Panel3
        '
        Me.Guna2Panel3.BackColor = System.Drawing.Color.Silver
        Me.Guna2Panel3.Controls.Add(Me.record_home_btn)
        Me.Guna2Panel3.Location = New System.Drawing.Point(-11, 39)
        Me.Guna2Panel3.Name = "Guna2Panel3"
        Me.Guna2Panel3.ShadowDecoration.Parent = Me.Guna2Panel3
        Me.Guna2Panel3.Size = New System.Drawing.Size(744, 36)
        Me.Guna2Panel3.TabIndex = 9
        '
        'record_home_btn
        '
        Me.record_home_btn.Animated = True
        Me.record_home_btn.BorderRadius = 4
        Me.record_home_btn.CheckedState.Parent = Me.record_home_btn
        Me.record_home_btn.Cursor = System.Windows.Forms.Cursors.Hand
        Me.record_home_btn.CustomImages.Parent = Me.record_home_btn
        Me.record_home_btn.FillColor = System.Drawing.Color.FromArgb(CType(CType(47, Byte), Integer), CType(CType(60, Byte), Integer), CType(CType(77, Byte), Integer))
        Me.record_home_btn.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.record_home_btn.ForeColor = System.Drawing.Color.White
        Me.record_home_btn.HoverState.FillColor = System.Drawing.Color.Gray
        Me.record_home_btn.HoverState.Parent = Me.record_home_btn
        Me.record_home_btn.Location = New System.Drawing.Point(21, 3)
        Me.record_home_btn.Name = "record_home_btn"
        Me.record_home_btn.ShadowDecoration.Parent = Me.record_home_btn
        Me.record_home_btn.Size = New System.Drawing.Size(106, 30)
        Me.record_home_btn.TabIndex = 2
        Me.record_home_btn.Text = "Back"
        '
        'Guna2Panel4
        '
        Me.Guna2Panel4.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Guna2Panel4.BackColor = System.Drawing.Color.FromArgb(CType(CType(47, Byte), Integer), CType(CType(60, Byte), Integer), CType(CType(77, Byte), Integer))
        Me.Guna2Panel4.Controls.Add(Me.Guna2HtmlLabel2)
        Me.Guna2Panel4.Controls.Add(Me.exit_home_btn)
        Me.Guna2Panel4.Location = New System.Drawing.Point(-1, -1)
        Me.Guna2Panel4.Name = "Guna2Panel4"
        Me.Guna2Panel4.ShadowDecoration.Depth = 55
        Me.Guna2Panel4.ShadowDecoration.Enabled = True
        Me.Guna2Panel4.ShadowDecoration.Parent = Me.Guna2Panel4
        Me.Guna2Panel4.ShadowDecoration.Shadow = New System.Windows.Forms.Padding(0, 0, 0, 2)
        Me.Guna2Panel4.Size = New System.Drawing.Size(734, 40)
        Me.Guna2Panel4.TabIndex = 8
        '
        'Guna2HtmlLabel2
        '
        Me.Guna2HtmlLabel2.BackColor = System.Drawing.Color.Transparent
        Me.Guna2HtmlLabel2.Font = New System.Drawing.Font("Microsoft Tai Le", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Guna2HtmlLabel2.ForeColor = System.Drawing.Color.White
        Me.Guna2HtmlLabel2.Location = New System.Drawing.Point(11, 12)
        Me.Guna2HtmlLabel2.Name = "Guna2HtmlLabel2"
        Me.Guna2HtmlLabel2.Size = New System.Drawing.Size(114, 18)
        Me.Guna2HtmlLabel2.TabIndex = 3
        Me.Guna2HtmlLabel2.Text = "Customer Records"
        '
        'exit_home_btn
        '
        Me.exit_home_btn.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.exit_home_btn.Animated = True
        Me.exit_home_btn.CheckedState.Parent = Me.exit_home_btn
        Me.exit_home_btn.Cursor = System.Windows.Forms.Cursors.Hand
        Me.exit_home_btn.CustomImages.Parent = Me.exit_home_btn
        Me.exit_home_btn.FillColor = System.Drawing.Color.Red
        Me.exit_home_btn.Font = New System.Drawing.Font("Segoe UI", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.exit_home_btn.ForeColor = System.Drawing.Color.White
        Me.exit_home_btn.HoverState.FillColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.exit_home_btn.HoverState.Parent = Me.exit_home_btn
        Me.exit_home_btn.Location = New System.Drawing.Point(681, 0)
        Me.exit_home_btn.Name = "exit_home_btn"
        Me.exit_home_btn.ShadowDecoration.Parent = Me.exit_home_btn
        Me.exit_home_btn.Size = New System.Drawing.Size(51, 40)
        Me.exit_home_btn.TabIndex = 1
        Me.exit_home_btn.Text = "x"
        '
        'view_customer_records
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(731, 666)
        Me.Controls.Add(Me.userRecord)
        Me.Controls.Add(Me.Guna2Panel3)
        Me.Controls.Add(Me.Guna2Panel4)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.Name = "view_customer_records"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "view_customer_records"
        Me.Guna2Panel3.ResumeLayout(False)
        Me.Guna2Panel4.ResumeLayout(False)
        Me.Guna2Panel4.PerformLayout()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents userRecord As ListView
    Friend WithEvents sn As ColumnHeader
    Friend WithEvents customer_id As ColumnHeader
    Friend WithEvents full_name As ColumnHeader
    Friend WithEvents email As ColumnHeader
    Friend WithEvents phone_number As ColumnHeader
    Friend WithEvents LOAN_BALANCE As ColumnHeader
    Friend WithEvents PASSPORT As ColumnHeader
    Friend WithEvents PAS As ColumnHeader
    Friend WithEvents Guna2Panel3 As Guna.UI2.WinForms.Guna2Panel
    Friend WithEvents record_home_btn As Guna.UI2.WinForms.Guna2Button
    Friend WithEvents Guna2Panel4 As Guna.UI2.WinForms.Guna2Panel
    Friend WithEvents Guna2HtmlLabel2 As Guna.UI2.WinForms.Guna2HtmlLabel
    Friend WithEvents exit_home_btn As Guna.UI2.WinForms.Guna2Button
    Friend WithEvents ColumnHeader1 As ColumnHeader
    Friend WithEvents ColumnHeader2 As ColumnHeader
    Friend WithEvents ColumnHeader3 As ColumnHeader
    Friend WithEvents ColumnHeader4 As ColumnHeader
    Friend WithEvents ColumnHeader5 As ColumnHeader
    Friend WithEvents ColumnHeader6 As ColumnHeader
End Class
