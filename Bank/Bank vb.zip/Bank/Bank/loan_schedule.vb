﻿Public Class loan_schedule
    Private Sub backBtn_Click(sender As Object, e As EventArgs) Handles backBtn.Click
        loan_form.Show()
        Me.Hide()
    End Sub

    Private Sub closeBtn_Click(sender As Object, e As EventArgs) Handles closeBtn.Click
        exit_btn(Me)
    End Sub

    Private Sub loan_schedule_form_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Dim customer_id = loan_form.profile_id.SelectedValue
        functions.customerLoanSchedule(customer_id, loanScheduleRecord)
    End Sub
End Class