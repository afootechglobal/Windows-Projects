﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class system_settings
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Guna2Panel1 = New Guna.UI2.WinForms.Guna2Panel()
        Me.Guna2HtmlLabel2 = New Guna.UI2.WinForms.Guna2HtmlLabel()
        Me.exit_home = New Guna.UI2.WinForms.Guna2Button()
        Me.Guna2HtmlLabel3 = New Guna.UI2.WinForms.Guna2HtmlLabel()
        Me.minimum_balance_txt = New Guna.UI2.WinForms.Guna2TextBox()
        Me.maximum_loan_txt = New Guna.UI2.WinForms.Guna2TextBox()
        Me.Guna2HtmlLabel1 = New Guna.UI2.WinForms.Guna2HtmlLabel()
        Me.minimum_loan_txt = New Guna.UI2.WinForms.Guna2TextBox()
        Me.Guna2HtmlLabel4 = New Guna.UI2.WinForms.Guna2HtmlLabel()
        Me.maximum_duration_txt = New Guna.UI2.WinForms.Guna2TextBox()
        Me.Guna2HtmlLabel5 = New Guna.UI2.WinForms.Guna2HtmlLabel()
        Me.loan_rate_txt = New Guna.UI2.WinForms.Guna2TextBox()
        Me.Guna2HtmlLabel6 = New Guna.UI2.WinForms.Guna2HtmlLabel()
        Me.system_update_btn = New Guna.UI2.WinForms.Guna2GradientButton()
        Me.Guna2Panel1.SuspendLayout()
        Me.SuspendLayout()
        '
        'Guna2Panel1
        '
        Me.Guna2Panel1.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Guna2Panel1.BackColor = System.Drawing.Color.FromArgb(CType(CType(47, Byte), Integer), CType(CType(60, Byte), Integer), CType(CType(77, Byte), Integer))
        Me.Guna2Panel1.Controls.Add(Me.Guna2HtmlLabel2)
        Me.Guna2Panel1.Controls.Add(Me.exit_home)
        Me.Guna2Panel1.Location = New System.Drawing.Point(0, 0)
        Me.Guna2Panel1.Name = "Guna2Panel1"
        Me.Guna2Panel1.ShadowDecoration.Depth = 55
        Me.Guna2Panel1.ShadowDecoration.Enabled = True
        Me.Guna2Panel1.ShadowDecoration.Parent = Me.Guna2Panel1
        Me.Guna2Panel1.ShadowDecoration.Shadow = New System.Windows.Forms.Padding(0, 0, 0, 2)
        Me.Guna2Panel1.Size = New System.Drawing.Size(535, 40)
        Me.Guna2Panel1.TabIndex = 5
        '
        'Guna2HtmlLabel2
        '
        Me.Guna2HtmlLabel2.BackColor = System.Drawing.Color.Transparent
        Me.Guna2HtmlLabel2.Font = New System.Drawing.Font("Microsoft Tai Le", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Guna2HtmlLabel2.ForeColor = System.Drawing.Color.White
        Me.Guna2HtmlLabel2.Location = New System.Drawing.Point(8, 13)
        Me.Guna2HtmlLabel2.Name = "Guna2HtmlLabel2"
        Me.Guna2HtmlLabel2.Size = New System.Drawing.Size(100, 18)
        Me.Guna2HtmlLabel2.TabIndex = 2
        Me.Guna2HtmlLabel2.Text = "System settings"
        '
        'exit_home
        '
        Me.exit_home.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.exit_home.Animated = True
        Me.exit_home.CheckedState.Parent = Me.exit_home
        Me.exit_home.Cursor = System.Windows.Forms.Cursors.Hand
        Me.exit_home.CustomImages.Parent = Me.exit_home
        Me.exit_home.FillColor = System.Drawing.Color.Red
        Me.exit_home.Font = New System.Drawing.Font("Segoe UI", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.exit_home.ForeColor = System.Drawing.Color.White
        Me.exit_home.HoverState.FillColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.exit_home.HoverState.Parent = Me.exit_home
        Me.exit_home.Location = New System.Drawing.Point(484, 0)
        Me.exit_home.Name = "exit_home"
        Me.exit_home.ShadowDecoration.Parent = Me.exit_home
        Me.exit_home.Size = New System.Drawing.Size(51, 39)
        Me.exit_home.TabIndex = 1
        Me.exit_home.Text = "x"
        '
        'Guna2HtmlLabel3
        '
        Me.Guna2HtmlLabel3.BackColor = System.Drawing.Color.Transparent
        Me.Guna2HtmlLabel3.Font = New System.Drawing.Font("Microsoft Tai Le", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Guna2HtmlLabel3.Location = New System.Drawing.Point(20, 60)
        Me.Guna2HtmlLabel3.Name = "Guna2HtmlLabel3"
        Me.Guna2HtmlLabel3.Size = New System.Drawing.Size(114, 18)
        Me.Guna2HtmlLabel3.TabIndex = 7
        Me.Guna2HtmlLabel3.Text = "Minimum Balance"
        '
        'minimum_balance_txt
        '
        Me.minimum_balance_txt.BorderRadius = 3
        Me.minimum_balance_txt.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.minimum_balance_txt.DefaultText = ""
        Me.minimum_balance_txt.DisabledState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer))
        Me.minimum_balance_txt.DisabledState.FillColor = System.Drawing.Color.FromArgb(CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer))
        Me.minimum_balance_txt.DisabledState.ForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.minimum_balance_txt.DisabledState.Parent = Me.minimum_balance_txt
        Me.minimum_balance_txt.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.minimum_balance_txt.FocusedState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.minimum_balance_txt.FocusedState.Parent = Me.minimum_balance_txt
        Me.minimum_balance_txt.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.minimum_balance_txt.ForeColor = System.Drawing.Color.Black
        Me.minimum_balance_txt.HoverState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.minimum_balance_txt.HoverState.Parent = Me.minimum_balance_txt
        Me.minimum_balance_txt.Location = New System.Drawing.Point(8, 78)
        Me.minimum_balance_txt.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.minimum_balance_txt.Name = "minimum_balance_txt"
        Me.minimum_balance_txt.PasswordChar = Global.Microsoft.VisualBasic.ChrW(0)
        Me.minimum_balance_txt.PlaceholderText = "0.00"
        Me.minimum_balance_txt.SelectedText = ""
        Me.minimum_balance_txt.ShadowDecoration.Parent = Me.minimum_balance_txt
        Me.minimum_balance_txt.Size = New System.Drawing.Size(513, 38)
        Me.minimum_balance_txt.TabIndex = 6
        '
        'maximum_loan_txt
        '
        Me.maximum_loan_txt.BorderRadius = 3
        Me.maximum_loan_txt.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.maximum_loan_txt.DefaultText = ""
        Me.maximum_loan_txt.DisabledState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer))
        Me.maximum_loan_txt.DisabledState.FillColor = System.Drawing.Color.FromArgb(CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer))
        Me.maximum_loan_txt.DisabledState.ForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.maximum_loan_txt.DisabledState.Parent = Me.maximum_loan_txt
        Me.maximum_loan_txt.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.maximum_loan_txt.FocusedState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.maximum_loan_txt.FocusedState.Parent = Me.maximum_loan_txt
        Me.maximum_loan_txt.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.maximum_loan_txt.ForeColor = System.Drawing.Color.Black
        Me.maximum_loan_txt.HoverState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.maximum_loan_txt.HoverState.Parent = Me.maximum_loan_txt
        Me.maximum_loan_txt.Location = New System.Drawing.Point(8, 160)
        Me.maximum_loan_txt.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.maximum_loan_txt.Name = "maximum_loan_txt"
        Me.maximum_loan_txt.PasswordChar = Global.Microsoft.VisualBasic.ChrW(0)
        Me.maximum_loan_txt.PlaceholderText = "0.00"
        Me.maximum_loan_txt.SelectedText = ""
        Me.maximum_loan_txt.ShadowDecoration.Parent = Me.maximum_loan_txt
        Me.maximum_loan_txt.Size = New System.Drawing.Size(513, 38)
        Me.maximum_loan_txt.TabIndex = 6
        '
        'Guna2HtmlLabel1
        '
        Me.Guna2HtmlLabel1.BackColor = System.Drawing.Color.Transparent
        Me.Guna2HtmlLabel1.Font = New System.Drawing.Font("Microsoft Tai Le", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Guna2HtmlLabel1.Location = New System.Drawing.Point(20, 142)
        Me.Guna2HtmlLabel1.Name = "Guna2HtmlLabel1"
        Me.Guna2HtmlLabel1.Size = New System.Drawing.Size(99, 18)
        Me.Guna2HtmlLabel1.TabIndex = 7
        Me.Guna2HtmlLabel1.Text = "Maximum Loan"
        '
        'minimum_loan_txt
        '
        Me.minimum_loan_txt.BorderRadius = 3
        Me.minimum_loan_txt.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.minimum_loan_txt.DefaultText = ""
        Me.minimum_loan_txt.DisabledState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer))
        Me.minimum_loan_txt.DisabledState.FillColor = System.Drawing.Color.FromArgb(CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer))
        Me.minimum_loan_txt.DisabledState.ForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.minimum_loan_txt.DisabledState.Parent = Me.minimum_loan_txt
        Me.minimum_loan_txt.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.minimum_loan_txt.FocusedState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.minimum_loan_txt.FocusedState.Parent = Me.minimum_loan_txt
        Me.minimum_loan_txt.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.minimum_loan_txt.ForeColor = System.Drawing.Color.Black
        Me.minimum_loan_txt.HoverState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.minimum_loan_txt.HoverState.Parent = Me.minimum_loan_txt
        Me.minimum_loan_txt.Location = New System.Drawing.Point(8, 245)
        Me.minimum_loan_txt.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.minimum_loan_txt.Name = "minimum_loan_txt"
        Me.minimum_loan_txt.PasswordChar = Global.Microsoft.VisualBasic.ChrW(0)
        Me.minimum_loan_txt.PlaceholderText = "0.00"
        Me.minimum_loan_txt.SelectedText = ""
        Me.minimum_loan_txt.ShadowDecoration.Parent = Me.minimum_loan_txt
        Me.minimum_loan_txt.Size = New System.Drawing.Size(513, 38)
        Me.minimum_loan_txt.TabIndex = 6
        '
        'Guna2HtmlLabel4
        '
        Me.Guna2HtmlLabel4.BackColor = System.Drawing.Color.Transparent
        Me.Guna2HtmlLabel4.Font = New System.Drawing.Font("Microsoft Tai Le", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Guna2HtmlLabel4.Location = New System.Drawing.Point(20, 227)
        Me.Guna2HtmlLabel4.Name = "Guna2HtmlLabel4"
        Me.Guna2HtmlLabel4.Size = New System.Drawing.Size(97, 18)
        Me.Guna2HtmlLabel4.TabIndex = 7
        Me.Guna2HtmlLabel4.Text = "Minimum Loan"
        '
        'maximum_duration_txt
        '
        Me.maximum_duration_txt.BorderRadius = 3
        Me.maximum_duration_txt.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.maximum_duration_txt.DefaultText = ""
        Me.maximum_duration_txt.DisabledState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer))
        Me.maximum_duration_txt.DisabledState.FillColor = System.Drawing.Color.FromArgb(CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer))
        Me.maximum_duration_txt.DisabledState.ForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.maximum_duration_txt.DisabledState.Parent = Me.maximum_duration_txt
        Me.maximum_duration_txt.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.maximum_duration_txt.FocusedState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.maximum_duration_txt.FocusedState.Parent = Me.maximum_duration_txt
        Me.maximum_duration_txt.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.maximum_duration_txt.ForeColor = System.Drawing.Color.Black
        Me.maximum_duration_txt.HoverState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.maximum_duration_txt.HoverState.Parent = Me.maximum_duration_txt
        Me.maximum_duration_txt.Location = New System.Drawing.Point(8, 333)
        Me.maximum_duration_txt.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.maximum_duration_txt.Name = "maximum_duration_txt"
        Me.maximum_duration_txt.PasswordChar = Global.Microsoft.VisualBasic.ChrW(0)
        Me.maximum_duration_txt.PlaceholderText = "0.00"
        Me.maximum_duration_txt.SelectedText = ""
        Me.maximum_duration_txt.ShadowDecoration.Parent = Me.maximum_duration_txt
        Me.maximum_duration_txt.Size = New System.Drawing.Size(513, 38)
        Me.maximum_duration_txt.TabIndex = 6
        '
        'Guna2HtmlLabel5
        '
        Me.Guna2HtmlLabel5.BackColor = System.Drawing.Color.Transparent
        Me.Guna2HtmlLabel5.Font = New System.Drawing.Font("Microsoft Tai Le", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Guna2HtmlLabel5.Location = New System.Drawing.Point(20, 315)
        Me.Guna2HtmlLabel5.Name = "Guna2HtmlLabel5"
        Me.Guna2HtmlLabel5.Size = New System.Drawing.Size(124, 18)
        Me.Guna2HtmlLabel5.TabIndex = 7
        Me.Guna2HtmlLabel5.Text = "Maximum Duration"
        '
        'loan_rate_txt
        '
        Me.loan_rate_txt.BorderRadius = 3
        Me.loan_rate_txt.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.loan_rate_txt.DefaultText = ""
        Me.loan_rate_txt.DisabledState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer))
        Me.loan_rate_txt.DisabledState.FillColor = System.Drawing.Color.FromArgb(CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer))
        Me.loan_rate_txt.DisabledState.ForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.loan_rate_txt.DisabledState.Parent = Me.loan_rate_txt
        Me.loan_rate_txt.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.loan_rate_txt.FocusedState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.loan_rate_txt.FocusedState.Parent = Me.loan_rate_txt
        Me.loan_rate_txt.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.loan_rate_txt.ForeColor = System.Drawing.Color.Black
        Me.loan_rate_txt.HoverState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.loan_rate_txt.HoverState.Parent = Me.loan_rate_txt
        Me.loan_rate_txt.Location = New System.Drawing.Point(8, 413)
        Me.loan_rate_txt.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.loan_rate_txt.Name = "loan_rate_txt"
        Me.loan_rate_txt.PasswordChar = Global.Microsoft.VisualBasic.ChrW(0)
        Me.loan_rate_txt.PlaceholderText = "0.00"
        Me.loan_rate_txt.SelectedText = ""
        Me.loan_rate_txt.ShadowDecoration.Parent = Me.loan_rate_txt
        Me.loan_rate_txt.Size = New System.Drawing.Size(513, 38)
        Me.loan_rate_txt.TabIndex = 6
        '
        'Guna2HtmlLabel6
        '
        Me.Guna2HtmlLabel6.BackColor = System.Drawing.Color.Transparent
        Me.Guna2HtmlLabel6.Font = New System.Drawing.Font("Microsoft Tai Le", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Guna2HtmlLabel6.Location = New System.Drawing.Point(20, 395)
        Me.Guna2HtmlLabel6.Name = "Guna2HtmlLabel6"
        Me.Guna2HtmlLabel6.Size = New System.Drawing.Size(85, 18)
        Me.Guna2HtmlLabel6.TabIndex = 7
        Me.Guna2HtmlLabel6.Text = "Loan Rate(%)"
        '
        'system_update_btn
        '
        Me.system_update_btn.BorderRadius = 4
        Me.system_update_btn.CheckedState.Parent = Me.system_update_btn
        Me.system_update_btn.Cursor = System.Windows.Forms.Cursors.Hand
        Me.system_update_btn.CustomImages.Parent = Me.system_update_btn
        Me.system_update_btn.FillColor = System.Drawing.Color.FromArgb(CType(CType(47, Byte), Integer), CType(CType(60, Byte), Integer), CType(CType(77, Byte), Integer))
        Me.system_update_btn.FillColor2 = System.Drawing.Color.SlateGray
        Me.system_update_btn.Font = New System.Drawing.Font("Segoe UI", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.system_update_btn.ForeColor = System.Drawing.Color.White
        Me.system_update_btn.HoverState.Parent = Me.system_update_btn
        Me.system_update_btn.Location = New System.Drawing.Point(12, 475)
        Me.system_update_btn.Name = "system_update_btn"
        Me.system_update_btn.ShadowDecoration.Parent = Me.system_update_btn
        Me.system_update_btn.Size = New System.Drawing.Size(150, 50)
        Me.system_update_btn.TabIndex = 8
        Me.system_update_btn.Text = "Update"
        '
        'system_settings
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(534, 579)
        Me.Controls.Add(Me.system_update_btn)
        Me.Controls.Add(Me.Guna2HtmlLabel6)
        Me.Controls.Add(Me.Guna2HtmlLabel5)
        Me.Controls.Add(Me.Guna2HtmlLabel4)
        Me.Controls.Add(Me.loan_rate_txt)
        Me.Controls.Add(Me.Guna2HtmlLabel1)
        Me.Controls.Add(Me.maximum_duration_txt)
        Me.Controls.Add(Me.minimum_loan_txt)
        Me.Controls.Add(Me.Guna2HtmlLabel3)
        Me.Controls.Add(Me.maximum_loan_txt)
        Me.Controls.Add(Me.minimum_balance_txt)
        Me.Controls.Add(Me.Guna2Panel1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.Name = "system_settings"
        Me.ShowInTaskbar = False
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "system_settings"
        Me.Guna2Panel1.ResumeLayout(False)
        Me.Guna2Panel1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents Guna2Panel1 As Guna.UI2.WinForms.Guna2Panel
    Friend WithEvents Guna2HtmlLabel2 As Guna.UI2.WinForms.Guna2HtmlLabel
    Friend WithEvents exit_home As Guna.UI2.WinForms.Guna2Button
    Friend WithEvents Guna2HtmlLabel3 As Guna.UI2.WinForms.Guna2HtmlLabel
    Friend WithEvents minimum_balance_txt As Guna.UI2.WinForms.Guna2TextBox
    Friend WithEvents maximum_loan_txt As Guna.UI2.WinForms.Guna2TextBox
    Friend WithEvents Guna2HtmlLabel1 As Guna.UI2.WinForms.Guna2HtmlLabel
    Friend WithEvents minimum_loan_txt As Guna.UI2.WinForms.Guna2TextBox
    Friend WithEvents Guna2HtmlLabel4 As Guna.UI2.WinForms.Guna2HtmlLabel
    Friend WithEvents maximum_duration_txt As Guna.UI2.WinForms.Guna2TextBox
    Friend WithEvents Guna2HtmlLabel5 As Guna.UI2.WinForms.Guna2HtmlLabel
    Friend WithEvents loan_rate_txt As Guna.UI2.WinForms.Guna2TextBox
    Friend WithEvents Guna2HtmlLabel6 As Guna.UI2.WinForms.Guna2HtmlLabel
    Friend WithEvents system_update_btn As Guna.UI2.WinForms.Guna2GradientButton
End Class
