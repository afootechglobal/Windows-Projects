﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class change_pass
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Guna2Panel1 = New Guna.UI2.WinForms.Guna2Panel()
        Me.Guna2HtmlLabel2 = New Guna.UI2.WinForms.Guna2HtmlLabel()
        Me.exit_home = New Guna.UI2.WinForms.Guna2Button()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.confirmPass_txt = New Guna.UI2.WinForms.Guna2TextBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.newPass_txt = New Guna.UI2.WinForms.Guna2TextBox()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.oldPass_txt = New Guna.UI2.WinForms.Guna2TextBox()
        Me.system_update_btn = New Guna.UI2.WinForms.Guna2GradientButton()
        Me.Guna2Panel1.SuspendLayout()
        Me.SuspendLayout()
        '
        'Guna2Panel1
        '
        Me.Guna2Panel1.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Guna2Panel1.BackColor = System.Drawing.Color.FromArgb(CType(CType(47, Byte), Integer), CType(CType(60, Byte), Integer), CType(CType(77, Byte), Integer))
        Me.Guna2Panel1.Controls.Add(Me.Guna2HtmlLabel2)
        Me.Guna2Panel1.Controls.Add(Me.exit_home)
        Me.Guna2Panel1.Location = New System.Drawing.Point(-1, 0)
        Me.Guna2Panel1.Name = "Guna2Panel1"
        Me.Guna2Panel1.ShadowDecoration.Depth = 55
        Me.Guna2Panel1.ShadowDecoration.Enabled = True
        Me.Guna2Panel1.ShadowDecoration.Parent = Me.Guna2Panel1
        Me.Guna2Panel1.ShadowDecoration.Shadow = New System.Windows.Forms.Padding(0, 0, 0, 2)
        Me.Guna2Panel1.Size = New System.Drawing.Size(561, 45)
        Me.Guna2Panel1.TabIndex = 21
        '
        'Guna2HtmlLabel2
        '
        Me.Guna2HtmlLabel2.BackColor = System.Drawing.Color.Transparent
        Me.Guna2HtmlLabel2.Font = New System.Drawing.Font("Microsoft Tai Le", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Guna2HtmlLabel2.ForeColor = System.Drawing.Color.White
        Me.Guna2HtmlLabel2.Location = New System.Drawing.Point(21, 15)
        Me.Guna2HtmlLabel2.Name = "Guna2HtmlLabel2"
        Me.Guna2HtmlLabel2.Size = New System.Drawing.Size(155, 18)
        Me.Guna2HtmlLabel2.TabIndex = 2
        Me.Guna2HtmlLabel2.Text = "Customer Loan Schedule"
        '
        'exit_home
        '
        Me.exit_home.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.exit_home.Animated = True
        Me.exit_home.CheckedState.Parent = Me.exit_home
        Me.exit_home.Cursor = System.Windows.Forms.Cursors.Hand
        Me.exit_home.CustomImages.Parent = Me.exit_home
        Me.exit_home.FillColor = System.Drawing.Color.Red
        Me.exit_home.Font = New System.Drawing.Font("Segoe UI", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.exit_home.ForeColor = System.Drawing.Color.White
        Me.exit_home.HoverState.FillColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.exit_home.HoverState.Parent = Me.exit_home
        Me.exit_home.Location = New System.Drawing.Point(508, 0)
        Me.exit_home.Name = "exit_home"
        Me.exit_home.ShadowDecoration.Parent = Me.exit_home
        Me.exit_home.Size = New System.Drawing.Size(51, 44)
        Me.exit_home.TabIndex = 1
        Me.exit_home.Text = "x"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.BackColor = System.Drawing.Color.Transparent
        Me.Label2.ForeColor = System.Drawing.Color.Black
        Me.Label2.Location = New System.Drawing.Point(22, 254)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(103, 13)
        Me.Label2.TabIndex = 32
        Me.Label2.Text = "Confirmed Password"
        '
        'confirmPass_txt
        '
        Me.confirmPass_txt.BorderColor = System.Drawing.SystemColors.ControlLight
        Me.confirmPass_txt.BorderRadius = 5
        Me.confirmPass_txt.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.confirmPass_txt.DefaultText = ""
        Me.confirmPass_txt.DisabledState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer))
        Me.confirmPass_txt.DisabledState.FillColor = System.Drawing.Color.FromArgb(CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer))
        Me.confirmPass_txt.DisabledState.ForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.confirmPass_txt.DisabledState.Parent = Me.confirmPass_txt
        Me.confirmPass_txt.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.confirmPass_txt.FocusedState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.confirmPass_txt.FocusedState.Parent = Me.confirmPass_txt
        Me.confirmPass_txt.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.confirmPass_txt.ForeColor = System.Drawing.Color.Black
        Me.confirmPass_txt.HoverState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.confirmPass_txt.HoverState.Parent = Me.confirmPass_txt
        Me.confirmPass_txt.Location = New System.Drawing.Point(20, 276)
        Me.confirmPass_txt.Margin = New System.Windows.Forms.Padding(2)
        Me.confirmPass_txt.Name = "confirmPass_txt"
        Me.confirmPass_txt.PasswordChar = Global.Microsoft.VisualBasic.ChrW(0)
        Me.confirmPass_txt.PlaceholderForeColor = System.Drawing.Color.Black
        Me.confirmPass_txt.PlaceholderText = "ENTER CONFIRMED PASSWORD"
        Me.confirmPass_txt.SelectedText = ""
        Me.confirmPass_txt.ShadowDecoration.Parent = Me.confirmPass_txt
        Me.confirmPass_txt.Size = New System.Drawing.Size(524, 41)
        Me.confirmPass_txt.TabIndex = 31
        Me.confirmPass_txt.UseSystemPasswordChar = True
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.BackColor = System.Drawing.Color.Transparent
        Me.Label1.ForeColor = System.Drawing.Color.Black
        Me.Label1.Location = New System.Drawing.Point(22, 173)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(78, 13)
        Me.Label1.TabIndex = 30
        Me.Label1.Text = "New Password"
        '
        'newPass_txt
        '
        Me.newPass_txt.BorderColor = System.Drawing.SystemColors.ControlLight
        Me.newPass_txt.BorderRadius = 5
        Me.newPass_txt.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.newPass_txt.DefaultText = ""
        Me.newPass_txt.DisabledState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer))
        Me.newPass_txt.DisabledState.FillColor = System.Drawing.Color.FromArgb(CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer))
        Me.newPass_txt.DisabledState.ForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.newPass_txt.DisabledState.Parent = Me.newPass_txt
        Me.newPass_txt.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.newPass_txt.FocusedState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.newPass_txt.FocusedState.Parent = Me.newPass_txt
        Me.newPass_txt.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.newPass_txt.ForeColor = System.Drawing.Color.Black
        Me.newPass_txt.HoverState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.newPass_txt.HoverState.Parent = Me.newPass_txt
        Me.newPass_txt.Location = New System.Drawing.Point(20, 194)
        Me.newPass_txt.Margin = New System.Windows.Forms.Padding(2)
        Me.newPass_txt.Name = "newPass_txt"
        Me.newPass_txt.PasswordChar = Global.Microsoft.VisualBasic.ChrW(0)
        Me.newPass_txt.PlaceholderForeColor = System.Drawing.Color.Black
        Me.newPass_txt.PlaceholderText = "ENTER PASSWORD"
        Me.newPass_txt.SelectedText = ""
        Me.newPass_txt.ShadowDecoration.Parent = Me.newPass_txt
        Me.newPass_txt.Size = New System.Drawing.Size(524, 41)
        Me.newPass_txt.TabIndex = 29
        Me.newPass_txt.UseSystemPasswordChar = True
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.BackColor = System.Drawing.Color.Transparent
        Me.Label7.ForeColor = System.Drawing.Color.Black
        Me.Label7.Location = New System.Drawing.Point(22, 88)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(72, 13)
        Me.Label7.TabIndex = 28
        Me.Label7.Text = "Old Password"
        '
        'oldPass_txt
        '
        Me.oldPass_txt.BorderColor = System.Drawing.SystemColors.ControlLight
        Me.oldPass_txt.BorderRadius = 5
        Me.oldPass_txt.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.oldPass_txt.DefaultText = ""
        Me.oldPass_txt.DisabledState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer))
        Me.oldPass_txt.DisabledState.FillColor = System.Drawing.Color.FromArgb(CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer))
        Me.oldPass_txt.DisabledState.ForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.oldPass_txt.DisabledState.Parent = Me.oldPass_txt
        Me.oldPass_txt.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.oldPass_txt.FocusedState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.oldPass_txt.FocusedState.Parent = Me.oldPass_txt
        Me.oldPass_txt.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.oldPass_txt.ForeColor = System.Drawing.Color.Black
        Me.oldPass_txt.HoverState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.oldPass_txt.HoverState.Parent = Me.oldPass_txt
        Me.oldPass_txt.Location = New System.Drawing.Point(20, 110)
        Me.oldPass_txt.Margin = New System.Windows.Forms.Padding(2)
        Me.oldPass_txt.Name = "oldPass_txt"
        Me.oldPass_txt.PasswordChar = Global.Microsoft.VisualBasic.ChrW(0)
        Me.oldPass_txt.PlaceholderForeColor = System.Drawing.Color.Black
        Me.oldPass_txt.PlaceholderText = "ENTER OLD PASSWORD"
        Me.oldPass_txt.SelectedText = ""
        Me.oldPass_txt.ShadowDecoration.Parent = Me.oldPass_txt
        Me.oldPass_txt.Size = New System.Drawing.Size(524, 41)
        Me.oldPass_txt.TabIndex = 27
        Me.oldPass_txt.UseSystemPasswordChar = True
        '
        'system_update_btn
        '
        Me.system_update_btn.BorderRadius = 4
        Me.system_update_btn.CheckedState.Parent = Me.system_update_btn
        Me.system_update_btn.Cursor = System.Windows.Forms.Cursors.Hand
        Me.system_update_btn.CustomImages.Parent = Me.system_update_btn
        Me.system_update_btn.FillColor = System.Drawing.Color.FromArgb(CType(CType(47, Byte), Integer), CType(CType(60, Byte), Integer), CType(CType(77, Byte), Integer))
        Me.system_update_btn.FillColor2 = System.Drawing.Color.SlateGray
        Me.system_update_btn.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.system_update_btn.ForeColor = System.Drawing.Color.White
        Me.system_update_btn.HoverState.Parent = Me.system_update_btn
        Me.system_update_btn.Location = New System.Drawing.Point(20, 339)
        Me.system_update_btn.Name = "system_update_btn"
        Me.system_update_btn.ShadowDecoration.Parent = Me.system_update_btn
        Me.system_update_btn.Size = New System.Drawing.Size(150, 50)
        Me.system_update_btn.TabIndex = 33
        Me.system_update_btn.Text = "CHANGE PASSWORD"
        '
        'change_pass
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(558, 474)
        Me.Controls.Add(Me.system_update_btn)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.confirmPass_txt)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.newPass_txt)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.oldPass_txt)
        Me.Controls.Add(Me.Guna2Panel1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.Name = "change_pass"
        Me.ShowInTaskbar = False
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "change_pass"
        Me.Guna2Panel1.ResumeLayout(False)
        Me.Guna2Panel1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents Guna2Panel1 As Guna.UI2.WinForms.Guna2Panel
    Friend WithEvents Guna2HtmlLabel2 As Guna.UI2.WinForms.Guna2HtmlLabel
    Friend WithEvents exit_home As Guna.UI2.WinForms.Guna2Button
    Friend WithEvents Label2 As Label
    Friend WithEvents confirmPass_txt As Guna.UI2.WinForms.Guna2TextBox
    Friend WithEvents Label1 As Label
    Friend WithEvents newPass_txt As Guna.UI2.WinForms.Guna2TextBox
    Friend WithEvents Label7 As Label
    Friend WithEvents oldPass_txt As Guna.UI2.WinForms.Guna2TextBox
    Friend WithEvents system_update_btn As Guna.UI2.WinForms.Guna2GradientButton
End Class
