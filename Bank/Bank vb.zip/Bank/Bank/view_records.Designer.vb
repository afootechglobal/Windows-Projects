﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class view_records
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.staffRecord = New System.Windows.Forms.ListView()
        Me.sn = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.staff_id = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.full_name = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.email = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.phone_number = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.role = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.status = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.PASSPORT = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.ColumnHeader1 = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.ColumnHeader2 = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.ColumnHeader3 = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.Guna2Panel3 = New Guna.UI2.WinForms.Guna2Panel()
        Me.record_home_btn = New Guna.UI2.WinForms.Guna2Button()
        Me.Guna2Panel4 = New Guna.UI2.WinForms.Guna2Panel()
        Me.Guna2HtmlLabel2 = New Guna.UI2.WinForms.Guna2HtmlLabel()
        Me.exit_home_btn = New Guna.UI2.WinForms.Guna2Button()
        Me.Guna2Panel3.SuspendLayout()
        Me.Guna2Panel4.SuspendLayout()
        Me.SuspendLayout()
        '
        'staffRecord
        '
        Me.staffRecord.Columns.AddRange(New System.Windows.Forms.ColumnHeader() {Me.sn, Me.staff_id, Me.full_name, Me.email, Me.phone_number, Me.role, Me.status, Me.PASSPORT, Me.ColumnHeader1, Me.ColumnHeader2, Me.ColumnHeader3})
        Me.staffRecord.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.staffRecord.FullRowSelect = True
        Me.staffRecord.GridLines = True
        Me.staffRecord.HideSelection = False
        Me.staffRecord.Location = New System.Drawing.Point(10, 110)
        Me.staffRecord.Name = "staffRecord"
        Me.staffRecord.Size = New System.Drawing.Size(707, 419)
        Me.staffRecord.TabIndex = 7
        Me.staffRecord.UseCompatibleStateImageBehavior = False
        Me.staffRecord.View = System.Windows.Forms.View.Details
        '
        'sn
        '
        Me.sn.Text = "S/N"
        Me.sn.Width = 40
        '
        'staff_id
        '
        Me.staff_id.Text = "STAFF_ID"
        Me.staff_id.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        Me.staff_id.Width = 200
        '
        'full_name
        '
        Me.full_name.Text = "FULL NAME"
        Me.full_name.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        Me.full_name.Width = 200
        '
        'email
        '
        Me.email.Text = "EMAIL ADDRESS"
        Me.email.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        Me.email.Width = 200
        '
        'phone_number
        '
        Me.phone_number.Text = "PHONE NUMBER"
        Me.phone_number.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        Me.phone_number.Width = 200
        '
        'role
        '
        Me.role.Text = "ROLE"
        Me.role.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        Me.role.Width = 200
        '
        'status
        '
        Me.status.Text = "STATUS"
        Me.status.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        Me.status.Width = 200
        '
        'PASSPORT
        '
        Me.PASSPORT.Text = "PASSPORT"
        Me.PASSPORT.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        Me.PASSPORT.Width = 200
        '
        'ColumnHeader1
        '
        Me.ColumnHeader1.Text = "DATE REGISTERED"
        '
        'ColumnHeader2
        '
        Me.ColumnHeader2.Text = "CREATED_TIME"
        '
        'ColumnHeader3
        '
        Me.ColumnHeader3.Text = "UPDATED_TIME"
        '
        'Guna2Panel3
        '
        Me.Guna2Panel3.BackColor = System.Drawing.Color.Silver
        Me.Guna2Panel3.Controls.Add(Me.record_home_btn)
        Me.Guna2Panel3.Location = New System.Drawing.Point(-17, 47)
        Me.Guna2Panel3.Name = "Guna2Panel3"
        Me.Guna2Panel3.ShadowDecoration.Parent = Me.Guna2Panel3
        Me.Guna2Panel3.Size = New System.Drawing.Size(744, 36)
        Me.Guna2Panel3.TabIndex = 6
        '
        'record_home_btn
        '
        Me.record_home_btn.Animated = True
        Me.record_home_btn.BorderRadius = 4
        Me.record_home_btn.CheckedState.Parent = Me.record_home_btn
        Me.record_home_btn.Cursor = System.Windows.Forms.Cursors.Hand
        Me.record_home_btn.CustomImages.Parent = Me.record_home_btn
        Me.record_home_btn.FillColor = System.Drawing.Color.FromArgb(CType(CType(47, Byte), Integer), CType(CType(60, Byte), Integer), CType(CType(77, Byte), Integer))
        Me.record_home_btn.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.record_home_btn.ForeColor = System.Drawing.Color.White
        Me.record_home_btn.HoverState.FillColor = System.Drawing.Color.Gray
        Me.record_home_btn.HoverState.Parent = Me.record_home_btn
        Me.record_home_btn.Location = New System.Drawing.Point(21, 3)
        Me.record_home_btn.Name = "record_home_btn"
        Me.record_home_btn.ShadowDecoration.Parent = Me.record_home_btn
        Me.record_home_btn.Size = New System.Drawing.Size(106, 30)
        Me.record_home_btn.TabIndex = 2
        Me.record_home_btn.Text = "Back"
        '
        'Guna2Panel4
        '
        Me.Guna2Panel4.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Guna2Panel4.BackColor = System.Drawing.Color.FromArgb(CType(CType(47, Byte), Integer), CType(CType(60, Byte), Integer), CType(CType(77, Byte), Integer))
        Me.Guna2Panel4.Controls.Add(Me.Guna2HtmlLabel2)
        Me.Guna2Panel4.Controls.Add(Me.exit_home_btn)
        Me.Guna2Panel4.Location = New System.Drawing.Point(-1, 0)
        Me.Guna2Panel4.Name = "Guna2Panel4"
        Me.Guna2Panel4.ShadowDecoration.Depth = 55
        Me.Guna2Panel4.ShadowDecoration.Enabled = True
        Me.Guna2Panel4.ShadowDecoration.Parent = Me.Guna2Panel4
        Me.Guna2Panel4.ShadowDecoration.Shadow = New System.Windows.Forms.Padding(0, 0, 0, 2)
        Me.Guna2Panel4.Size = New System.Drawing.Size(736, 40)
        Me.Guna2Panel4.TabIndex = 5
        '
        'Guna2HtmlLabel2
        '
        Me.Guna2HtmlLabel2.BackColor = System.Drawing.Color.Transparent
        Me.Guna2HtmlLabel2.Font = New System.Drawing.Font("Microsoft Tai Le", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Guna2HtmlLabel2.ForeColor = System.Drawing.Color.White
        Me.Guna2HtmlLabel2.Location = New System.Drawing.Point(11, 12)
        Me.Guna2HtmlLabel2.Name = "Guna2HtmlLabel2"
        Me.Guna2HtmlLabel2.Size = New System.Drawing.Size(96, 18)
        Me.Guna2HtmlLabel2.TabIndex = 3
        Me.Guna2HtmlLabel2.Text = "Admin Records"
        '
        'exit_home_btn
        '
        Me.exit_home_btn.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.exit_home_btn.Animated = True
        Me.exit_home_btn.CheckedState.Parent = Me.exit_home_btn
        Me.exit_home_btn.Cursor = System.Windows.Forms.Cursors.Hand
        Me.exit_home_btn.CustomImages.Parent = Me.exit_home_btn
        Me.exit_home_btn.FillColor = System.Drawing.Color.Red
        Me.exit_home_btn.Font = New System.Drawing.Font("Segoe UI", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.exit_home_btn.ForeColor = System.Drawing.Color.White
        Me.exit_home_btn.HoverState.FillColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.exit_home_btn.HoverState.Parent = Me.exit_home_btn
        Me.exit_home_btn.Location = New System.Drawing.Point(677, 0)
        Me.exit_home_btn.Name = "exit_home_btn"
        Me.exit_home_btn.ShadowDecoration.Parent = Me.exit_home_btn
        Me.exit_home_btn.Size = New System.Drawing.Size(51, 40)
        Me.exit_home_btn.TabIndex = 1
        Me.exit_home_btn.Text = "x"
        '
        'view_records
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(725, 535)
        Me.Controls.Add(Me.staffRecord)
        Me.Controls.Add(Me.Guna2Panel3)
        Me.Controls.Add(Me.Guna2Panel4)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.Name = "view_records"
        Me.ShowInTaskbar = False
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "view_records"
        Me.Guna2Panel3.ResumeLayout(False)
        Me.Guna2Panel4.ResumeLayout(False)
        Me.Guna2Panel4.PerformLayout()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents staffRecord As ListView
    Friend WithEvents sn As ColumnHeader
    Friend WithEvents staff_id As ColumnHeader
    Friend WithEvents full_name As ColumnHeader
    Friend WithEvents email As ColumnHeader
    Friend WithEvents phone_number As ColumnHeader
    Friend WithEvents role As ColumnHeader
    Friend WithEvents status As ColumnHeader
    Friend WithEvents PASSPORT As ColumnHeader
    Friend WithEvents Guna2Panel3 As Guna.UI2.WinForms.Guna2Panel
    Friend WithEvents record_home_btn As Guna.UI2.WinForms.Guna2Button
    Friend WithEvents Guna2Panel4 As Guna.UI2.WinForms.Guna2Panel
    Friend WithEvents exit_home_btn As Guna.UI2.WinForms.Guna2Button
    Friend WithEvents Guna2HtmlLabel2 As Guna.UI2.WinForms.Guna2HtmlLabel
    Friend WithEvents ColumnHeader1 As ColumnHeader
    Friend WithEvents ColumnHeader2 As ColumnHeader
    Friend WithEvents ColumnHeader3 As ColumnHeader
End Class
