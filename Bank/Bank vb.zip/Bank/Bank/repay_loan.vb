﻿Imports MySql.Data.MySqlClient

Public Class repay_loan
    Dim reader As MySqlDataReader
    Dim command As MySqlCommand
    Dim query As String
    Private Sub exit_home_Click(sender As Object, e As EventArgs) Handles exit_home.Click
        Me.Close()
        index.Hide()
    End Sub

    Private Sub ClearButton_Click(sender As Object, e As EventArgs) Handles ClearButton.Click
        repay_txt.Text = ""
    End Sub

    Private Sub SubmitButton_Click(sender As Object, e As EventArgs) Handles SubmitButton.Click
        Dim connection = functions.connection
        Dim repayment_amount As Double = Double.Parse(repay_txt.Text)
        Dim remaining_balance As Double

        If repay_txt.Text = "" Then
            MessageBox.Show("ERROR! ENTER AMOUNT TO CONTINUE", "Bank Application Software", MessageBoxButtons.OK, MessageBoxIcon.Error)
        Else
            Dim result = functions.getCustomerProfile(userlog.login_customer_id)
            Dim account_balance = Double.Parse(result.item3)
            Dim loan_balance = Double.Parse(result.item4)

            Dim total_repayment = functions.Getrepayment(user_loan_request.transaction_id)

            If repayment_amount > account_balance Then
                MessageBox.Show("ERROR! INSUFFICIENT ACCOUNT BALANCE", "Bank Application Software", MessageBoxButtons.OK, MessageBoxIcon.Information)
            ElseIf repayment_amount > loan_balance Then
                MessageBox.Show("ERROR! YOU ARE TRYING TO PAY MORE THAN THE LOAN BALANCE", "Bank Application Software", MessageBoxButtons.OK, MessageBoxIcon.Information)
            ElseIf repayment_amount < total_repayment Then
                MessageBox.Show("ERROR! REPAYMENT AMOUNT IS LESS THAN THE REQUIRED MONTHLY INSTALLMENT", "Bank Application Software", MessageBoxButtons.OK, MessageBoxIcon.Information)
            ElseIf repayment_amount Mod total_repayment <> 0 Then
                MessageBox.Show("ERROR! REPAYMENT AMOUNT MUST BE A MULTIPLE OF THE MONTHLY INSTALLMENT", "Bank Application Software", MessageBoxButtons.OK, MessageBoxIcon.Information)
            Else
                Dim months_to_pay As Integer = CInt(repayment_amount / total_repayment)

                If repayment_amount > loan_balance Then
                    MessageBox.Show("ERROR! YOU ARE TRYING TO PAY MORE THAN THE LOAN BALANCE", "Bank Application Software", MessageBoxButtons.OK, MessageBoxIcon.Information)
                Else
                    remaining_balance = account_balance - repayment_amount
                    loan_balance -= repayment_amount

                    connection.open()
                    query = "UPDATE account_tab SET loan_balance=@loan_balance, account_balance=@account_balance WHERE customer_id=@customer_id"
                    command = New MySqlCommand(query, connection)
                    command.Parameters.AddWithValue("@loan_balance", loan_balance)
                    command.Parameters.AddWithValue("@customer_id", userlog.login_customer_id)
                    command.Parameters.AddWithValue("@account_balance", remaining_balance)
                    command.ExecuteNonQuery()
                    connection.Close()

                    MessageBox.Show("LOAN REPAYMENT SUCCESSFUL FOR " & months_to_pay & " MONTH(S)!", "Bank Application Software", MessageBoxButtons.OK, MessageBoxIcon.Information)
                    functions.getCustomerProfile(userlog.login_customer_id)
                    repay_txt.Text = ""
                End If
            End If
        End If

    End Sub
End Class