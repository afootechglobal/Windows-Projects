﻿Imports MySql.Data.MySqlClient
Imports System.Text.RegularExpressions
Public Class userlog
    Dim reader As MySqlDataReader
    Dim command As MySqlCommand
    Dim query As String
    Public customer_id, fullname, email_address, login_status_id, login_customer_id As String
    Private Sub exit_home_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles exit_home.Click
        Dim answer As Integer
        answer = MessageBox.Show("Are you sure you want to Exit", "Exit Application", MessageBoxButtons.YesNo, MessageBoxIcon.Question)
        If answer = vbYes Then
            Me.Close()
        End If
    End Sub


    Private Sub forgotpass_link_LinkClicked_2(ByVal sender As System.Object, ByVal e As System.Windows.Forms.LinkLabelLinkClickedEventArgs) Handles forgotpass_link.LinkClicked
        resetpass_panel.Show()
        login_panel.Hide()
    End Sub

    Private Sub login_link_LinkClicked_1(ByVal sender As System.Object, ByVal e As System.Windows.Forms.LinkLabelLinkClickedEventArgs) Handles login_link.LinkClicked
        login_panel.Show()
        resetpass_panel.Hide()
    End Sub

    Private Sub proceed_btn_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles proceed_btn.Click
        If Guna2TextBox3.Text = "" Then
            MessageBox.Show("Error! Input your Email Address to Continue!", "Information", MessageBoxButtons.OK, MessageBoxIcon.Error)
        ElseIf functions.emailValidate(Guna2TextBox3.Text) = False Then
            MessageBox.Show("Invalid Email Address", "Bank System Software", MessageBoxButtons.OK, MessageBoxIcon.Error)
            Exit Sub
        Else
            Try
                reader = functions.customerEmailCheck(Guna2TextBox3.Text)
                If reader.HasRows Then
                    customer_id = reader("customer_id")
                    Dim status_id = reader("status_id")
                    fullname = reader("fullname")
                    email_address = reader("email")

                    If status_id = 1 Then
                        Dim otp As String = New Random().Next(100000, 999999).ToString()

                        Dim connection = functions.connection

                        connection.Open()
                        command = New MySqlCommand("UPDATE customer_tab SET otp=@otp WHERE customer_id=@customer_id", connection)
                        command.Parameters.AddWithValue("@customer_id", customer_id)
                        command.Parameters.AddWithValue("@otp", otp)
                        reader = command.ExecuteReader
                        connection.Close()

                        reset_password.Show()
                        Me.Hide()
                        index.Hide()
                    Else
                        MessageBox.Show("ERROR! Account has been Suspended", "Bank System Software", MessageBoxButtons.OK, MessageBoxIcon.Error)
                    End If
                Else
                    MessageBox.Show("Email Address not Found!", "Bank System Software", MessageBoxButtons.OK, MessageBoxIcon.Error)
                    Exit Sub
                End If
            Catch ex As Exception
                MsgBox(ex.ToString)
            End Try
        End If
    End Sub




    Private Sub user_login_btn_Click(sender As Object, e As EventArgs) Handles user_login_btn.Click
        If email_txt.Text = "" Or password_txt.Text = "" Then
            MessageBox.Show("ERROR! All fields are required!", "Bank System Software", MessageBoxButtons.OK, MessageBoxIcon.Error)
        ElseIf functions.emailValidate(email_txt.Text) = False Then
            MessageBox.Show("Invalid Email Address", "Bank System Software", MessageBoxButtons.OK, MessageBoxIcon.Error)
            Exit Sub
        Else
            Dim connection = functions.connection

            Try
                connection.Open()
                command = New MySqlCommand("SELECT * FROM customer_tab WHERE email=@email", connection)
                command.Parameters.AddWithValue("@email", email_txt.Text)
                reader = command.ExecuteReader
                reader.Read()

                If reader.HasRows Then
                    Dim storedHash As String = reader("password").ToString()
                    If BCrypt.Net.BCrypt.Verify(password_txt.Text, storedHash) Then

                        login_customer_id = reader("customer_id")
                        login_status_id = reader("status_id")
                        connection.Close()

                        ' Check if the customer_id has an account in account_tab
                        Dim accountCheckCommand = New MySqlCommand("SELECT * FROM account_tab WHERE customer_id=@customer_id", connection)
                        accountCheckCommand.Parameters.AddWithValue("@customer_id", login_customer_id)

                        connection.Open()
                        Dim accountReader = accountCheckCommand.ExecuteReader()

                        If accountReader.HasRows Then
                            ' Customer has an account
                            connection.Close()

                            If login_status_id = 1 Then
                                connection.Open()
                                command = New MySqlCommand("UPDATE customer_tab SET last_login=NOW() WHERE customer_id=@customer_id", connection)
                                command.Parameters.AddWithValue("@customer_id", login_customer_id)
                                reader = command.ExecuteReader()
                                connection.Close()

                                Me.Hide()
                                index.Hide()
                                functions.directToUserDashboard()

                            Else
                                MessageBox.Show("ERROR! Account has been Suspended", "Bank System Software", MessageBoxButtons.OK, MessageBoxIcon.Error)
                            End If

                        Else
                            ' Customer does not have an account
                            MessageBox.Show("ERROR! This customer does not have an account.", "Bank System Software", MessageBoxButtons.OK, MessageBoxIcon.Error)
                        End If

                    Else
                        MessageBox.Show("ERROR! Invalid password!", "Bank System Software", MessageBoxButtons.OK, MessageBoxIcon.Error)
                    End If
                Else
                    MessageBox.Show("ERROR! Invalid email address!", "Bank System Software", MessageBoxButtons.OK, MessageBoxIcon.Error)
                End If

            Catch ex As Exception
                MsgBox(ex.ToString)
            End Try
        End If
    End Sub
End Class