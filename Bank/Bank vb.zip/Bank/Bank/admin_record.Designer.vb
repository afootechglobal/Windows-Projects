﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class admin_record
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.phoneno_txt = New Guna.UI2.WinForms.Guna2TextBox()
        Me.Guna2HtmlLabel4 = New Guna.UI2.WinForms.Guna2HtmlLabel()
        Me.profile_id = New Guna.UI2.WinForms.Guna2ComboBox()
        Me.Guna2HtmlLabel5 = New Guna.UI2.WinForms.Guna2HtmlLabel()
        Me.Guna2Panel1 = New Guna.UI2.WinForms.Guna2Panel()
        Me.Guna2HtmlLabel2 = New Guna.UI2.WinForms.Guna2HtmlLabel()
        Me.exit_home = New Guna.UI2.WinForms.Guna2Button()
        Me.Guna2HtmlLabel3 = New Guna.UI2.WinForms.Guna2HtmlLabel()
        Me.submit_btn = New Guna.UI2.WinForms.Guna2Button()
        Me.email_txt = New Guna.UI2.WinForms.Guna2TextBox()
        Me.select_btn = New Guna.UI2.WinForms.Guna2Button()
        Me.fullname_txt = New Guna.UI2.WinForms.Guna2TextBox()
        Me.GroupBox3 = New System.Windows.Forms.GroupBox()
        Me.picture_box = New Guna.UI2.WinForms.Guna2PictureBox()
        Me.GroupBox2 = New System.Windows.Forms.GroupBox()
        Me.StatusComboBox = New Guna.UI2.WinForms.Guna2ComboBox()
        Me.RoleComboBox = New Guna.UI2.WinForms.Guna2ComboBox()
        Me.Guna2HtmlLabel7 = New Guna.UI2.WinForms.Guna2HtmlLabel()
        Me.Guna2HtmlLabel6 = New Guna.UI2.WinForms.Guna2HtmlLabel()
        Me.Guna2Panel2 = New Guna.UI2.WinForms.Guna2Panel()
        Me.counter_val_txt = New Guna.UI2.WinForms.Guna2HtmlLabel()
        Me.Guna2HtmlLabel1 = New Guna.UI2.WinForms.Guna2HtmlLabel()
        Me.view_btn = New Guna.UI2.WinForms.Guna2Button()
        Me.main_clear = New Guna.UI2.WinForms.Guna2Button()
        Me.fetch_btn = New Guna.UI2.WinForms.Guna2Button()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.Guna2Panel1.SuspendLayout()
        Me.GroupBox3.SuspendLayout()
        CType(Me.picture_box, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox2.SuspendLayout()
        Me.Guna2Panel2.SuspendLayout()
        Me.GroupBox1.SuspendLayout()
        Me.SuspendLayout()
        '
        'phoneno_txt
        '
        Me.phoneno_txt.BorderRadius = 3
        Me.phoneno_txt.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.phoneno_txt.DefaultText = ""
        Me.phoneno_txt.DisabledState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer))
        Me.phoneno_txt.DisabledState.FillColor = System.Drawing.Color.FromArgb(CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer))
        Me.phoneno_txt.DisabledState.ForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.phoneno_txt.DisabledState.Parent = Me.phoneno_txt
        Me.phoneno_txt.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.phoneno_txt.FocusedState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.phoneno_txt.FocusedState.Parent = Me.phoneno_txt
        Me.phoneno_txt.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.phoneno_txt.ForeColor = System.Drawing.Color.Black
        Me.phoneno_txt.HoverState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.phoneno_txt.HoverState.Parent = Me.phoneno_txt
        Me.phoneno_txt.Location = New System.Drawing.Point(13, 196)
        Me.phoneno_txt.Margin = New System.Windows.Forms.Padding(9, 6, 9, 6)
        Me.phoneno_txt.Name = "phoneno_txt"
        Me.phoneno_txt.PasswordChar = Global.Microsoft.VisualBasic.ChrW(0)
        Me.phoneno_txt.PlaceholderText = "ENTER PHONE NUMBER"
        Me.phoneno_txt.SelectedText = ""
        Me.phoneno_txt.ShadowDecoration.Parent = Me.phoneno_txt
        Me.phoneno_txt.Size = New System.Drawing.Size(423, 47)
        Me.phoneno_txt.TabIndex = 0
        '
        'Guna2HtmlLabel4
        '
        Me.Guna2HtmlLabel4.BackColor = System.Drawing.Color.Transparent
        Me.Guna2HtmlLabel4.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Guna2HtmlLabel4.Location = New System.Drawing.Point(25, 104)
        Me.Guna2HtmlLabel4.Name = "Guna2HtmlLabel4"
        Me.Guna2HtmlLabel4.Size = New System.Drawing.Size(100, 17)
        Me.Guna2HtmlLabel4.TabIndex = 2
        Me.Guna2HtmlLabel4.Text = "EMAIL ADDRESS"
        '
        'profile_id
        '
        Me.profile_id.BackColor = System.Drawing.Color.Transparent
        Me.profile_id.Cursor = System.Windows.Forms.Cursors.Hand
        Me.profile_id.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed
        Me.profile_id.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.profile_id.FocusedColor = System.Drawing.Color.Empty
        Me.profile_id.FocusedState.Parent = Me.profile_id
        Me.profile_id.Font = New System.Drawing.Font("Segoe UI", 10.0!)
        Me.profile_id.ForeColor = System.Drawing.Color.FromArgb(CType(CType(68, Byte), Integer), CType(CType(88, Byte), Integer), CType(CType(112, Byte), Integer))
        Me.profile_id.FormattingEnabled = True
        Me.profile_id.HoverState.Parent = Me.profile_id
        Me.profile_id.IntegralHeight = False
        Me.profile_id.ItemHeight = 25
        Me.profile_id.ItemsAppearance.Parent = Me.profile_id
        Me.profile_id.Location = New System.Drawing.Point(13, 20)
        Me.profile_id.Name = "profile_id"
        Me.profile_id.ShadowDecoration.Parent = Me.profile_id
        Me.profile_id.Size = New System.Drawing.Size(717, 31)
        Me.profile_id.TabIndex = 0
        '
        'Guna2HtmlLabel5
        '
        Me.Guna2HtmlLabel5.BackColor = System.Drawing.Color.Transparent
        Me.Guna2HtmlLabel5.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Guna2HtmlLabel5.Location = New System.Drawing.Point(26, 176)
        Me.Guna2HtmlLabel5.Name = "Guna2HtmlLabel5"
        Me.Guna2HtmlLabel5.Size = New System.Drawing.Size(103, 17)
        Me.Guna2HtmlLabel5.TabIndex = 2
        Me.Guna2HtmlLabel5.Text = "PHONE NUMBER"
        '
        'Guna2Panel1
        '
        Me.Guna2Panel1.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Guna2Panel1.BackColor = System.Drawing.Color.FromArgb(CType(CType(47, Byte), Integer), CType(CType(60, Byte), Integer), CType(CType(77, Byte), Integer))
        Me.Guna2Panel1.Controls.Add(Me.Guna2HtmlLabel2)
        Me.Guna2Panel1.Controls.Add(Me.exit_home)
        Me.Guna2Panel1.Location = New System.Drawing.Point(-6, -8)
        Me.Guna2Panel1.Name = "Guna2Panel1"
        Me.Guna2Panel1.ShadowDecoration.Depth = 55
        Me.Guna2Panel1.ShadowDecoration.Enabled = True
        Me.Guna2Panel1.ShadowDecoration.Parent = Me.Guna2Panel1
        Me.Guna2Panel1.ShadowDecoration.Shadow = New System.Windows.Forms.Padding(0, 0, 0, 2)
        Me.Guna2Panel1.Size = New System.Drawing.Size(758, 40)
        Me.Guna2Panel1.TabIndex = 4
        '
        'Guna2HtmlLabel2
        '
        Me.Guna2HtmlLabel2.BackColor = System.Drawing.Color.Transparent
        Me.Guna2HtmlLabel2.Font = New System.Drawing.Font("Microsoft Tai Le", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Guna2HtmlLabel2.ForeColor = System.Drawing.Color.White
        Me.Guna2HtmlLabel2.Location = New System.Drawing.Point(14, 17)
        Me.Guna2HtmlLabel2.Name = "Guna2HtmlLabel2"
        Me.Guna2HtmlLabel2.Size = New System.Drawing.Size(96, 18)
        Me.Guna2HtmlLabel2.TabIndex = 2
        Me.Guna2HtmlLabel2.Text = "Admin Records"
        '
        'exit_home
        '
        Me.exit_home.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.exit_home.Animated = True
        Me.exit_home.CheckedState.Parent = Me.exit_home
        Me.exit_home.Cursor = System.Windows.Forms.Cursors.Hand
        Me.exit_home.CustomImages.Parent = Me.exit_home
        Me.exit_home.FillColor = System.Drawing.Color.Red
        Me.exit_home.Font = New System.Drawing.Font("Segoe UI", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.exit_home.ForeColor = System.Drawing.Color.White
        Me.exit_home.HoverState.FillColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.exit_home.HoverState.Parent = Me.exit_home
        Me.exit_home.Location = New System.Drawing.Point(696, 3)
        Me.exit_home.Name = "exit_home"
        Me.exit_home.ShadowDecoration.Parent = Me.exit_home
        Me.exit_home.Size = New System.Drawing.Size(51, 39)
        Me.exit_home.TabIndex = 1
        Me.exit_home.Text = "x"
        '
        'Guna2HtmlLabel3
        '
        Me.Guna2HtmlLabel3.BackColor = System.Drawing.Color.Transparent
        Me.Guna2HtmlLabel3.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Guna2HtmlLabel3.Location = New System.Drawing.Point(25, 37)
        Me.Guna2HtmlLabel3.Name = "Guna2HtmlLabel3"
        Me.Guna2HtmlLabel3.Size = New System.Drawing.Size(68, 17)
        Me.Guna2HtmlLabel3.TabIndex = 2
        Me.Guna2HtmlLabel3.Text = "FULLNAME"
        '
        'submit_btn
        '
        Me.submit_btn.Animated = True
        Me.submit_btn.BorderRadius = 3
        Me.submit_btn.CheckedState.Parent = Me.submit_btn
        Me.submit_btn.Cursor = System.Windows.Forms.Cursors.Hand
        Me.submit_btn.CustomImages.Parent = Me.submit_btn
        Me.submit_btn.FillColor = System.Drawing.Color.DarkRed
        Me.submit_btn.Font = New System.Drawing.Font("Segoe UI", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.submit_btn.ForeColor = System.Drawing.Color.White
        Me.submit_btn.HoverState.FillColor = System.Drawing.Color.Red
        Me.submit_btn.HoverState.Parent = Me.submit_btn
        Me.submit_btn.Location = New System.Drawing.Point(480, 445)
        Me.submit_btn.Name = "submit_btn"
        Me.submit_btn.ShadowDecoration.Parent = Me.submit_btn
        Me.submit_btn.Size = New System.Drawing.Size(114, 46)
        Me.submit_btn.TabIndex = 9
        Me.submit_btn.Text = "SUBMIT"
        '
        'email_txt
        '
        Me.email_txt.BorderRadius = 3
        Me.email_txt.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.email_txt.DefaultText = ""
        Me.email_txt.DisabledState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer))
        Me.email_txt.DisabledState.FillColor = System.Drawing.Color.FromArgb(CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer))
        Me.email_txt.DisabledState.ForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.email_txt.DisabledState.Parent = Me.email_txt
        Me.email_txt.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.email_txt.FocusedState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.email_txt.FocusedState.Parent = Me.email_txt
        Me.email_txt.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.email_txt.ForeColor = System.Drawing.Color.Black
        Me.email_txt.HoverState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.email_txt.HoverState.Parent = Me.email_txt
        Me.email_txt.Location = New System.Drawing.Point(11, 123)
        Me.email_txt.Margin = New System.Windows.Forms.Padding(6, 5, 6, 5)
        Me.email_txt.Name = "email_txt"
        Me.email_txt.PasswordChar = Global.Microsoft.VisualBasic.ChrW(0)
        Me.email_txt.PlaceholderText = "ENTER EMAIL ADDRESS"
        Me.email_txt.SelectedText = ""
        Me.email_txt.ShadowDecoration.Parent = Me.email_txt
        Me.email_txt.Size = New System.Drawing.Size(423, 47)
        Me.email_txt.TabIndex = 0
        '
        'select_btn
        '
        Me.select_btn.Animated = True
        Me.select_btn.BorderRadius = 3
        Me.select_btn.CheckedState.Parent = Me.select_btn
        Me.select_btn.Cursor = System.Windows.Forms.Cursors.Hand
        Me.select_btn.CustomImages.Parent = Me.select_btn
        Me.select_btn.FillColor = System.Drawing.Color.Silver
        Me.select_btn.Font = New System.Drawing.Font("Segoe UI", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.select_btn.ForeColor = System.Drawing.Color.White
        Me.select_btn.HoverState.FillColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.select_btn.HoverState.Parent = Me.select_btn
        Me.select_btn.Location = New System.Drawing.Point(31, 198)
        Me.select_btn.Name = "select_btn"
        Me.select_btn.ShadowDecoration.Parent = Me.select_btn
        Me.select_btn.Size = New System.Drawing.Size(188, 37)
        Me.select_btn.TabIndex = 3
        Me.select_btn.Text = "SELECT PICTURE"
        '
        'fullname_txt
        '
        Me.fullname_txt.BorderRadius = 3
        Me.fullname_txt.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.fullname_txt.DefaultText = ""
        Me.fullname_txt.DisabledState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer))
        Me.fullname_txt.DisabledState.FillColor = System.Drawing.Color.FromArgb(CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer))
        Me.fullname_txt.DisabledState.ForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.fullname_txt.DisabledState.Parent = Me.fullname_txt
        Me.fullname_txt.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.fullname_txt.FocusedState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.fullname_txt.FocusedState.Parent = Me.fullname_txt
        Me.fullname_txt.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.fullname_txt.ForeColor = System.Drawing.Color.Black
        Me.fullname_txt.HoverState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.fullname_txt.HoverState.Parent = Me.fullname_txt
        Me.fullname_txt.Location = New System.Drawing.Point(11, 57)
        Me.fullname_txt.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.fullname_txt.Name = "fullname_txt"
        Me.fullname_txt.PasswordChar = Global.Microsoft.VisualBasic.ChrW(0)
        Me.fullname_txt.PlaceholderText = "ENTER FULLNAME"
        Me.fullname_txt.SelectedText = ""
        Me.fullname_txt.ShadowDecoration.Parent = Me.fullname_txt
        Me.fullname_txt.Size = New System.Drawing.Size(423, 38)
        Me.fullname_txt.TabIndex = 0
        '
        'GroupBox3
        '
        Me.GroupBox3.Controls.Add(Me.picture_box)
        Me.GroupBox3.Controls.Add(Me.select_btn)
        Me.GroupBox3.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox3.Location = New System.Drawing.Point(481, 180)
        Me.GroupBox3.Name = "GroupBox3"
        Me.GroupBox3.Size = New System.Drawing.Size(244, 241)
        Me.GroupBox3.TabIndex = 6
        Me.GroupBox3.TabStop = False
        Me.GroupBox3.Text = "PASSPORT"
        '
        'picture_box
        '
        Me.picture_box.BackgroundImage = Global.Bank.My.Resources.Resources.person
        Me.picture_box.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.picture_box.Location = New System.Drawing.Point(53, 48)
        Me.picture_box.Name = "picture_box"
        Me.picture_box.ShadowDecoration.Parent = Me.picture_box
        Me.picture_box.Size = New System.Drawing.Size(140, 131)
        Me.picture_box.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.picture_box.TabIndex = 4
        Me.picture_box.TabStop = False
        '
        'GroupBox2
        '
        Me.GroupBox2.Controls.Add(Me.StatusComboBox)
        Me.GroupBox2.Controls.Add(Me.RoleComboBox)
        Me.GroupBox2.Controls.Add(Me.Guna2HtmlLabel7)
        Me.GroupBox2.Controls.Add(Me.phoneno_txt)
        Me.GroupBox2.Controls.Add(Me.Guna2HtmlLabel6)
        Me.GroupBox2.Controls.Add(Me.Guna2HtmlLabel5)
        Me.GroupBox2.Controls.Add(Me.Guna2HtmlLabel4)
        Me.GroupBox2.Controls.Add(Me.Guna2HtmlLabel3)
        Me.GroupBox2.Controls.Add(Me.email_txt)
        Me.GroupBox2.Controls.Add(Me.fullname_txt)
        Me.GroupBox2.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox2.Location = New System.Drawing.Point(2, 180)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(450, 387)
        Me.GroupBox2.TabIndex = 7
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "Staff information"
        '
        'StatusComboBox
        '
        Me.StatusComboBox.BackColor = System.Drawing.Color.Transparent
        Me.StatusComboBox.Cursor = System.Windows.Forms.Cursors.Hand
        Me.StatusComboBox.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed
        Me.StatusComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.StatusComboBox.FocusedColor = System.Drawing.Color.Empty
        Me.StatusComboBox.FocusedState.Parent = Me.StatusComboBox
        Me.StatusComboBox.Font = New System.Drawing.Font("Segoe UI", 10.0!)
        Me.StatusComboBox.ForeColor = System.Drawing.Color.FromArgb(CType(CType(68, Byte), Integer), CType(CType(88, Byte), Integer), CType(CType(112, Byte), Integer))
        Me.StatusComboBox.FormattingEnabled = True
        Me.StatusComboBox.HoverState.Parent = Me.StatusComboBox
        Me.StatusComboBox.IntegralHeight = False
        Me.StatusComboBox.ItemHeight = 35
        Me.StatusComboBox.ItemsAppearance.Parent = Me.StatusComboBox
        Me.StatusComboBox.Location = New System.Drawing.Point(11, 332)
        Me.StatusComboBox.Name = "StatusComboBox"
        Me.StatusComboBox.ShadowDecoration.Parent = Me.StatusComboBox
        Me.StatusComboBox.Size = New System.Drawing.Size(423, 41)
        Me.StatusComboBox.TabIndex = 0
        '
        'RoleComboBox
        '
        Me.RoleComboBox.BackColor = System.Drawing.Color.Transparent
        Me.RoleComboBox.Cursor = System.Windows.Forms.Cursors.Hand
        Me.RoleComboBox.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed
        Me.RoleComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.RoleComboBox.FocusedColor = System.Drawing.Color.Empty
        Me.RoleComboBox.FocusedState.Parent = Me.RoleComboBox
        Me.RoleComboBox.Font = New System.Drawing.Font("Segoe UI", 10.0!)
        Me.RoleComboBox.ForeColor = System.Drawing.Color.FromArgb(CType(CType(68, Byte), Integer), CType(CType(88, Byte), Integer), CType(CType(112, Byte), Integer))
        Me.RoleComboBox.FormattingEnabled = True
        Me.RoleComboBox.HoverState.Parent = Me.RoleComboBox
        Me.RoleComboBox.IntegralHeight = False
        Me.RoleComboBox.ItemHeight = 35
        Me.RoleComboBox.ItemsAppearance.Parent = Me.RoleComboBox
        Me.RoleComboBox.Location = New System.Drawing.Point(10, 269)
        Me.RoleComboBox.Name = "RoleComboBox"
        Me.RoleComboBox.ShadowDecoration.Parent = Me.RoleComboBox
        Me.RoleComboBox.Size = New System.Drawing.Size(423, 41)
        Me.RoleComboBox.TabIndex = 0
        '
        'Guna2HtmlLabel7
        '
        Me.Guna2HtmlLabel7.BackColor = System.Drawing.Color.Transparent
        Me.Guna2HtmlLabel7.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Guna2HtmlLabel7.Location = New System.Drawing.Point(26, 314)
        Me.Guna2HtmlLabel7.Name = "Guna2HtmlLabel7"
        Me.Guna2HtmlLabel7.Size = New System.Drawing.Size(88, 17)
        Me.Guna2HtmlLabel7.TabIndex = 2
        Me.Guna2HtmlLabel7.Text = "STAFF STATUS"
        '
        'Guna2HtmlLabel6
        '
        Me.Guna2HtmlLabel6.BackColor = System.Drawing.Color.Transparent
        Me.Guna2HtmlLabel6.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Guna2HtmlLabel6.Location = New System.Drawing.Point(25, 251)
        Me.Guna2HtmlLabel6.Name = "Guna2HtmlLabel6"
        Me.Guna2HtmlLabel6.Size = New System.Drawing.Size(75, 17)
        Me.Guna2HtmlLabel6.TabIndex = 2
        Me.Guna2HtmlLabel6.Text = "STAFF ROLE"
        '
        'Guna2Panel2
        '
        Me.Guna2Panel2.BackColor = System.Drawing.Color.Silver
        Me.Guna2Panel2.Controls.Add(Me.counter_val_txt)
        Me.Guna2Panel2.Controls.Add(Me.Guna2HtmlLabel1)
        Me.Guna2Panel2.Controls.Add(Me.view_btn)
        Me.Guna2Panel2.Location = New System.Drawing.Point(-6, 34)
        Me.Guna2Panel2.Name = "Guna2Panel2"
        Me.Guna2Panel2.ShadowDecoration.Parent = Me.Guna2Panel2
        Me.Guna2Panel2.Size = New System.Drawing.Size(758, 36)
        Me.Guna2Panel2.TabIndex = 5
        '
        'counter_val_txt
        '
        Me.counter_val_txt.BackColor = System.Drawing.Color.Transparent
        Me.counter_val_txt.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.counter_val_txt.ForeColor = System.Drawing.Color.Red
        Me.counter_val_txt.Location = New System.Drawing.Point(728, 8)
        Me.counter_val_txt.Name = "counter_val_txt"
        Me.counter_val_txt.Size = New System.Drawing.Size(12, 20)
        Me.counter_val_txt.TabIndex = 2
        Me.counter_val_txt.Text = "0"
        '
        'Guna2HtmlLabel1
        '
        Me.Guna2HtmlLabel1.BackColor = System.Drawing.Color.Transparent
        Me.Guna2HtmlLabel1.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Guna2HtmlLabel1.Location = New System.Drawing.Point(619, 8)
        Me.Guna2HtmlLabel1.Name = "Guna2HtmlLabel1"
        Me.Guna2HtmlLabel1.Size = New System.Drawing.Size(104, 20)
        Me.Guna2HtmlLabel1.TabIndex = 2
        Me.Guna2HtmlLabel1.Text = "TOTAL STAFF:"
        '
        'view_btn
        '
        Me.view_btn.Animated = True
        Me.view_btn.BackColor = System.Drawing.Color.FromArgb(CType(CType(47, Byte), Integer), CType(CType(60, Byte), Integer), CType(CType(77, Byte), Integer))
        Me.view_btn.BorderRadius = 4
        Me.view_btn.CheckedState.Parent = Me.view_btn
        Me.view_btn.Cursor = System.Windows.Forms.Cursors.Hand
        Me.view_btn.CustomImages.Parent = Me.view_btn
        Me.view_btn.FillColor = System.Drawing.Color.FromArgb(CType(CType(47, Byte), Integer), CType(CType(60, Byte), Integer), CType(CType(77, Byte), Integer))
        Me.view_btn.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.view_btn.ForeColor = System.Drawing.Color.White
        Me.view_btn.HoverState.FillColor = System.Drawing.Color.Gray
        Me.view_btn.HoverState.Parent = Me.view_btn
        Me.view_btn.Location = New System.Drawing.Point(12, 3)
        Me.view_btn.Name = "view_btn"
        Me.view_btn.ShadowDecoration.Parent = Me.view_btn
        Me.view_btn.Size = New System.Drawing.Size(106, 30)
        Me.view_btn.TabIndex = 2
        Me.view_btn.Text = "VIEW RECORDS"
        '
        'main_clear
        '
        Me.main_clear.Animated = True
        Me.main_clear.BorderRadius = 3
        Me.main_clear.CheckedState.Parent = Me.main_clear
        Me.main_clear.Cursor = System.Windows.Forms.Cursors.Hand
        Me.main_clear.CustomImages.Parent = Me.main_clear
        Me.main_clear.FillColor = System.Drawing.Color.FromArgb(CType(CType(47, Byte), Integer), CType(CType(60, Byte), Integer), CType(CType(77, Byte), Integer))
        Me.main_clear.Font = New System.Drawing.Font("Segoe UI", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.main_clear.ForeColor = System.Drawing.Color.White
        Me.main_clear.HoverState.FillColor = System.Drawing.Color.Gray
        Me.main_clear.HoverState.Parent = Me.main_clear
        Me.main_clear.Location = New System.Drawing.Point(614, 445)
        Me.main_clear.Name = "main_clear"
        Me.main_clear.ShadowDecoration.Parent = Me.main_clear
        Me.main_clear.Size = New System.Drawing.Size(114, 46)
        Me.main_clear.TabIndex = 10
        Me.main_clear.Text = "CLEAR"
        '
        'fetch_btn
        '
        Me.fetch_btn.Animated = True
        Me.fetch_btn.CheckedState.Parent = Me.fetch_btn
        Me.fetch_btn.Cursor = System.Windows.Forms.Cursors.Hand
        Me.fetch_btn.CustomImages.Parent = Me.fetch_btn
        Me.fetch_btn.FillColor = System.Drawing.Color.DarkRed
        Me.fetch_btn.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.fetch_btn.ForeColor = System.Drawing.Color.White
        Me.fetch_btn.HoverState.FillColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.fetch_btn.HoverState.Parent = Me.fetch_btn
        Me.fetch_btn.Location = New System.Drawing.Point(13, 57)
        Me.fetch_btn.Name = "fetch_btn"
        Me.fetch_btn.ShadowDecoration.Parent = Me.fetch_btn
        Me.fetch_btn.Size = New System.Drawing.Size(85, 33)
        Me.fetch_btn.TabIndex = 2
        Me.fetch_btn.Text = "FETCH"
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.profile_id)
        Me.GroupBox1.Controls.Add(Me.fetch_btn)
        Me.GroupBox1.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox1.Location = New System.Drawing.Point(2, 75)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(737, 98)
        Me.GroupBox1.TabIndex = 8
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "PROFILE ID"
        '
        'admin_record
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(741, 579)
        Me.Controls.Add(Me.Guna2Panel1)
        Me.Controls.Add(Me.submit_btn)
        Me.Controls.Add(Me.GroupBox3)
        Me.Controls.Add(Me.GroupBox2)
        Me.Controls.Add(Me.Guna2Panel2)
        Me.Controls.Add(Me.main_clear)
        Me.Controls.Add(Me.GroupBox1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.Name = "admin_record"
        Me.ShowInTaskbar = False
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "admin_record"
        Me.Guna2Panel1.ResumeLayout(False)
        Me.Guna2Panel1.PerformLayout()
        Me.GroupBox3.ResumeLayout(False)
        CType(Me.picture_box, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox2.PerformLayout()
        Me.Guna2Panel2.ResumeLayout(False)
        Me.Guna2Panel2.PerformLayout()
        Me.GroupBox1.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents phoneno_txt As Guna.UI2.WinForms.Guna2TextBox
    Friend WithEvents Guna2HtmlLabel4 As Guna.UI2.WinForms.Guna2HtmlLabel
    Friend WithEvents profile_id As Guna.UI2.WinForms.Guna2ComboBox
    Friend WithEvents Guna2HtmlLabel5 As Guna.UI2.WinForms.Guna2HtmlLabel
    Friend WithEvents Guna2Panel1 As Guna.UI2.WinForms.Guna2Panel
    Friend WithEvents exit_home As Guna.UI2.WinForms.Guna2Button
    Friend WithEvents Guna2HtmlLabel3 As Guna.UI2.WinForms.Guna2HtmlLabel
    Friend WithEvents submit_btn As Guna.UI2.WinForms.Guna2Button
    Friend WithEvents email_txt As Guna.UI2.WinForms.Guna2TextBox
    Friend WithEvents select_btn As Guna.UI2.WinForms.Guna2Button
    Friend WithEvents fullname_txt As Guna.UI2.WinForms.Guna2TextBox
    Friend WithEvents GroupBox3 As GroupBox
    Friend WithEvents GroupBox2 As GroupBox
    Friend WithEvents Guna2Panel2 As Guna.UI2.WinForms.Guna2Panel
    Friend WithEvents counter_val_txt As Guna.UI2.WinForms.Guna2HtmlLabel
    Friend WithEvents Guna2HtmlLabel1 As Guna.UI2.WinForms.Guna2HtmlLabel
    Friend WithEvents view_btn As Guna.UI2.WinForms.Guna2Button
    Friend WithEvents main_clear As Guna.UI2.WinForms.Guna2Button
    Friend WithEvents fetch_btn As Guna.UI2.WinForms.Guna2Button
    Friend WithEvents GroupBox1 As GroupBox
    Friend WithEvents Guna2HtmlLabel2 As Guna.UI2.WinForms.Guna2HtmlLabel
    Friend WithEvents RoleComboBox As Guna.UI2.WinForms.Guna2ComboBox
    Friend WithEvents Guna2HtmlLabel6 As Guna.UI2.WinForms.Guna2HtmlLabel
    Friend WithEvents StatusComboBox As Guna.UI2.WinForms.Guna2ComboBox
    Friend WithEvents Guna2HtmlLabel7 As Guna.UI2.WinForms.Guna2HtmlLabel
    Friend WithEvents picture_box As Guna.UI2.WinForms.Guna2PictureBox
End Class
