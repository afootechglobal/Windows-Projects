﻿Imports MySql.Data.MySqlClient
Imports System.Text.RegularExpressions
Public Class admin_login
    Dim reader As MySqlDataReader
    Dim command As MySqlCommand
    Dim query As String
    Public staff_id, fullname, email_address As String
    Public login_staff_id, login_role_id, login_status_id As String
    Private Sub exit_home_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles exit_home.Click
        exit_btn(Me)
    End Sub

    Private Sub login_link_LinkClicked(ByVal sender As System.Object, ByVal e As System.Windows.Forms.LinkLabelLinkClickedEventArgs) Handles login_link.LinkClicked
        admin_log_panel.Show()
        admin_reset_panel.Hide()
    End Sub

    Private Sub forgotpass_link_LinkClicked_1(ByVal sender As System.Object, ByVal e As System.Windows.Forms.LinkLabelLinkClickedEventArgs) Handles forgotpass_link.LinkClicked
        admin_reset_panel.Show()
        admin_log_panel.Hide()
    End Sub



    Private Sub proceed_btn_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles proceed_btn.Click
        If email_txt.Text = "" Then
            MessageBox.Show("Error! Input your Email Address to Continue!", "Information", MessageBoxButtons.OK, MessageBoxIcon.Error)
        ElseIf functions.emailValidate(email_txt.Text) = False Then
            MessageBox.Show("Invalid Email Address", "Bank System Software", MessageBoxButtons.OK, MessageBoxIcon.Error)
            Exit Sub
        Else
            Try
                reader = functions.emailCheck(email_txt.Text)
                If reader.HasRows Then
                    staff_id = reader("staff_id")
                    Dim status_id = reader("status_id")
                    fullname = reader("fullname")
                    email_address = reader("email")

                    If status_id = 1 Then
                        Dim otp As String = New Random().Next(100000, 999999).ToString()

                        Dim connection = functions.connection

                        connection.Open()
                        command = New MySqlCommand("UPDATE staff_tab SET otp=@otp WHERE staff_id=@staff_id", connection)
                        command.Parameters.AddWithValue("@staff_id", staff_id)
                        command.Parameters.AddWithValue("@otp", otp)
                        reader = command.ExecuteReader
                        connection.Close()


                        admin_reset_password.Show()
                        Me.Hide()
                        index.Hide()
                    Else
                        MessageBox.Show("ERROR! Account has been Suspended", "Bank System Software", MessageBoxButtons.OK, MessageBoxIcon.Error)
                    End If
                Else
                    MessageBox.Show("Email Address not Found!", "Bank System Software", MessageBoxButtons.OK, MessageBoxIcon.Error)
                    Exit Sub
                End If
            Catch ex As Exception
                MsgBox(ex.ToString)
            End Try
        End If

    End Sub

    Private Sub admin_login_btn_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles admin_login_btn.Click
        If email_admin_txt.Text = "" Then
            MessageBox.Show("ERROR! Email address is required!", "Bank System Software", MessageBoxButtons.OK, MessageBoxIcon.Error)
        ElseIf password_txt.Text = "" Then
            MessageBox.Show("ERROR! Password is required!", "Bank System Software", MessageBoxButtons.OK, MessageBoxIcon.Error)
        ElseIf functions.emailValidate(email_admin_txt.Text) = False Then
            MessageBox.Show("Invalid Email Address", "Bank System Software", MessageBoxButtons.OK, MessageBoxIcon.Error)
            Exit Sub
        Else
            Dim connection = functions.connection

            Try
                connection.Open()
                command = New MySqlCommand("SELECT * FROM staff_tab WHERE email=@email", connection)
                command.Parameters.AddWithValue("@email", email_admin_txt.Text)
                reader = command.ExecuteReader
                reader.Read()

                If reader.HasRows Then
                    Dim storedHash As String = reader("password").ToString()


                    If BCrypt.Net.BCrypt.Verify(password_txt.Text, storedHash) Then
                        login_staff_id = reader("staff_id")
                        login_status_id = reader("status_id")
                        login_role_id = reader("role_id")
                        connection.close()

                        If login_status_id = 1 Then
                            connection.open()
                            command = New MySqlCommand("UPDATE staff_tab SET last_login=NOW() WHERE staff_id=@staff_id", connection)
                            command.Parameters.AddWithValue("@staff_id", login_staff_id)
                            reader = command.ExecuteReader
                            connection.close()
                            functions.directToDashboard()
                        Else
                            MessageBox.Show("ERROR! Account has been Suspended", "Bank System Software", MessageBoxButtons.OK, MessageBoxIcon.Error)
                        End If
                    Else

                        MessageBox.Show("ERROR! Invalid password!", "Bank System Software", MessageBoxButtons.OK, MessageBoxIcon.Error)
                    End If
                Else
                    MessageBox.Show("ERROR! Invalid email address!", "Bank System Software", MessageBoxButtons.OK, MessageBoxIcon.Error)
                End If
            Catch ex As Exception
                MsgBox(ex.ToString)
            End Try
        End If

    End Sub
End Class