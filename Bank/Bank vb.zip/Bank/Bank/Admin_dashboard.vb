﻿Imports System.IO
Imports MySql.Data.MySqlClient
Public Class Admin_dashboard
    Dim reader As MySqlDataReader

    Private Sub Admin_dashboard_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Dim currentDate As Date = Date.Today

        time.Text = DateTime.Now.ToString("h:mm:ss tt")
        date_txt.Text = currentDate.ToString("dddd, MMMM dd, yyyy")

        profilename_panel.FillColor = Color.FromArgb(230, 255, 255, 255)
        time_panel.FillColor = Color.FromArgb(230, 255, 255, 255)


        Dim result = functions.getStaffProfile(admin_login.login_staff_id)
        Dim arrimage() As Byte = result.item3

        fullname_label.Text = result.item1.ToString
            name_label.Text = result.item1.ToString
            last_login_label.Text = result.item2.ToString
            Dim mstream = New MemoryStream(arrimage)
            passport.Image = Image.FromStream(mstream)
        role_label.Text = result.item5.ToString
        status_label.Text = result.item4.ToString

        Dim allCounts = functions.allCounts()
        total_admin_label.Text = allCounts.item1.ToString
        total_customer_label.Text = allCounts.item2.ToString
        total_loan_label.Text = allCounts.item3.ToString
        total_balance_label.Text = allCounts.item4.ToString


        If admin_login.login_role_id <= 1 Then
            add_staff_btn.Hide()
            customer_btn.Location = New Point(8, 102)
            loan_btn.Location = New Point(8, 180)
            deposit_btn.Location = New Point(8, 256)
            setting_btn.Location = New Point(8, 328)
        End If
    End Sub

    Private Sub logout_btn_Click(sender As Object, e As EventArgs) Handles logout_btn.Click
        Dim answer As Integer
        answer = MessageBox.Show("Are you sure you want to Logout", "Logout Application", MessageBoxButtons.YesNo, MessageBoxIcon.Question)
        If answer = vbYes Then
            Me.Close()
        End If
    End Sub

    Private Sub add_staff_btn_Click(sender As Object, e As EventArgs) Handles add_staff_btn.Click
        index.Show()
        admin_record.Show()

    End Sub

    Private Sub customer_btn_Click(sender As Object, e As EventArgs) Handles customer_btn.Click
        index.Show()
        customer_record.Show()
    End Sub

    Private Sub loan_btn_Click(sender As Object, e As EventArgs) Handles loan_btn.Click
        index.Show()
        loan_form.Show()

    End Sub

    Private Sub setting_btn_Click(sender As Object, e As EventArgs) Handles setting_btn.Click
        index.Show()
        system_settings.Show()
    End Sub

    Private Sub deposit_btn_Click(sender As Object, e As EventArgs) Handles deposit_btn.Click
        index.Show()
        payment_deposit.Show()
    End Sub
End Class