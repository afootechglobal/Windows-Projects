﻿Imports System.IO
Imports MySql.Data.MySqlClient

Public Class admin_record
    Dim reader As MySqlDataReader
    Dim command As MySqlCommand
    Dim query As String
    Private Sub exit_home_Click(sender As Object, e As EventArgs) Handles exit_home.Click
        exit_btn(Me)
    End Sub

    Private Sub select_btn_Click(sender As Object, e As EventArgs) Handles select_btn.Click
        functions.selectPassport(picture_box)
    End Sub

    Private Sub view_btn_Click(sender As Object, e As EventArgs) Handles view_btn.Click
        view_records.Show()
        index.Show()
        Me.Hide()
    End Sub

    Private Sub admin_record_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        functions.getStaffID()
        functions.getRole()
        functions.getStatus(StatusComboBox)
        counter_val_txt.Text = GetRecordCount()
    End Sub

    Private Sub fetch_btn_Click(sender As Object, e As EventArgs) Handles fetch_btn.Click
        If profile_id.Text = "SELECT STAFF" Then
            MessageBox.Show("SELECT STAFF TO CONTINUE!", "Bank Application Software", MessageBoxButtons.OK, MessageBoxIcon.Error)

        Else
            Try
                Dim connection = functions.connection
                connection.Open()
                query = "SELECT a.*, b.role_name, c.status_name FROM staff_tab a, setup_role_tab b, setup_status_tab c WHERE a.status_id=c.status_id AND a.role_id=b.role_id AND staff_id=@staff_id;"
                Dim Command = New MySqlCommand(query, connection)
                Command.Parameters.AddWithValue("@staff_id", profile_id.SelectedValue)
                reader = Command.ExecuteReader
                reader.Read()

                Dim arrimage() As Byte

                fullname_txt.Text = reader("fullname")
                email_txt.Text = reader("email")
                phoneno_txt.Text = reader("mobile")
                RoleComboBox.Text = (reader("role_name"))
                RoleComboBox.SelectedValue = reader("role_id")
                StatusComboBox.Text = (reader("status_name"))
                StatusComboBox.SelectedValue = reader("status_id")
                arrimage = reader("passport")

                Dim mstream = New MemoryStream(arrimage)
                picture_box.Image = Image.FromStream(mstream)
                connection.Close()
            Catch ex As Exception
                MsgBox(ex.Message)
            End Try
        End If
    End Sub

    Private Sub submit_btn_Click(sender As Object, e As EventArgs) Handles submit_btn.Click

        If fullname_txt.Text = "" Or email_txt.Text = "" Or phoneno_txt.Text = "" Then
            MessageBox.Show("ERROR! Enter Input for all Fields", "Bank Application Software", MessageBoxButtons.OK, MessageBoxIcon.Error)
        ElseIf picture_box.Image Is Nothing Then
            MessageBox.Show("ERROR! Select a Passport to Continue!", "Bank Application Software", MessageBoxButtons.OK, MessageBoxIcon.Error)
        ElseIf functions.emailValidate(email_txt.Text) = False Then
            MessageBox.Show("ERROR! Invalid Email Address", "Bank Application Software", MessageBoxButtons.OK, MessageBoxIcon.Error)
        ElseIf RoleComboBox.Text = "SELECT ROLE" Then
            MessageBox.Show("SELECT ROLE TO CONTINUE!", "Bank Application Software", MessageBoxButtons.OK, MessageBoxIcon.Error)
        Else
            If profile_id.Text = "SELECT STAFF" Then
                reader = functions.emailCheck(email_txt.Text)
                If reader.HasRows Then
                    MessageBox.Show("ERROR! Email Address is already Exist, Kindly Enter a new Email Address to Continue!", "Bank Application Software", MessageBoxButtons.OK, MessageBoxIcon.Error)
                Else
                    staffRegistration()
                End If
            Else
                reader = functions.updateEmailCheck(email_txt.Text)
                If reader.HasRows Then
                    MessageBox.Show("ERROR! Emaill Address is already Exist, Kindly Enter a new Email Address to Continue!", "Bank Application Software", MessageBoxButtons.OK, MessageBoxIcon.Error)
                Else
                    UpdateStaff()
                End If
            End If
        End If
    End Sub

    Private Sub main_clear_Click(sender As Object, e As EventArgs) Handles main_clear.Click
        functions.clearFunction()
    End Sub

    Private Sub fullname_txt_KeyPress(sender As Object, e As KeyPressEventArgs) Handles fullname_txt.KeyPress
        functions.alphaCheck(e)
    End Sub

    Private Sub phoneno_txt_KeyPress(sender As Object, e As KeyPressEventArgs) Handles phoneno_txt.KeyPress
        functions.numCheck(e)
    End Sub

End Class