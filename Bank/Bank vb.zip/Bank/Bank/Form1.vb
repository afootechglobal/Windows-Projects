﻿Imports MySql.Data.MySqlClient
Public Class Form1

    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Dim connection = functions.connection
        Try
            connection.Open()
            If connection.State = ConnectionState.Open Then
                MsgBox("Connection successful.")
            End If
        Catch ex As MySqlException
            MsgBox("Connection failed: " & ex.Message)
            Me.Close()
        Finally
            connection.Close()
        End Try
        Guna2Panel1.FillColor = Color.FromArgb(180, 255, 255, 255)
    End Sub

    Private Sub user_btn_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles user_btn.Click
        index.Show()
        userlog.Show()
    End Sub
   
    Private Sub admin_btn_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles admin_btn.Click
        index.Show()
        admin_login.Show()
    End Sub
End Class
