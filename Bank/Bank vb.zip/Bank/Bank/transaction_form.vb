﻿Public Class transaction_form
    Private Sub backBtn_Click(sender As Object, e As EventArgs) Handles backBtn.Click
        Me.Hide()
        payment_deposit.Show()
    End Sub

    Private Sub closeBtn_Click(sender As Object, e As EventArgs) Handles closeBtn.Click
        exit_btn(Me)
        index.Close()
    End Sub

    Private Sub transaction_form_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Dim customer_id = payment_deposit.profile_id.SelectedValue
        functions.customerDepositTransaction(customer_id, userRecord)
    End Sub
End Class