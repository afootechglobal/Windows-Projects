﻿Public Class customer_loan_schedule
    Private Sub exit_home_Click(sender As Object, e As EventArgs) Handles exit_home.Click
        exit_btn(Me)
        index.Hide()

    End Sub

    Private Sub customer_loan_schedule_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Dim customer_id = userlog.login_customer_id

        functions.customerLoanSchedule(customer_id, loanScheduleRecord)
    End Sub
End Class