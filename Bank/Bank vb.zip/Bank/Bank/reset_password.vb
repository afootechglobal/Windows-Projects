﻿Imports MySql.Data.MySqlClient
Imports BCrypt.Net
Public Class reset_password
    Dim reader As MySqlDataReader
    Dim command As MySqlCommand
    Private Sub exit_home_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles exit_home.Click
        Me.Close()
    End Sub

    Private Sub reset_password_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        passLabel.Text = "Dear" & " " & userlog.fullname & "," & " " & "an OTP has been sent to your registered Email Address" & Environment.NewLine & "(" & userlog.email_address & ")"
    End Sub

    Private Sub reset_btn_Click(sender As Object, e As EventArgs) Handles reset_btn.Click
        If otp_txt.Text = "" Or create_pass.Text = "" Or confirm_pass.Text = "" Then
            MessageBox.Show("ERROR! All fields are Required", "Bank System Software", MessageBoxButtons.OK, MessageBoxIcon.Error)
        Else
            If create_pass.Text = confirm_pass.Text Then
                Try
                    Dim connection = functions.connection

                    connection.Open()
                    command = New MySqlCommand("SELECT otp FROM customer_tab WHERE otp=@otp AND customer_id=@customer_id", connection)
                    command.Parameters.AddWithValue("@customer_id", userlog.customer_id)
                    command.Parameters.AddWithValue("@otp", otp_txt.Text)
                    reader = command.ExecuteReader

                    If reader.HasRows Then
                        connection.close()
                        connection.open()
                        command = New MySqlCommand("UPDATE customer_tab SET password=@password WHERE customer_id=@customer_id", connection)
                        command.Parameters.AddWithValue("@customer_id", userlog.customer_id)
                        Dim hashedPassword As String = BCrypt.Net.BCrypt.HashPassword(create_pass.Text)
                        command.Parameters.AddWithValue("@password", hashedPassword)
                        reader = command.ExecuteReader
                        connection.Close()
                        MessageBox.Show("SUCCESS! Password has been successfully updated", "Bank System Software", MessageBoxButtons.OK, MessageBoxIcon.Information)
                        Me.Hide()
                        index.Show()
                        userlog.Show()

                    Else
                        MessageBox.Show("ERROR! OTP not valid", "Bank System Software", MessageBoxButtons.OK, MessageBoxIcon.Error)
                    End If
                Catch ex As Exception
                    MsgBox(ex.ToString)
                End Try
            Else
                MessageBox.Show("ERROR! New password and confirm password don't match", "Bank System Software", MessageBoxButtons.OK, MessageBoxIcon.Error)
            End If
        End If
    End Sub

    Private Sub login_link_LinkClicked(sender As Object, e As LinkLabelLinkClickedEventArgs) Handles login_link.LinkClicked
        Dim otp As String = New Random().Next(100000, 999999).ToString()

        Dim connection = functions.connection
        connection.Open()
        command = New MySqlCommand("UPDATE customer_tab SET otp=@otp WHERE customer_id=@customer_id", connection)
        command.Parameters.AddWithValue("@customer_id", userlog.customer_id)
        command.Parameters.AddWithValue("@otp", otp)
        reader = command.ExecuteReader
        connection.Close()

        MessageBox.Show("SUCCESS! OTP has been successfully resent", "Bank System Software", MessageBoxButtons.OK, MessageBoxIcon.Information)


    End Sub

    Private Sub otp_txt_KeyPress(sender As Object, e As KeyPressEventArgs) Handles otp_txt.KeyPress
        functions.numCheck(e)
    End Sub
End Class