﻿
Imports MySql.Data.MySqlClient
Imports System.IO
Public Class user_dashboard
    Private Sub user_dashboard_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        profilename_panel.FillColor = Color.FromArgb(230, 255, 255, 255)

        Dim result = functions.getCustomerProfile(userlog.login_customer_id)
        fullname_label.Text = result.item1.ToString()
        Dim arrimage() As Byte = result.item5
        last_login_label.Text = result.item2.ToString
        acct_bal_txt.Text = "NGN" & " " & result.item3.ToString
        loan_bal_txt.Text = "NGN" & " " & result.item4.ToString
        Dim mstream = New MemoryStream(arrimage)
        passport.Image = Image.FromStream(mstream)
    End Sub

    Private Sub logout_btn_Click(sender As Object, e As EventArgs) Handles logout_btn.Click
        Dim closeValidation = MessageBox.Show("Are you sure you want to Logout?", "Logout Application", MessageBoxButtons.YesNo, MessageBoxIcon.Question)
        If closeValidation = vbYes Then
            Me.Close()
            index.Show()
            userlog.Show()
        End If
    End Sub

    Private Sub request_loan_Click(sender As Object, e As EventArgs) Handles request_loan.Click
        index.Show()
        user_loan_request.Show()
    End Sub

    Private Sub cust_deposit_Click(sender As Object, e As EventArgs) Handles cust_deposit.Click
        index.Show()
        user_deposit.Show()
    End Sub

    Private Sub change_password_btn_Click(sender As Object, e As EventArgs) Handles change_password_btn.Click
        index.Show()
        change_pass.Show()
    End Sub

    Private Sub loan_schedule_Click(sender As Object, e As EventArgs) Handles loan_schedule.Click
        index.Show()
        customer_loan_schedule.Show()
    End Sub

    Private Sub repay_btn_Click(sender As Object, e As EventArgs) Handles loan_schedule.Click, repay_btn.Click
        index.Show()
        repay_loan.Show()
    End Sub
End Class